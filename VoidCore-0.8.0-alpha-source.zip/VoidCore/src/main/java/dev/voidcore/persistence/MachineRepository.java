package dev.voidcore.persistence;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.machine.MachineFault;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineType;
import dev.voidcore.machine.ObserverProgram;
import dev.voidcore.machine.ControlDirective;
import dev.voidcore.machine.AutomationRule;
import dev.voidcore.machine.SignalGate;
import dev.voidcore.machine.SingularityMode;
import dev.voidcore.machine.CoreChamberMode;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.inventory.ItemStack;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

public final class MachineRepository {
    private static final String INSERT = """
        INSERT INTO machines(
            world_uuid, x, y, z, type, flux, progress, heat, target_heat, pressure, target_pressure, quality, wear, entropy, computation, fault, fault_ticks,
            primary_input, secondary_input, catalyst, fuel, output, byproduct,
            upgrade_0, upgrade_1, upgrade_2, completed_process, selected_process, network_frequency,
            secondary_network_frequency, routing_priority, routing_filter_id,
            observer_program, control_directive, lifetime_cycles, lifetime_items_produced, lifetime_flux_consumed, lifetime_entropy_processed, incident_count,
            automation_group, signal_channel, signal_gate, automation_rule, singularity_mode, core_chamber_mode, production_ledger
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """;

    private final VoidCorePlugin plugin;
    private final VoidDatabase database;

    public MachineRepository(VoidCorePlugin plugin, VoidDatabase database) {
        this.plugin = plugin;
        this.database = database;
    }

    public List<MachineInstance> loadAll() {
        List<MachineInstance> machines = new ArrayList<>();
        try (var statement = database.connection().prepareStatement("SELECT * FROM machines");
             ResultSet result = statement.executeQuery()) {
            while (result.next()) {
                World world;
                try { world = Bukkit.getWorld(UUID.fromString(result.getString("world_uuid"))); }
                catch (IllegalArgumentException ex) { continue; }
                if (world == null) continue;
                MachineType type = MachineType.fromId(result.getString("type"));
                if (type == null) continue;
                MachineInstance machine = new MachineInstance(new Location(world,
                    result.getInt("x"), result.getInt("y"), result.getInt("z")), type);
                machine.flux(result.getInt("flux"));
                machine.progress(result.getDouble("progress"));
                machine.heat(result.getDouble("heat"));
                machine.targetHeat(result.getDouble("target_heat"));
                machine.pressure(result.getDouble("pressure"));
                machine.targetPressure(result.getDouble("target_pressure"));
                machine.quality(result.getInt("quality"));
                machine.wear(result.getDouble("wear"));
                machine.entropy(result.getDouble("entropy"));
                machine.computation(result.getInt("computation"));
                machine.fault(MachineFault.fromId(result.getString("fault")));
                machine.faultTicks(result.getInt("fault_ticks"));
                machine.input(readItem(result, "primary_input"));
                machine.secondaryInput(readItem(result, "secondary_input"));
                machine.catalyst(readItem(result, "catalyst"));
                machine.fuel(readItem(result, "fuel"));
                machine.output(readItem(result, "output"));
                machine.byproduct(readItem(result, "byproduct"));
                machine.upgrade(0, readItem(result, "upgrade_0"));
                machine.upgrade(1, readItem(result, "upgrade_1"));
                machine.upgrade(2, readItem(result, "upgrade_2"));
                machine.completedProcessId(result.getString("completed_process"));
                machine.selectedProcessId(result.getString("selected_process"));
                machine.networkFrequency(result.getInt("network_frequency"));
                machine.secondaryNetworkFrequency(result.getInt("secondary_network_frequency"));
                machine.routingPriority(result.getInt("routing_priority"));
                machine.routingFilterId(result.getString("routing_filter_id"));
                machine.observerProgram(ObserverProgram.fromId(result.getString("observer_program")));
                machine.controlDirective(ControlDirective.fromId(result.getString("control_directive")));
                machine.lifetimeCycles(result.getLong("lifetime_cycles"));
                machine.lifetimeItemsProduced(result.getLong("lifetime_items_produced"));
                machine.lifetimeFluxConsumed(result.getLong("lifetime_flux_consumed"));
                machine.lifetimeEntropyProcessed(result.getDouble("lifetime_entropy_processed"));
                machine.incidentCount(result.getLong("incident_count"));
                machine.automationGroup(result.getInt("automation_group"));
                machine.signalChannel(result.getInt("signal_channel"));
                machine.signalGate(SignalGate.fromId(result.getString("signal_gate")));
                machine.automationRule(AutomationRule.fromId(result.getString("automation_rule")));
                machine.singularityMode(SingularityMode.fromId(result.getString("singularity_mode")));
                machine.coreChamberMode(CoreChamberMode.fromId(result.getString("core_chamber_mode")));
                machine.productionLedger(decodeLedger(result.getString("production_ledger")));
                machines.add(machine);
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not load machines from SQLite.", ex);
        }
        return machines;
    }

    public int count() {
        try (var statement = database.connection().prepareStatement("SELECT COUNT(*) FROM machines");
             var result = statement.executeQuery()) {
            return result.next() ? result.getInt(1) : 0;
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Could not count persisted machines.", ex);
            return 0;
        }
    }

    public boolean saveAll(Collection<MachineInstance> machines) {
        return saveSnapshots(machines.stream().map(MachineSnapshot::capture).toList());
    }

    public synchronized boolean saveSnapshots(Collection<MachineSnapshot> snapshots) {
        try {
            var connection = database.connection();
            boolean oldAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try (var clear = connection.prepareStatement("DELETE FROM machines");
                 PreparedStatement insert = connection.prepareStatement(INSERT)) {
                clear.executeUpdate();
                for (MachineSnapshot snapshot : snapshots) {
                    write(insert, snapshot);
                    insert.addBatch();
                }
                insert.executeBatch();
                connection.commit();
                return true;
            } catch (SQLException ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(oldAutoCommit);
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not save machine snapshot to SQLite.", ex);
            return false;
        }
    }

    private void write(PreparedStatement s, MachineSnapshot m) throws SQLException {
        s.setString(1, m.world().toString());
        s.setInt(2, m.x()); s.setInt(3, m.y()); s.setInt(4, m.z()); s.setString(5, m.type());
        s.setInt(6, m.flux()); s.setDouble(7, m.progress()); s.setDouble(8, m.heat()); s.setDouble(9, m.targetHeat());
        s.setDouble(10, m.pressure()); s.setDouble(11, m.targetPressure()); s.setInt(12, m.quality()); s.setDouble(13, m.wear());
        s.setDouble(14, m.entropy()); s.setInt(15, m.computation()); s.setString(16, m.fault()); s.setInt(17, m.faultTicks());
        bytes(s,18,m.primaryInput()); bytes(s,19,m.secondaryInput()); bytes(s,20,m.catalyst()); bytes(s,21,m.fuel());
        bytes(s,22,m.output()); bytes(s,23,m.byproduct()); bytes(s,24,m.upgrade0()); bytes(s,25,m.upgrade1()); bytes(s,26,m.upgrade2());
        s.setString(27, m.completedProcess()); s.setString(28, m.selectedProcess()); s.setInt(29, m.networkFrequency());
        s.setInt(30, m.secondaryNetworkFrequency()); s.setInt(31, m.routingPriority()); s.setString(32, m.routingFilterId());
        s.setString(33, m.observerProgram()); s.setString(34, m.controlDirective()); s.setLong(35, m.lifetimeCycles());
        s.setLong(36, m.lifetimeItemsProduced()); s.setLong(37, m.lifetimeFluxConsumed()); s.setDouble(38, m.lifetimeEntropyProcessed());
        s.setLong(39, m.incidentCount());
        s.setInt(40, m.automationGroup()); s.setInt(41, m.signalChannel()); s.setString(42, m.signalGate());
        s.setString(43, m.automationRule()); s.setString(44, m.singularityMode()); s.setString(45, m.coreChamberMode());
        s.setString(46, m.productionLedger());
    }

    private static void bytes(PreparedStatement statement, int index, byte[] data) throws SQLException {
        statement.setBytes(index, data);
    }

    private static java.util.Map<String, Long> decodeLedger(String encoded) {
        if (encoded == null || encoded.isBlank()) return java.util.Map.of();
        java.util.Map<String, Long> result = new java.util.LinkedHashMap<>();
        for (String part : encoded.split(";")) {
            String[] pair = part.split("=", 2);
            if (pair.length != 2 || !pair[0].matches("[a-z0-9_]+")) continue;
            try {
                long value = Long.parseLong(pair[1]);
                if (value > 0L) result.put(pair[0], value);
            } catch (NumberFormatException ignored) { }
        }
        return java.util.Map.copyOf(result);
    }

    private static ItemStack readItem(ResultSet result, String column) throws SQLException {
        byte[] data = result.getBytes(column);
        if (data == null || data.length == 0) return null;
        try { return ItemStack.deserializeBytes(data); }
        catch (IllegalArgumentException ex) { return null; }
    }
}
