package dev.voidcore.persistence;

import dev.voidcore.machine.MachineInstance;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/** Immutable, Bukkit-free persistence payload captured on the server thread. */
public record MachineSnapshot(
    UUID world,
    int x,
    int y,
    int z,
    String type,
    int flux,
    double progress,
    double heat,
    double targetHeat,
    double pressure,
    double targetPressure,
    int quality,
    double wear,
    double entropy,
    int computation,
    String fault,
    int faultTicks,
    byte[] primaryInput,
    byte[] secondaryInput,
    byte[] catalyst,
    byte[] fuel,
    byte[] output,
    byte[] byproduct,
    byte[] upgrade0,
    byte[] upgrade1,
    byte[] upgrade2,
    String completedProcess,
    String selectedProcess,
    int networkFrequency,
    int secondaryNetworkFrequency,
    int routingPriority,
    String routingFilterId,
    String observerProgram,
    String controlDirective,
    long lifetimeCycles,
    long lifetimeItemsProduced,
    long lifetimeFluxConsumed,
    double lifetimeEntropyProcessed,
    long incidentCount,
    int automationGroup,
    int signalChannel,
    String signalGate,
    String automationRule,
    String singularityMode,
    String coreChamberMode,
    String productionLedger
) {
    public static MachineSnapshot capture(MachineInstance machine) {
        Location location = machine.location();
        return new MachineSnapshot(
            location.getWorld().getUID(), location.getBlockX(), location.getBlockY(), location.getBlockZ(), machine.type().id(),
            machine.flux(), machine.progress(), machine.heat(), machine.targetHeat(), machine.pressure(), machine.targetPressure(),
            machine.quality(), machine.wear(), machine.entropy(), machine.computation(), machine.fault().id(), machine.faultTicks(),
            bytes(machine.input()), bytes(machine.secondaryInput()),
            bytes(machine.catalyst()), bytes(machine.fuel()), bytes(machine.output()), bytes(machine.byproduct()),
            bytes(machine.upgrade(0)), bytes(machine.upgrade(1)), bytes(machine.upgrade(2)), machine.completedProcessId(),
            machine.selectedProcessId(), machine.networkFrequency(), machine.secondaryNetworkFrequency(), machine.routingPriority(),
            machine.routingFilterId(), machine.observerProgram().id(), machine.controlDirective().id(), machine.lifetimeCycles(),
            machine.lifetimeItemsProduced(), machine.lifetimeFluxConsumed(), machine.lifetimeEntropyProcessed(), machine.incidentCount(),
            machine.automationGroup(), machine.signalChannel(), machine.signalGate().id(), machine.automationRule().id(),
            machine.singularityMode().id(), machine.coreChamberMode().id(), encodeLedger(machine.productionLedger()));
    }

    private static String encodeLedger(java.util.Map<String, Long> ledger) {
        if (ledger == null || ledger.isEmpty()) return "";
        return ledger.entrySet().stream()
            .filter(entry -> entry.getKey() != null && entry.getKey().matches("[a-z0-9_]+") && entry.getValue() != null && entry.getValue() > 0L)
            .sorted(java.util.Map.Entry.comparingByKey())
            .map(entry -> entry.getKey() + "=" + entry.getValue())
            .collect(java.util.stream.Collectors.joining(";"));
    }

    private static byte[] bytes(ItemStack item) {
        return item == null || item.getType().isAir() ? null : item.serializeAsBytes();
    }
}
