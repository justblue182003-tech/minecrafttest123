package dev.voidcore.persistence;

import dev.voidcore.VoidCorePlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

public final class VoidDatabase implements AutoCloseable {
    private static final int CURRENT_SCHEMA = 5;

    private final VoidCorePlugin plugin;
    private final File file;
    private Connection connection;

    public VoidDatabase(VoidCorePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "voidcore.db");
    }

    public void open() {
        try {
            if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
                throw new IllegalStateException("Could not create VoidCore data directory.");
            }
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
            try (Statement statement = connection.createStatement()) {
                statement.execute("PRAGMA foreign_keys = ON");
                statement.execute("PRAGMA journal_mode = WAL");
                statement.execute("PRAGMA synchronous = NORMAL");
                statement.execute("PRAGMA busy_timeout = 5000");
            }
            migrate();
        } catch (ClassNotFoundException | SQLException ex) {
            throw new IllegalStateException("Could not initialize VoidCore SQLite persistence.", ex);
        }
    }

    public Connection connection() {
        if (connection == null) throw new IllegalStateException("Database has not been opened.");
        return connection;
    }

    private void migrate() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute("CREATE TABLE IF NOT EXISTS vc_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
        }
        int version = schemaVersion();
        if (version < 1) migrateV1();
        if (schemaVersion() < 2) migrateV2();
        if (schemaVersion() < 3) migrateV3();
        if (schemaVersion() < 4) migrateV4();
        if (schemaVersion() < 5) migrateV5();
        if (schemaVersion() != CURRENT_SCHEMA) {
            plugin.getLogger().warning("VoidCore database schema is newer than this plugin expects: " + schemaVersion());
        }
    }

    private int schemaVersion() throws SQLException {
        try (var statement = connection.prepareStatement("SELECT value FROM vc_meta WHERE key = 'schema_version'");
             var result = statement.executeQuery()) {
            if (!result.next()) return 0;
            try {
                return Integer.parseInt(result.getString(1));
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }
    }

    private void migrateV1() throws SQLException {
        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            statement.execute("""
                CREATE TABLE IF NOT EXISTS machines (
                    world_uuid TEXT NOT NULL,
                    x INTEGER NOT NULL,
                    y INTEGER NOT NULL,
                    z INTEGER NOT NULL,
                    type TEXT NOT NULL,
                    flux INTEGER NOT NULL DEFAULT 0,
                    progress REAL NOT NULL DEFAULT 0,
                    heat REAL NOT NULL DEFAULT 20,
                    target_heat REAL NOT NULL DEFAULT 20,
                    quality INTEGER NOT NULL DEFAULT 50,
                    wear REAL NOT NULL DEFAULT 0,
                    primary_input BLOB,
                    secondary_input BLOB,
                    catalyst BLOB,
                    fuel BLOB,
                    output BLOB,
                    byproduct BLOB,
                    upgrade_0 BLOB,
                    upgrade_1 BLOB,
                    upgrade_2 BLOB,
                    completed_process TEXT,
                    selected_process TEXT,
                    network_frequency INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY(world_uuid, x, y, z)
                )
                """);
            statement.execute("CREATE INDEX IF NOT EXISTS idx_machines_type ON machines(type)");
            statement.execute("INSERT OR REPLACE INTO vc_meta(key, value) VALUES('schema_version', '1')");
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    private void migrateV2() throws SQLException {
        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            addColumnIfMissing(statement, "pressure", "REAL NOT NULL DEFAULT 1");
            addColumnIfMissing(statement, "target_pressure", "REAL NOT NULL DEFAULT 1");
            addColumnIfMissing(statement, "fault", "TEXT NOT NULL DEFAULT 'none'");
            addColumnIfMissing(statement, "secondary_network_frequency", "INTEGER NOT NULL DEFAULT 2");
            addColumnIfMissing(statement, "routing_priority", "INTEGER NOT NULL DEFAULT 5");
            addColumnIfMissing(statement, "routing_filter_id", "TEXT");
            statement.execute("INSERT OR REPLACE INTO vc_meta(key, value) VALUES('schema_version', '2')");
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    private void migrateV3() throws SQLException {
        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            addColumnIfMissing(statement, "entropy", "REAL NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "computation", "INTEGER NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "fault_ticks", "INTEGER NOT NULL DEFAULT 0");
            statement.execute("INSERT OR REPLACE INTO vc_meta(key, value) VALUES('schema_version', '3')");
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    private void migrateV4() throws SQLException {
        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            addColumnIfMissing(statement, "observer_program", "TEXT NOT NULL DEFAULT 'broad_spectrum'");
            addColumnIfMissing(statement, "control_directive", "TEXT NOT NULL DEFAULT 'balanced'");
            addColumnIfMissing(statement, "lifetime_cycles", "INTEGER NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "lifetime_items_produced", "INTEGER NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "lifetime_flux_consumed", "INTEGER NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "lifetime_entropy_processed", "REAL NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "incident_count", "INTEGER NOT NULL DEFAULT 0");
            statement.execute("INSERT OR REPLACE INTO vc_meta(key, value) VALUES('schema_version', '4')");
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    private void migrateV5() throws SQLException {
        boolean autoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            addColumnIfMissing(statement, "automation_group", "INTEGER NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "signal_channel", "INTEGER NOT NULL DEFAULT 0");
            addColumnIfMissing(statement, "signal_gate", "TEXT NOT NULL DEFAULT 'ignore'");
            addColumnIfMissing(statement, "automation_rule", "TEXT NOT NULL DEFAULT 'always'");
            addColumnIfMissing(statement, "singularity_mode", "TEXT NOT NULL DEFAULT 'contained'");
            addColumnIfMissing(statement, "core_chamber_mode", "TEXT NOT NULL DEFAULT 'stabilization'");
            addColumnIfMissing(statement, "production_ledger", "TEXT NOT NULL DEFAULT ''");
            statement.execute("INSERT OR REPLACE INTO vc_meta(key, value) VALUES('schema_version', '5')");
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(autoCommit);
        }
    }

    /** Makes interrupted/manual schema migration recovery idempotent rather than failing on a duplicate column. */
    private void addColumnIfMissing(Statement statement, String column, String definition) throws SQLException {
        if (hasColumn("machines", column)) return;
        if (!column.matches("[a-z_]+")) throw new SQLException("Unsafe migration column: " + column);
        statement.execute("ALTER TABLE machines ADD COLUMN " + column + " " + definition);
    }

    private boolean hasColumn(String table, String column) throws SQLException {
        try (var statement = connection.prepareStatement("PRAGMA table_info(" + table + ")");
             var result = statement.executeQuery()) {
            while (result.next()) {
                if (column.equalsIgnoreCase(result.getString("name"))) return true;
            }
            return false;
        }
    }

    @Override
    public void close() {
        if (connection == null) return;
        try {
            connection.close();
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Could not close VoidCore SQLite connection cleanly.", ex);
        } finally {
            connection = null;
        }
    }
}
