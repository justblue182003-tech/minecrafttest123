package dev.voidcore.research;

import org.bukkit.Material;

public enum ResearchExperiment {
    DISCOVER_RESONANCE(
        "discover_resonance", "First Resonance", Material.AMETHYST_SHARD, 1, 5,
        "Recover a Resonant Fragment from a naturally mined deep ore."
    ),
    ASSEMBLE_COPPER_LATTICE(
        "assemble_copper_lattice", "Controlled Fabrication", Material.CHAIN, 1, 3,
        "Assemble a Copper Lattice at a Prototype Bench."
    ),
    STABILIZE_RESONANCE(
        "stabilize_resonance", "Stable Envelope", Material.ECHO_SHARD, 1, 5,
        "Produce and recover Charged Resonance from a Flux Crucible."
    ),
    ANALYZE_RESONANCE(
        "analyze_resonance", "Spectral Signature", Material.SPYGLASS, 1, 5,
        "Scan a Resonant Fragment in a Spectrum Analyzer."
    ),
    BUILD_PROTOTYPE_CORE(
        "build_prototype_core", "Integrated Prototype", Material.COMPARATOR, 1, 6,
        "Assemble a Prototype Core at a Prototype Bench."
    ),
    BUILD_FIELD_EMITTER(
        "build_field_emitter", "Active Field", Material.END_ROD, 1, 5,
        "Assemble a Field Emitter at a Prototype Bench."
    ),
    BUILD_SPECTRAL_PLATE(
        "build_spectral_plate", "Resolved Spectrum", Material.GLASS_PANE, 1, 5,
        "Assemble a Spectral Plate at a Prototype Bench."
    ),
    HEAT_TREAT_MATRIX(
        "heat_treat_matrix", "Thermal Hysteresis", Material.BLAST_FURNACE, 1, 7,
        "Recover an Annealed Matrix produced inside the Induction Heater's valid heat window."
    ),
    RUN_CATALYTIC_REACTION(
        "run_catalytic_reaction", "Catalytic Activation", Material.BREWING_STAND, 1, 8,
        "Recover a Catalyzed Matrix from a heated Catalytic Reactor."
    ),
    PURIFY_CATALYST(
        "purify_catalyst", "Surface Recovery", Material.CAULDRON, 1, 8,
        "Recover a Catalyst Matrix after a Matrix Purifier removes contamination from it."
    ),
    PREPARE_REACTIVE_SLURRY(
        "prepare_reactive_slurry", "Coupled Feed", Material.LIME_DYE, 1, 9,
        "Run a two-input catalytic process and recover Reactive Slurry."
    ),
    CRYOGENIC_SEPARATION(
        "cryogenic_separation", "Cold Fraction", Material.PACKED_ICE, 1, 10,
        "Recover a Purified Matrix from a Cryogenic Column below ambient temperature."
    ),
    SERVICE_MACHINE(
        "service_machine", "Preventive Maintenance", Material.ANVIL, 1, 5,
        "Use a Precision Maintenance Kit on a machine with measurable wear."
    ),
    NETWORK_FLUX_BALANCE(
        "network_flux_balance", "Shared Load", Material.LIGHTNING_ROD, 1, 10,
        "Operate a Flux Bus graph that successfully transfers flux between two machines."
    ),
    PRIORITY_ROUTE(
        "priority_route", "Deterministic Priority", Material.CRAFTER, 1, 10,
        "Route an item through a network where a Phase Router or Priority Buffer changes destination priority."
    ),
    FREQUENCY_BRIDGE(
        "frequency_bridge", "Cross-Frequency Bridge", Material.COPPER_GRATE, 1, 10,
        "Transfer flux or items across two frequency domains joined by a Frequency Splitter."
    ),
    PRESSURE_SYNTHESIS(
        "pressure_synthesis", "Pressure Envelope", Material.HEAVY_WEIGHTED_PRESSURE_PLATE, 1, 12,
        "Recover a pressure-engineered output produced inside both its thermal and pressure windows."
    ),
    FAULT_RECOVERY(
        "fault_recovery", "Hard-Fault Recovery", Material.ANVIL, 1, 8,
        "Repair a hard machine fault with the required replacement part instead of routine maintenance."
    ),
    RECLAIM_WASTE(
        "reclaim_waste", "Closed Waste Loop", Material.CHARCOAL, 1, 12,
        "Recover usable feedstock from Thermal Residue inside a complete Entropy Condenser Array."
    ),
    STABLE_OBSERVATION(
        "stable_observation", "Correlated Observation", Material.OBSERVER, 1, 12,
        "Accumulate at least 250 computation in a Phase Observer under a valid environmental signal."
    ),
    ASSEMBLE_CONDENSER_ARRAY(
        "assemble_condenser_array", "Array Commissioning", Material.BEACON, 1, 14,
        "Complete and inspect the full Entropy Condenser multiblock structure."
    ),
    ENVIRONMENTAL_PROCESS(
        "environmental_process", "Environmental Constraint", Material.END_STONE, 1, 14,
        "Recover a process output whose recipe requires a specific world environment."
    ),
    ENTROPY_CHAIN_RECOVERY(
        "entropy_chain_recovery", "Cascade Arrest", Material.SCULK_CATALYST, 1, 12,
        "Repair an entropy-driven fault chain before a containment breach remains active."
    ),
    PROGRAM_OBSERVER(
        "program_observer", "Programmed Observation", Material.COMPARATOR, 1, 12,
        "Change a Phase Observer from broad-spectrum sensing to a specialized observation program."
    ),
    BROADCAST_CONTROL(
        "broadcast_control", "Factory Policy", Material.REDSTONE_LAMP, 1, 14,
        "Run a non-balanced Control Matrix policy while at least two machine endpoints share its network."
    ),
    FIELD_CALIBRATION(
        "field_calibration", "Spatial Calibration", Material.LODESTONE, 1, 14,
        "Operate a machine inside a coherence field stabilized above 80%."
    ),
    INCIDENT_RECOVERY(
        "incident_recovery", "Incident Recovery", Material.REINFORCED_DEEPSLATE, 1, 16,
        "Recover a Void Core from a spatial-collapse fault without rebuilding the controller."
    ),
    PRODUCTION_HISTORY(
        "production_history", "Industrial History", Material.CLOCK, 1, 14,
        "Inspect a machine after it has completed at least 25 production cycles."
    ),
    ASSEMBLE_VOID_CORE(
        "assemble_void_core", "Void Core Commissioning", Material.CRYING_OBSIDIAN, 1, 18,
        "Complete and inspect the full 35-block Void Core containment lattice."
    ),
    STABLE_VOID_CORE_RUN(
        "stable_void_core_run", "Stable Singularity Run", Material.DRAGON_BREATH, 1, 22,
        "Recover a Void Seed produced by a complete Void Core while the spatial field is stable."
    ),
    SIGNAL_AUTOMATION(
        "signal_automation", "Closed-Loop Automation", Material.COMPARATOR, 1, 16,
        "Drive a non-trivial automation signal and let a gated machine change its run permission from that channel."
    ),
    REMOTE_OPERATIONS(
        "remote_operations", "Remote Operations", Material.LECTERN, 1, 14,
        "Inspect a resolved Phase network from an Automation Terminal with at least three grouped endpoints."
    ),
    CORE_UPGRADE(
        "core_upgrade", "Auxiliary Containment", Material.RESPAWN_ANCHOR, 1, 18,
        "Operate a Void Core with a nearby configured upgrade chamber and select a non-default singularity mode."
    ),
    REFINE_VOID_SEED(
        "refine_void_seed", "Singularity Refinement", Material.ENDER_EYE, 1, 24,
        "Recover a Compressed Void Seed from a supported, stable Void Core."
    ),
    DIMENSIONAL_LINK(
        "dimensional_link", "Dimensional Phase Link", Material.LODESTONE, 1, 24,
        "Resolve a Phase network containing loaded matching-frequency Dimensional Anchors in different worlds."
    ),
    FIELD_VISUALIZATION(
        "field_visualization", "Visible Stability", Material.END_ROD, 1, 10,
        "Render a local spatial-field diagnostic trace for an operating factory."
    ),
    PROJECT_NULLSTAR(
        "project_nullstar", "Project Nullstar", Material.BEACON, 1, 40,
        "Commission the server-scale Nullstar objective after meeting all infrastructure, production, and dimensional milestones."
    );

    private final String id;
    private final String displayName;
    private final Material icon;
    private final int target;
    private final int insightReward;
    private final String description;

    ResearchExperiment(String id, String displayName, Material icon, int target, int insightReward, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.target = target;
        this.insightReward = insightReward;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public int target() { return target; }
    public int insightReward() { return insightReward; }
    public String description() { return description; }

    public static ResearchExperiment fromId(String id) {
        if (id == null) return null;
        for (ResearchExperiment experiment : values()) if (experiment.id.equalsIgnoreCase(id)) return experiment;
        return null;
    }
}
