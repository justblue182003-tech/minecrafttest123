package dev.voidcore.research;

import dev.voidcore.Keys;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;

public final class ResearchService {
    public enum UnlockResult {
        UNLOCKED,
        ALREADY_UNLOCKED,
        MISSING_PREREQUISITE,
        MISSING_EXPERIMENT,
        NOT_ENOUGH_INSIGHT
    }

    private final Keys keys;
    private final ExperimentService experiments;

    public ResearchService(Keys keys, ExperimentService experiments) {
        this.keys = keys;
        this.experiments = experiments;
    }

    public int insight(Player player) {
        return player.getPersistentDataContainer().getOrDefault(keys.insight, PersistentDataType.INTEGER, 0);
    }

    public void addInsight(Player player, int amount) {
        if (amount == 0) return;
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        pdc.set(keys.insight, PersistentDataType.INTEGER, Math.max(0, insight(player) + amount));
    }

    public void setInsight(Player player, int value) {
        player.getPersistentDataContainer().set(keys.insight, PersistentDataType.INTEGER, Math.max(0, value));
    }

    public boolean isUnlocked(Player player, ResearchNode node) {
        return unlocked(player).contains(node);
    }

    public Set<ResearchNode> unlocked(Player player) {
        String raw = player.getPersistentDataContainer().get(keys.research, PersistentDataType.STRING);
        if (raw == null || raw.isBlank()) return new LinkedHashSet<>();
        return Arrays.stream(raw.split(","))
            .map(ResearchNode::fromId)
            .filter(java.util.Objects::nonNull)
            .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    public boolean prerequisitesMet(Player player, ResearchNode node) {
        Set<ResearchNode> unlocked = unlocked(player);
        return unlocked.containsAll(node.prerequisites());
    }

    public boolean experimentsMet(Player player, ResearchNode node) {
        return node.experiments().stream().allMatch(experiment -> experiments.isComplete(player, experiment));
    }

    public UnlockResult unlock(Player player, ResearchNode node) {
        Set<ResearchNode> unlocked = unlocked(player);
        if (unlocked.contains(node)) return UnlockResult.ALREADY_UNLOCKED;
        if (!unlocked.containsAll(node.prerequisites())) return UnlockResult.MISSING_PREREQUISITE;
        if (!experimentsMet(player, node)) return UnlockResult.MISSING_EXPERIMENT;
        if (insight(player) < node.cost()) return UnlockResult.NOT_ENOUGH_INSIGHT;

        addInsight(player, -node.cost());
        unlocked.add(node);
        String serialized = unlocked.stream().map(ResearchNode::id).collect(Collectors.joining(","));
        player.getPersistentDataContainer().set(keys.research, PersistentDataType.STRING, serialized);
        return UnlockResult.UNLOCKED;
    }
}
