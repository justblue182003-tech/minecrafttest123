package dev.voidcore.research;

import org.bukkit.Material;

import java.util.List;

public enum ResearchNode {
    RESONANCE_THEORY(
        "resonance_theory", "Resonance Theory", 3, Material.AMETHYST_CLUSTER,
        "Understand why some materials remember energy.", List.of(),
        List.of(ResearchExperiment.DISCOVER_RESONANCE)
    ),
    FIELD_FABRICATION(
        "field_fabrication", "Field Fabrication", 4, Material.CRAFTING_TABLE,
        "Build controlled prototypes instead of relying on crude crafting grids.", List.of(RESONANCE_THEORY),
        List.of()
    ),
    FLUX_HANDLING(
        "flux_handling", "Flux Handling", 7, Material.REDSTONE_TORCH,
        "Contain unstable flux and operate the first powered machine.", List.of(FIELD_FABRICATION),
        List.of(ResearchExperiment.ASSEMBLE_COPPER_LATTICE)
    ),
    SPECTRAL_ANALYSIS(
        "spectral_analysis", "Spectral Analysis", 10, Material.SPYGLASS,
        "Measure resonance signatures instead of guessing at them.", List.of(FLUX_HANDLING),
        List.of(ResearchExperiment.STABILIZE_RESONANCE)
    ),
    HARMONIC_ENGINEERING(
        "harmonic_engineering", "Harmonic Engineering", 15, Material.NOTE_BLOCK,
        "Control phase relationships across interacting components.", List.of(SPECTRAL_ANALYSIS),
        List.of(ResearchExperiment.ANALYZE_RESONANCE)
    ),
    RESONANT_METALLURGY(
        "resonant_metallurgy", "Resonant Metallurgy", 20, Material.SMITHING_TABLE,
        "Bind stable resonance patterns into durable industrial materials.", List.of(HARMONIC_ENGINEERING),
        List.of(ResearchExperiment.BUILD_PROTOTYPE_CORE)
    ),
    THERMAL_ENGINEERING(
        "thermal_engineering", "Thermal Engineering", 24, Material.BLAST_FURNACE,
        "Control heat as a process variable instead of treating it as an on/off fuel state.", List.of(RESONANT_METALLURGY),
        List.of(ResearchExperiment.BUILD_FIELD_EMITTER, ResearchExperiment.BUILD_SPECTRAL_PLATE)
    ),
    CATALYTIC_MATRICES(
        "catalytic_matrices", "Catalytic Matrices", 30, Material.BREEZE_ROD,
        "Run reusable catalysts inside controlled thermal windows and manage surface contamination.", List.of(THERMAL_ENGINEERING),
        List.of(ResearchExperiment.HEAT_TREAT_MATRIX)
    ),
    THERMAL_INFRASTRUCTURE(
        "thermal_infrastructure", "Thermal Infrastructure", 36, Material.PACKED_ICE,
        "Treat cooling, heat recovery, multi-feed chemistry, and maintenance as one industrial system.", List.of(CATALYTIC_MATRICES),
        List.of(ResearchExperiment.RUN_CATALYTIC_REACTION, ResearchExperiment.PURIFY_CATALYST)
    ),
    QUANTUM_ROUTING(
        "quantum_routing", "Quantum Routing", 45, Material.ENDER_EYE,
        "Move energy and matter through addressable physical networks with measurable loss and bandwidth.", List.of(THERMAL_INFRASTRUCTURE),
        List.of(ResearchExperiment.PREPARE_REACTIVE_SLURRY, ResearchExperiment.CRYOGENIC_SEPARATION)
    ),
    PRESSURE_DYNAMICS(
        "pressure_dynamics", "Pressure Dynamics", 55, Material.HEAVY_WEIGHTED_PRESSURE_PLATE,
        "Control compression, seal integrity, and coupled heat-pressure process envelopes.", List.of(QUANTUM_ROUTING),
        List.of(ResearchExperiment.PRIORITY_ROUTE, ResearchExperiment.FREQUENCY_BRIDGE)
    ),
    ENTROPY_CONDENSATION(
        "entropy_condensation", "Entropy Condensation", 68, Material.SCULK_CATALYST,
        "Capture process entropy, reclaim waste, and prevent unmanaged decay from cascading through machinery.", List.of(PRESSURE_DYNAMICS),
        List.of(ResearchExperiment.PRESSURE_SYNTHESIS, ResearchExperiment.FAULT_RECOVERY)
    ),
    OBSERVATIONAL_COMPUTATION(
        "observational_computation", "Observational Computation", 78, Material.DAYLIGHT_DETECTOR,
        "Turn environmental measurements into a routable computation budget for industrial inference.", List.of(ENTROPY_CONDENSATION),
        List.of(ResearchExperiment.RECLAIM_WASTE, ResearchExperiment.STABLE_OBSERVATION)
    ),
    SPATIAL_ENGINEERING(
        "spatial_engineering", "Spatial Engineering", 92, Material.LODESTONE,
        "Treat machine placement, interference, and local coherence as measurable engineering variables.", List.of(OBSERVATIONAL_COMPUTATION),
        List.of(ResearchExperiment.ASSEMBLE_CONDENSER_ARRAY, ResearchExperiment.PROGRAM_OBSERVER)
    ),
    SINGULARITY_CONTAINMENT(
        "singularity_containment", "Singularity Containment", 110, Material.NETHER_STAR,
        "Coordinate factory-wide policy and stabilize field-sensitive reactions before they become incidents.", List.of(SPATIAL_ENGINEERING),
        List.of(ResearchExperiment.ENVIRONMENTAL_PROCESS, ResearchExperiment.BROADCAST_CONTROL, ResearchExperiment.FIELD_CALIBRATION)
    ),
    VOID_CORE_ARCHITECTURE(
        "void_core_architecture", "Void-Core Architecture", 135, Material.CRYING_OBSIDIAN,
        "Build a large containment lattice that converts computation, entropy, and spatial stability into endgame matter.", List.of(SINGULARITY_CONTAINMENT),
        List.of(ResearchExperiment.PRODUCTION_HISTORY, ResearchExperiment.ENTROPY_CHAIN_RECOVERY)
    ),
    AUTOMATION_ARCHITECTURE(
        "automation_architecture", "Automation Architecture", 155, Material.COMPARATOR,
        "Coordinate machine groups with condition-driven signal channels and remote industrial operations.", List.of(VOID_CORE_ARCHITECTURE),
        List.of(ResearchExperiment.STABLE_VOID_CORE_RUN, ResearchExperiment.FIELD_VISUALIZATION)
    ),
    DIMENSIONAL_INFRASTRUCTURE(
        "dimensional_infrastructure", "Dimensional Infrastructure", 180, Material.LODESTONE,
        "Extend physical Phase networks through paired dimensional anchors and refine bounded singularities into addressable kernels.", List.of(AUTOMATION_ARCHITECTURE),
        List.of(ResearchExperiment.SIGNAL_AUTOMATION, ResearchExperiment.REMOTE_OPERATIONS, ResearchExperiment.CORE_UPGRADE)
    ),
    ASCENDANT_ENGINEERING(
        "ascendant_engineering", "Ascendant Engineering", 220, Material.BEACON,
        "Commission infrastructure whose objective spans the whole server rather than one machine or one dimension.", List.of(DIMENSIONAL_INFRASTRUCTURE),
        List.of(ResearchExperiment.DIMENSIONAL_LINK, ResearchExperiment.REFINE_VOID_SEED, ResearchExperiment.PROJECT_NULLSTAR)
    );

    private final String id;
    private final String displayName;
    private final int cost;
    private final Material icon;
    private final String description;
    private final List<ResearchNode> prerequisites;
    private final List<ResearchExperiment> experiments;

    ResearchNode(String id, String displayName, int cost, Material icon, String description,
                 List<ResearchNode> prerequisites, List<ResearchExperiment> experiments) {
        this.id = id;
        this.displayName = displayName;
        this.cost = cost;
        this.icon = icon;
        this.description = description;
        this.prerequisites = prerequisites;
        this.experiments = experiments;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public int cost() { return cost; }
    public Material icon() { return icon; }
    public String description() { return description; }
    public List<ResearchNode> prerequisites() { return prerequisites; }
    public List<ResearchExperiment> experiments() { return experiments; }

    public static ResearchNode fromId(String id) {
        if (id == null) return null;
        for (ResearchNode node : values()) if (node.id.equalsIgnoreCase(id)) return node;
        return null;
    }
}
