package dev.voidcore.research;

import dev.voidcore.Keys;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ExperimentService {
    private final Keys keys;

    public ExperimentService(Keys keys) {
        this.keys = keys;
    }

    public int progress(Player player, ResearchExperiment experiment) {
        return Math.min(experiment.target(), progressMap(player).getOrDefault(experiment.id(), 0));
    }

    public boolean isComplete(Player player, ResearchExperiment experiment) {
        return progress(player, experiment) >= experiment.target();
    }

    public boolean advance(Player player, ResearchExperiment experiment) {
        return advance(player, experiment, 1);
    }

    public boolean advance(Player player, ResearchExperiment experiment, int amount) {
        if (amount <= 0 || isComplete(player, experiment)) return false;
        Map<String, Integer> progress = progressMap(player);
        int before = progress.getOrDefault(experiment.id(), 0);
        int after = Math.min(experiment.target(), before + amount);
        progress.put(experiment.id(), after);
        save(player, progress);

        if (after >= experiment.target() && before < experiment.target()) {
            PersistentDataContainer pdc = player.getPersistentDataContainer();
            int insight = pdc.getOrDefault(keys.insight, PersistentDataType.INTEGER, 0);
            pdc.set(keys.insight, PersistentDataType.INTEGER, Math.max(0, insight + experiment.insightReward()));
            player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_CLUSTER_HIT, 0.7f, 1.8f);
            player.sendMessage(Component.text("Experiment complete: ", NamedTextColor.GREEN)
                .append(Component.text(experiment.displayName(), NamedTextColor.LIGHT_PURPLE)));
            player.sendActionBar(Text.accent("+" + experiment.insightReward() + " Insight • experiment completed"));
            return true;
        }
        return false;
    }

    private Map<String, Integer> progressMap(Player player) {
        Map<String, Integer> result = new LinkedHashMap<>();
        String raw = player.getPersistentDataContainer().get(keys.experimentProgress, PersistentDataType.STRING);
        if (raw == null || raw.isBlank()) return result;
        for (String part : raw.split(";")) {
            String[] pair = part.split("=", 2);
            if (pair.length != 2) continue;
            try {
                result.put(pair[0], Math.max(0, Integer.parseInt(pair[1])));
            } catch (NumberFormatException ignored) {
            }
        }
        return result;
    }

    private void save(Player player, Map<String, Integer> progress) {
        String serialized = progress.entrySet().stream()
            .map(entry -> entry.getKey() + "=" + entry.getValue())
            .reduce((a, b) -> a + ";" + b)
            .orElse("");
        player.getPersistentDataContainer().set(keys.experimentProgress, PersistentDataType.STRING, serialized);
    }
}
