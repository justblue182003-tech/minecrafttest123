package dev.voidcore.recipe;

import dev.voidcore.item.CustomItem;
import dev.voidcore.research.ResearchNode;

import java.util.List;

public record VoidRecipe(
    String id,
    CustomItem output,
    int outputAmount,
    RecipeStation station,
    ResearchNode research,
    List<RecipeIngredient> ingredients,
    String description
) {
    public VoidRecipe {
        ingredients = List.copyOf(ingredients);
    }
}
