package dev.voidcore.recipe;

import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchService;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public final class RecipeCraftingService {
    public enum CraftResult { CRAFTED, LOCKED_RESEARCH, MISSING_INGREDIENTS }

    private final ItemService items;
    private final ResearchService research;
    private final ExperimentService experiments;
    private final DiscoveryService discoveries;

    public RecipeCraftingService(ItemService items, ResearchService research, ExperimentService experiments, DiscoveryService discoveries) {
        this.items = items;
        this.research = research;
        this.experiments = experiments;
        this.discoveries = discoveries;
    }

    public boolean canCraft(Player player, VoidRecipe recipe) {
        if (recipe.research() != null && !research.isUnlocked(player, recipe.research())) return false;
        for (RecipeIngredient ingredient : recipe.ingredients()) if (count(player, ingredient) < ingredient.amount()) return false;
        return true;
    }

    public CraftResult craftOne(Player player, VoidRecipe recipe) {
        if (recipe.research() != null && !research.isUnlocked(player, recipe.research())) return CraftResult.LOCKED_RESEARCH;
        for (RecipeIngredient ingredient : recipe.ingredients()) if (count(player, ingredient) < ingredient.amount()) return CraftResult.MISSING_INGREDIENTS;

        int outputQuality = calculateQuality(player, recipe);
        for (RecipeIngredient ingredient : recipe.ingredients()) remove(player, ingredient, ingredient.amount());

        ItemStack output = qualityBearing(recipe.output())
            ? items.createWithQuality(recipe.output(), recipe.outputAmount(), outputQuality)
            : items.create(recipe.output(), recipe.outputAmount());
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(output);
        overflow.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
        discoveries.discover(player, recipe.output());
        advanceExperiment(player, recipe.output());
        return CraftResult.CRAFTED;
    }

    public int craftBatch(Player player, VoidRecipe recipe, int maximum) {
        int crafted = 0;
        int limit = Math.max(1, Math.min(64, maximum));
        while (crafted < limit && craftOne(player, recipe) == CraftResult.CRAFTED) crafted++;
        return crafted;
    }

    public int count(Player player, RecipeIngredient ingredient) {
        int total = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) if (matches(stack, ingredient)) total += stack.getAmount();
        return total;
    }

    private int calculateQuality(Player player, VoidRecipe recipe) {
        double total = 0.0;
        int weighted = 0;
        for (RecipeIngredient ingredient : recipe.ingredients()) {
            if (ingredient.customItem() == null) continue;
            int remaining = ingredient.amount();
            for (ItemStack stack : player.getInventory().getStorageContents()) {
                if (!matches(stack, ingredient)) continue;
                int used = Math.min(remaining, stack.getAmount());
                total += items.quality(stack) * used;
                weighted += used;
                remaining -= used;
                if (remaining <= 0) break;
            }
        }
        double source = weighted == 0 ? 50.0 : total / weighted;
        int variance = ThreadLocalRandom.current().nextInt(-6, 7);
        return Math.max(1, Math.min(100, (int) Math.round(35.0 + source * 0.55 + variance)));
    }

    private boolean qualityBearing(CustomItem item) {
        return item.category() == CustomItem.Category.COMPONENT
            || item.category() == CustomItem.Category.UPGRADE
            || item.category() == CustomItem.Category.MACHINE;
    }

    private void remove(Player player, RecipeIngredient ingredient, int amount) {
        ItemStack[] contents = player.getInventory().getStorageContents();
        int remaining = amount;
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack stack = contents[i];
            if (!matches(stack, ingredient)) continue;
            int take = Math.min(stack.getAmount(), remaining);
            stack.setAmount(stack.getAmount() - take);
            if (stack.getAmount() <= 0) contents[i] = null;
            remaining -= take;
        }
        player.getInventory().setStorageContents(contents);
    }

    private boolean matches(ItemStack stack, RecipeIngredient ingredient) {
        if (stack == null || stack.getType().isAir()) return false;
        if (ingredient.customItem() != null) return items.is(stack, ingredient.customItem());
        return stack.getType() == ingredient.material() && items.identify(stack) == null;
    }

    private void advanceExperiment(Player player, CustomItem output) {
        switch (output) {
            case COPPER_LATTICE -> experiments.advance(player, ResearchExperiment.ASSEMBLE_COPPER_LATTICE);
            case PROTOTYPE_CORE -> experiments.advance(player, ResearchExperiment.BUILD_PROTOTYPE_CORE);
            case FIELD_EMITTER -> experiments.advance(player, ResearchExperiment.BUILD_FIELD_EMITTER);
            case SPECTRAL_PLATE -> experiments.advance(player, ResearchExperiment.BUILD_SPECTRAL_PLATE);
            default -> { }
        }
    }
}
