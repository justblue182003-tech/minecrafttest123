package dev.voidcore.recipe;

import dev.voidcore.item.CustomItem;
import dev.voidcore.research.ResearchNode;
import dev.voidcore.process.ProcessRecipe;
import dev.voidcore.process.ProcessRegistry;
import dev.voidcore.machine.MachineType;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static dev.voidcore.recipe.RecipeIngredient.custom;
import static dev.voidcore.recipe.RecipeIngredient.vanilla;

public final class RecipeRegistry {
    private final List<VoidRecipe> recipes = new ArrayList<>();

    public RecipeRegistry(ProcessRegistry processRegistry) {
        recipes.add(new VoidRecipe("void_codex", CustomItem.VOID_CODEX, 1, RecipeStation.VANILLA_CRAFTING, null,
            List.of(vanilla(Material.AMETHYST_SHARD, 2), vanilla(Material.BOOK, 1), vanilla(Material.COMPASS, 2)),
            "A portable interface to research, materials, experiments, and recipes."));
        recipes.add(new VoidRecipe("prototype_bench", CustomItem.PROTOTYPE_BENCH, 1, RecipeStation.VANILLA_CRAFTING, ResearchNode.FIELD_FABRICATION,
            List.of(vanilla(Material.COPPER_INGOT, 4), vanilla(Material.IRON_INGOT, 3), vanilla(Material.CRAFTING_TABLE, 1), custom(CustomItem.RESONANT_FRAGMENT, 1)),
            "The controlled assembly surface used for all serious Tier-I fabrication."));

        addBench("copper_lattice", CustomItem.COPPER_LATTICE, 2, ResearchNode.FIELD_FABRICATION,
            "Woven copper that carries resonance with lower leakage.", vanilla(Material.COPPER_INGOT, 4), vanilla(Material.STRING, 2));
        addBench("signal_filament", CustomItem.SIGNAL_FILAMENT, 3, ResearchNode.FIELD_FABRICATION,
            "Fine low-power conductor for sensors and feedback circuits.", custom(CustomItem.COPPER_LATTICE, 1), vanilla(Material.REDSTONE, 2), vanilla(Material.STRING, 2));
        addBench("damping_plate", CustomItem.DAMPING_PLATE, 1, ResearchNode.FIELD_FABRICATION,
            "Mechanical isolation plate for unstable prototypes.", vanilla(Material.IRON_INGOT, 3), vanilla(Material.WHITE_WOOL, 1), custom(CustomItem.COPPER_LATTICE, 1));
        addBench("calibration_weight", CustomItem.CALIBRATION_WEIGHT, 1, ResearchNode.FIELD_FABRICATION,
            "Reference mass for validating prototype tolerances.", vanilla(Material.IRON_INGOT, 4), vanilla(Material.COPPER_INGOT, 2));
        addBench("void_solder", CustomItem.VOID_SOLDER, 4, ResearchNode.FIELD_FABRICATION,
            "Conductive solder that tolerates weak resonance fields.", vanilla(Material.GOLD_NUGGET, 4), vanilla(Material.REDSTONE, 2), vanilla(Material.AMETHYST_SHARD, 1));
        addBench("insulated_casing", CustomItem.INSULATED_CASING, 1, ResearchNode.FIELD_FABRICATION,
            "Shielded enclosure that keeps early devices from coupling to each other.", vanilla(Material.IRON_INGOT, 2), custom(CustomItem.COPPER_LATTICE, 2), vanilla(Material.LEATHER, 2));
        addBench("tuning_fork", CustomItem.TUNING_FORK, 1, ResearchNode.FIELD_FABRICATION,
            "A simple physical resonance standard.", vanilla(Material.COPPER_INGOT, 2), vanilla(Material.AMETHYST_SHARD, 1), custom(CustomItem.VOID_SOLDER, 1));
        addBench("machine_frame", CustomItem.MACHINE_FRAME, 1, ResearchNode.FIELD_FABRICATION,
            "Common reinforced chassis for Tier-I machines.", vanilla(Material.IRON_INGOT, 4), custom(CustomItem.INSULATED_CASING, 2), custom(CustomItem.DAMPING_PLATE, 2));
        addBench("flux_crucible", CustomItem.FLUX_CRUCIBLE, 1, ResearchNode.FLUX_HANDLING,
            "First powered processor: stabilizes Resonant Fragments into Charged Resonance.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.SIGNAL_FILAMENT, 2), custom(CustomItem.RESONANT_FRAGMENT, 2), vanilla(Material.REDSTONE_BLOCK, 1));
        addBench("flux_coil", CustomItem.FLUX_COIL, 1, ResearchNode.FLUX_HANDLING,
            "Stores and redirects conditioned flux.", custom(CustomItem.COPPER_LATTICE, 2), custom(CustomItem.CHARGED_RESONANCE, 1), vanilla(Material.REDSTONE, 4), custom(CustomItem.VOID_SOLDER, 2));
        addBench("resonance_cell", CustomItem.RESONANCE_CELL, 1, ResearchNode.FLUX_HANDLING,
            "Compact local reserve for resonance-sensitive devices.", custom(CustomItem.FLUX_COIL, 1), custom(CustomItem.CHARGED_RESONANCE, 2), vanilla(Material.QUARTZ, 2), custom(CustomItem.INSULATED_CASING, 1));
        addBench("resonant_conduit", CustomItem.RESONANT_CONDUIT, 2, ResearchNode.FLUX_HANDLING,
            "Short-range conditioned flux path.", custom(CustomItem.SIGNAL_FILAMENT, 2), custom(CustomItem.CHARGED_RESONANCE, 1), vanilla(Material.COPPER_INGOT, 2));
        addBench("analysis_prism", CustomItem.ANALYSIS_PRISM, 1, ResearchNode.SPECTRAL_ANALYSIS,
            "Separates resonance into measurable response bands.", vanilla(Material.AMETHYST_SHARD, 4), vanilla(Material.GLASS, 2), custom(CustomItem.CHARGED_RESONANCE, 1));
        addBench("coherent_dust", CustomItem.COHERENT_DUST, 2, ResearchNode.SPECTRAL_ANALYSIS,
            "Particulate matter synchronized to a shared oscillation.", custom(CustomItem.CHARGED_RESONANCE, 1), vanilla(Material.QUARTZ, 2), vanilla(Material.GLOWSTONE_DUST, 2));
        addBench("spectrum_analyzer", CustomItem.SPECTRUM_ANALYZER, 1, ResearchNode.SPECTRAL_ANALYSIS,
            "Instrument for non-destructive material scans and research observations.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.ANALYSIS_PRISM, 1), custom(CustomItem.TUNING_FORK, 1), vanilla(Material.SPYGLASS, 1));
        addBench("phase_glass", CustomItem.PHASE_GLASS, 2, ResearchNode.HARMONIC_ENGINEERING,
            "Glass that preserves signal phase across optical boundaries.", vanilla(Material.TINTED_GLASS, 2), custom(CustomItem.COHERENT_DUST, 2), vanilla(Material.AMETHYST_SHARD, 2));
        addBench("harmonic_lens", CustomItem.HARMONIC_LENS, 1, ResearchNode.HARMONIC_ENGINEERING,
            "Precision optic for phase-aware devices.", custom(CustomItem.ANALYSIS_PRISM, 1), custom(CustomItem.TUNING_FORK, 1), custom(CustomItem.PHASE_GLASS, 1));
        addBench("stabilized_matrix", CustomItem.STABILIZED_MATRIX, 1, ResearchNode.HARMONIC_ENGINEERING,
            "Structured substrate that resists phase collapse.", custom(CustomItem.CHARGED_RESONANCE, 2), custom(CustomItem.COPPER_LATTICE, 2), custom(CustomItem.COHERENT_DUST, 2));
        addBench("coherence_gel", CustomItem.COHERENCE_GEL, 2, ResearchNode.HARMONIC_ENGINEERING,
            "Viscoelastic contact medium for precision resonance assemblies.", vanilla(Material.SLIME_BALL, 2), custom(CustomItem.COHERENT_DUST, 2), vanilla(Material.HONEY_BOTTLE, 1));
        addBench("prototype_core", CustomItem.PROTOTYPE_CORE, 1, ResearchNode.HARMONIC_ENGINEERING,
            "Integrated control core that combines logic, buffering, and resonance stabilization.", custom(CustomItem.RESONANCE_CELL, 1), custom(CustomItem.STABILIZED_MATRIX, 1), vanilla(Material.COMPARATOR, 1), custom(CustomItem.COHERENCE_GEL, 1));
        addBench("harmonic_regulator", CustomItem.HARMONIC_REGULATOR, 1, ResearchNode.HARMONIC_ENGINEERING,
            "Feedback assembly for damping slow frequency drift.", custom(CustomItem.HARMONIC_LENS, 1), custom(CustomItem.SIGNAL_FILAMENT, 2), vanilla(Material.TARGET, 1), custom(CustomItem.COHERENCE_GEL, 1));
        addBench("resonant_alloy", CustomItem.RESONANT_ALLOY, 2, ResearchNode.RESONANT_METALLURGY,
            "Durable metal carrying a stable resonance pattern.", vanilla(Material.IRON_INGOT, 2), vanilla(Material.COPPER_INGOT, 2), custom(CustomItem.STABILIZED_MATRIX, 1), custom(CustomItem.VOID_SOLDER, 2));
        addBench("field_emitter", CustomItem.FIELD_EMITTER, 1, ResearchNode.RESONANT_METALLURGY,
            "Projects an active controlled resonance field.", custom(CustomItem.FLUX_COIL, 1), custom(CustomItem.HARMONIC_LENS, 1), custom(CustomItem.RESONANT_ALLOY, 2), custom(CustomItem.PROTOTYPE_CORE, 1));
        addBench("spectral_plate", CustomItem.SPECTRAL_PLATE, 1, ResearchNode.RESONANT_METALLURGY,
            "High-resolution layered sensor surface.", custom(CustomItem.PHASE_GLASS, 2), custom(CustomItem.ANALYSIS_PRISM, 1), custom(CustomItem.RESONANT_ALLOY, 1), custom(CustomItem.COHERENT_DUST, 2));

        addBench("ceramic_insulator", CustomItem.CERAMIC_INSULATOR, 2, ResearchNode.THERMAL_ENGINEERING,
            "Refractory dielectric used around high-temperature process chambers.", vanilla(Material.NETHER_BRICK, 4), vanilla(Material.QUARTZ, 2), custom(CustomItem.VOID_SOLDER, 1));
        addBench("pyrogel", CustomItem.PYROGEL, 2, ResearchNode.THERMAL_ENGINEERING,
            "Controlled thermal interface compound for induction hardware.", vanilla(Material.MAGMA_CREAM, 2), custom(CustomItem.COHERENCE_GEL, 1), vanilla(Material.BLAZE_POWDER, 2));
        addBench("induction_heater", CustomItem.INDUCTION_HEATER, 1, ResearchNode.THERMAL_ENGINEERING,
            "Tier-II heat-treatment machine with persistent thermal inertia and adjustable target temperature.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.FLUX_COIL, 2), custom(CustomItem.CERAMIC_INSULATOR, 2), custom(CustomItem.PYROGEL, 1), custom(CustomItem.HARMONIC_REGULATOR, 1));
        addBench("thermal_coupler", CustomItem.THERMAL_COUPLER, 1, ResearchNode.THERMAL_ENGINEERING,
            "Upgrade module that increases machine heating response.", custom(CustomItem.PYROGEL, 1), custom(CustomItem.FLUX_COIL, 1), custom(CustomItem.CERAMIC_INSULATOR, 1));
        addBench("speed_governor", CustomItem.SPEED_GOVERNOR, 1, ResearchNode.THERMAL_ENGINEERING,
            "Upgrade module that increases process throughput.", custom(CustomItem.HARMONIC_REGULATOR, 1), custom(CustomItem.SIGNAL_FILAMENT, 2), vanilla(Material.REPEATER, 1));
        addBench("flux_regulator", CustomItem.FLUX_REGULATOR, 1, ResearchNode.THERMAL_ENGINEERING,
            "Upgrade module that reduces process flux losses.", custom(CustomItem.FLUX_COIL, 1), custom(CustomItem.RESONANCE_CELL, 1), vanilla(Material.COMPARATOR, 1));
        addBench("catalyst_matrix", CustomItem.CATALYST_MATRIX, 1, ResearchNode.CATALYTIC_MATRICES,
            "Reusable reaction surface. It carries immutable engineering quality and mutable contamination.", custom(CustomItem.STABILIZED_MATRIX, 1), custom(CustomItem.SPECTRAL_PLATE, 1), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 1), custom(CustomItem.COHERENCE_GEL, 2));
        addBench("catalyst_filter", CustomItem.CATALYST_FILTER, 1, ResearchNode.CATALYTIC_MATRICES,
            "Upgrade module that slows catalyst contamination growth.", custom(CustomItem.SPECTRAL_PLATE, 1), custom(CustomItem.CERAMIC_INSULATOR, 1), vanilla(Material.HOPPER, 1));
        addBench("catalytic_reactor", CustomItem.CATALYTIC_REACTOR, 1, ResearchNode.CATALYTIC_MATRICES,
            "Heated reusable-catalyst processor. Throughput falls as the catalyst surface fouls.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 2), custom(CustomItem.FIELD_EMITTER, 1), custom(CustomItem.HARMONIC_REGULATOR, 1), custom(CustomItem.CERAMIC_INSULATOR, 2));
        addBench("matrix_purifier", CustomItem.MATRIX_PURIFIER, 1, ResearchNode.CATALYTIC_MATRICES,
            "Restores catalyst activity without rerolling catalyst quality.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.SPECTRAL_PLATE, 2), custom(CustomItem.RESONANCE_CELL, 1), custom(CustomItem.CERAMIC_INSULATOR, 2), custom(CustomItem.COHERENCE_GEL, 2));
        addBench("cryo_salt", CustomItem.CRYO_SALT, 3, ResearchNode.THERMAL_INFRASTRUCTURE,
            "Endothermic process salt for active low-temperature separation.", vanilla(Material.PACKED_ICE, 3), vanilla(Material.QUARTZ, 2), custom(CustomItem.COHERENT_DUST, 1));
        addBench("maintenance_kit", CustomItem.MAINTENANCE_KIT, 2, ResearchNode.THERMAL_INFRASTRUCTURE,
            "Consumable service pack that restores machine service life without resetting quality.", vanilla(Material.IRON_NUGGET, 6), custom(CustomItem.VOID_SOLDER, 2), custom(CustomItem.CALIBRATION_WEIGHT, 1), custom(CustomItem.COHERENCE_GEL, 1));
        addBench("cooling_jacket", CustomItem.COOLING_JACKET, 1, ResearchNode.THERMAL_INFRASTRUCTURE,
            "Upgrade module that increases active heat extraction below ambient.", custom(CustomItem.CRYO_SALT, 2), custom(CustomItem.CERAMIC_INSULATOR, 2), custom(CustomItem.FLUX_COIL, 1), vanilla(Material.PACKED_ICE, 2));
        addBench("cryogenic_column", CustomItem.CRYOGENIC_COLUMN, 1, ResearchNode.THERMAL_INFRASTRUCTURE,
            "Two-feed low-temperature separator with active cooling and persistent thermal inertia.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 2), custom(CustomItem.CERAMIC_INSULATOR, 3), custom(CustomItem.FLUX_COIL, 2), custom(CustomItem.SPECTRAL_PLATE, 1));
        addBench("thermal_exchanger", CustomItem.THERMAL_EXCHANGER, 1, ResearchNode.THERMAL_INFRASTRUCTURE,
            "Recovers waste heat between adjacent process machines instead of destroying it.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 2), custom(CustomItem.PYROGEL, 2), custom(CustomItem.COPPER_LATTICE, 3), custom(CustomItem.HARMONIC_REGULATOR, 1));

        addBench("address_crystal", CustomItem.ADDRESS_CRYSTAL, 1, ResearchNode.QUANTUM_ROUTING,
            "Stable identifier crystal for Phase Logistics endpoints.", custom(CustomItem.PURIFIED_MATRIX, 1), custom(CustomItem.HARMONIC_LENS, 1), vanilla(Material.ENDER_EYE, 1), custom(CustomItem.COHERENT_DUST, 2));
        addBench("phase_interface", CustomItem.PHASE_INTERFACE, 1, ResearchNode.QUANTUM_ROUTING,
            "Upgrade module that exposes machine item ports to automatic graph routing.", custom(CustomItem.ADDRESS_CRYSTAL, 1), custom(CustomItem.PHASE_THREAD, 2), custom(CustomItem.SIGNAL_FILAMENT, 2), custom(CustomItem.VOID_SOLDER, 2));
        addBench("flux_bus", CustomItem.FLUX_BUS, 4, ResearchNode.QUANTUM_ROUTING,
            "Physical network edge carrying shared flux and routed item traffic.", custom(CustomItem.RESONANT_CONDUIT, 2), custom(CustomItem.PHASE_THREAD, 2), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 1), vanilla(Material.COPPER_INGOT, 3));
        addBench("address_node", CustomItem.ADDRESS_NODE, 1, ResearchNode.QUANTUM_ROUTING,
            "Frequency anchor and diagnostic access point for a Flux Bus graph.", custom(CustomItem.ADDRESS_CRYSTAL, 1), custom(CustomItem.PURIFIED_MATRIX, 1), custom(CustomItem.PHASE_THREAD, 2), custom(CustomItem.PROTOTYPE_CORE, 1), vanilla(Material.COPPER_BLOCK, 1));
        addBench("routing_core", CustomItem.ROUTING_CORE, 1, ResearchNode.QUANTUM_ROUTING,
            "Deterministic controller for route policy and frequency bridge logic.", custom(CustomItem.ADDRESS_CRYSTAL, 1), custom(CustomItem.PURIFIED_MATRIX, 1), custom(CustomItem.PROTOTYPE_CORE, 1), vanilla(Material.COMPARATOR, 2));
        addBench("filter_matrix", CustomItem.FILTER_MATRIX, 1, ResearchNode.QUANTUM_ROUTING,
            "Programmable matter-signature discriminator used by routing policy nodes.", custom(CustomItem.SPECTRAL_PLATE, 1), custom(CustomItem.PHASE_THREAD, 1), vanilla(Material.MAP, 1), custom(CustomItem.COHERENT_DUST, 2));
        addBench("phase_router", CustomItem.PHASE_ROUTER, 1, ResearchNode.QUANTUM_ROUTING,
            "Applies priority and material filtering to an endpoint directly attached to it.", custom(CustomItem.ROUTING_CORE, 1), custom(CustomItem.FILTER_MATRIX, 1), custom(CustomItem.PHASE_THREAD, 2), vanilla(Material.CRAFTER, 1));
        addBench("priority_buffer", CustomItem.PRIORITY_BUFFER, 1, ResearchNode.QUANTUM_ROUTING,
            "Network-visible staging inventory that can absorb and re-emit routed outputs.", custom(CustomItem.ROUTING_CORE, 1), custom(CustomItem.PURIFIED_MATRIX, 1), custom(CustomItem.PHASE_THREAD, 2), vanilla(Material.CHEST, 1));
        addBench("frequency_splitter", CustomItem.FREQUENCY_SPLITTER, 1, ResearchNode.QUANTUM_ROUTING,
            "Bridges two isolated frequency domains while preserving physical route loss.", custom(CustomItem.ROUTING_CORE, 1), custom(CustomItem.ADDRESS_CRYSTAL, 2), custom(CustomItem.PHASE_THREAD, 3), vanilla(Material.COPPER_BLOCK, 2));

        addBench("observation_crystal", CustomItem.OBSERVATION_CRYSTAL, 1, ResearchNode.ENTROPY_CONDENSATION,
            "A phase-stable optical memory used to correlate environmental observations.", custom(CustomItem.PURIFIED_MATRIX, 1), custom(CustomItem.PHASE_GLASS, 2), custom(CustomItem.COHERENT_DUST, 2), vanilla(Material.AMETHYST_CLUSTER, 1));
        addBench("computation_core", CustomItem.COMPUTATION_CORE, 1, ResearchNode.ENTROPY_CONDENSATION,
            "A deterministic inference core that buffers observation-derived computation.", custom(CustomItem.PROTOTYPE_CORE, 1), custom(CustomItem.OBSERVATION_CRYSTAL, 1), custom(CustomItem.PHASE_THREAD, 2), vanilla(Material.DAYLIGHT_DETECTOR, 1));
        addBench("coherence_damper", CustomItem.COHERENCE_DAMPER, 1, ResearchNode.ENTROPY_CONDENSATION,
            "Replacement damping lattice for low-stage entropy drift faults.", custom(CustomItem.COMPUTATION_CORE, 1), custom(CustomItem.COHERENCE_GEL, 2), custom(CustomItem.SPECTRAL_PLATE, 1), vanilla(Material.CALIBRATED_SCULK_SENSOR, 1));
        addBench("containment_fuse", CustomItem.CONTAINMENT_FUSE, 2, ResearchNode.ENTROPY_CONDENSATION,
            "Sacrificial hard-fault part that arrests entropy surges and containment breaches.", custom(CustomItem.COHERENCE_DAMPER, 1), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 1), vanilla(Material.FIREWORK_STAR, 2), vanilla(Material.REDSTONE_BLOCK, 1));
        addBench("phase_observer", CustomItem.PHASE_OBSERVER, 1, ResearchNode.ENTROPY_CONDENSATION,
            "Powered environmental observer. Open sky, night, sculk fields, and dimensions change computation yield.", custom(CustomItem.COMPUTATION_CORE, 1), custom(CustomItem.OBSERVATION_CRYSTAL, 2), custom(CustomItem.PHASE_THREAD, 2), custom(CustomItem.FLUX_COIL, 1), vanilla(Material.OBSERVER, 1));
        addBench("entropy_condenser", CustomItem.ENTROPY_CONDENSER, 1, ResearchNode.ENTROPY_CONDENSATION,
            "Controller for the 17-block Entropy Condenser Array. Build its blackstone/copper/amethyst/glass crown around the controller before processing.", custom(CustomItem.DENSE_PHASE_COMPOSITE, 2), custom(CustomItem.COMPUTATION_CORE, 2), custom(CustomItem.FIELD_EMITTER, 2), custom(CustomItem.CONTAINMENT_FUSE, 2), vanilla(Material.BEACON, 1));
        addBench("recovered_cryo_salt", CustomItem.CRYO_SALT, 3, ResearchNode.ENTROPY_CONDENSATION,
            "Close part of the industrial waste loop by reconditioning recovered feedstock into cryogenic process salt.", custom(CustomItem.RECOVERED_FEEDSTOCK, 2), vanilla(Material.PACKED_ICE, 2), vanilla(Material.QUARTZ, 1));
        addBench("recovered_pyrogel", CustomItem.PYROGEL, 2, ResearchNode.ENTROPY_CONDENSATION,
            "Recondition recovered feedstock into thermal coupling media instead of consuming only virgin reagents.", custom(CustomItem.RECOVERED_FEEDSTOCK, 2), vanilla(Material.MAGMA_CREAM, 1), custom(CustomItem.COHERENCE_GEL, 1));

        addBench("spatial_anchor", CustomItem.SPATIAL_ANCHOR, 1, ResearchNode.SPATIAL_ENGINEERING,
            "A precision reference mass that anchors nearby phase fields against industrial interference.", custom(CustomItem.CONTAINMENT_PLATE, 1), custom(CustomItem.HARMONIC_REGULATOR, 1), custom(CustomItem.OBSERVATION_CRYSTAL, 1), vanilla(Material.LODESTONE, 1));
        addBench("control_matrix_core", CustomItem.CONTROL_MATRIX_CORE, 1, ResearchNode.SPATIAL_ENGINEERING,
            "Deterministic policy core for factory-wide control broadcasts.", custom(CustomItem.COMPUTATION_CORE, 1), custom(CustomItem.ROUTING_CORE, 1), custom(CustomItem.OBSERVATION_CRYSTAL, 1), vanilla(Material.COMPARATOR, 2));
        addBench("field_stabilizer", CustomItem.FIELD_STABILIZER, 1, ResearchNode.SPATIAL_ENGINEERING,
            "Powered coherence projector that raises local field stability around sensitive production lines.", custom(CustomItem.SPATIAL_ANCHOR, 1), custom(CustomItem.FIELD_EMITTER, 2), custom(CustomItem.FLUX_COIL, 2), custom(CustomItem.MACHINE_FRAME, 1));
        addBench("control_matrix", CustomItem.CONTROL_MATRIX, 1, ResearchNode.SPATIAL_ENGINEERING,
            "Broadcasts Balanced, Throughput, Efficiency, or Stability policy across one physical Phase network.", custom(CustomItem.CONTROL_MATRIX_CORE, 1), custom(CustomItem.ROUTING_CORE, 1), custom(CustomItem.PHASE_THREAD, 2), vanilla(Material.REDSTONE_LAMP, 1));
        addBench("void_casing", CustomItem.VOID_CASING, 2, ResearchNode.SINGULARITY_CONTAINMENT,
            "Extreme containment shell for machinery operating near coherent singularity conditions.", custom(CustomItem.CONTAINMENT_PLATE, 2), custom(CustomItem.DENSE_PHASE_COMPOSITE, 1), custom(CustomItem.STABILIZED_CONDENSATE, 1), vanilla(Material.CRYING_OBSIDIAN, 1));
        addBench("void_core", CustomItem.VOID_CORE, 1, ResearchNode.VOID_CORE_ARCHITECTURE,
            "Controller for the 35-block Void Core lattice. It consumes computation, captured entropy, and a stable spatial field to synthesize Void Seeds.", custom(CustomItem.VOID_CASING, 4), custom(CustomItem.COMPUTATION_CORE, 2), custom(CustomItem.SPATIAL_ANCHOR, 2), vanilla(Material.NETHER_STAR, 1));

        addBench("logic_wafer", CustomItem.LOGIC_WAFER, 2, ResearchNode.AUTOMATION_ARCHITECTURE,
            "Condition-evaluation substrate for signal automation and remote operations.", custom(CustomItem.COMPUTATION_CORE, 1), custom(CustomItem.SIGNAL_FILAMENT, 3), custom(CustomItem.VOID_SOLDER, 2), vanilla(Material.QUARTZ, 2));
        addBench("signal_crystal", CustomItem.SIGNAL_CRYSTAL, 2, ResearchNode.AUTOMATION_ARCHITECTURE,
            "Boolean phase carrier addressable across sixteen network signal channels.", custom(CustomItem.OBSERVATION_CRYSTAL, 1), custom(CustomItem.COHERENT_DUST, 2), custom(CustomItem.SIGNAL_FILAMENT, 2), vanilla(Material.REDSTONE_TORCH, 1));
        addBench("automation_terminal", CustomItem.AUTOMATION_TERMINAL, 1, ResearchNode.AUTOMATION_ARCHITECTURE,
            "Remote operations terminal that evaluates group conditions and drives factory signal channels.", custom(CustomItem.LOGIC_WAFER, 2), custom(CustomItem.SIGNAL_CRYSTAL, 2), custom(CustomItem.CONTROL_MATRIX_CORE, 1), vanilla(Material.LECTERN, 1));
        addBench("void_upgrade_chamber", CustomItem.VOID_UPGRADE_CHAMBER, 1, ResearchNode.AUTOMATION_ARCHITECTURE,
            "Auxiliary Void Core chamber configurable for stabilization, compression, or extraction.", custom(CustomItem.VOID_CASING, 2), custom(CustomItem.SPATIAL_ANCHOR, 1), custom(CustomItem.CONTROL_MATRIX_CORE, 1), custom(CustomItem.FLUX_COIL, 2), vanilla(Material.RESPAWN_ANCHOR, 1));
        addBench("dimensional_anchor", CustomItem.DIMENSIONAL_ANCHOR, 1, ResearchNode.DIMENSIONAL_INFRASTRUCTURE,
            "Cross-dimensional Phase bridge. Matching loaded anchors require local computation on both sides to maintain the virtual edge.", custom(CustomItem.DIMENSIONAL_KERNEL, 1), custom(CustomItem.ROUTING_CORE, 2), custom(CustomItem.SPATIAL_ANCHOR, 1), custom(CustomItem.PHASE_THREAD, 4), vanilla(Material.LODESTONE, 1));
        addBench("project_terminal", CustomItem.PROJECT_TERMINAL, 1, ResearchNode.DIMENSIONAL_INFRASTRUCTURE,
            "Server-scale commissioning terminal for Project Nullstar.", custom(CustomItem.LOGIC_WAFER, 2), custom(CustomItem.DIMENSIONAL_KERNEL, 1), custom(CustomItem.COMPUTATION_CORE, 2), vanilla(Material.ENCHANTING_TABLE, 1));

        recipes.add(new VoidRecipe("project_nullstar", CustomItem.ASCENDANT_CORE, 1, RecipeStation.PROJECT_NULLSTAR, ResearchNode.DIMENSIONAL_INFRASTRUCTURE,
            List.of(custom(CustomItem.COMPRESSED_VOID_SEED, 3), custom(CustomItem.DIMENSIONAL_KERNEL, 1)),
            "Commissioning objective, not a normal consumptive craft. Requires mature server production history, a stable Void Core, and loaded dimensional infrastructure before the terminal authorizes an Ascendant Core."));

        addBench("repair_parts", CustomItem.REPAIR_PARTS, 2, ResearchNode.PRESSURE_DYNAMICS,
            "Replacement actuators and control parts for hard-fault recovery.", custom(CustomItem.TEMPERED_RESONANT_ALLOY, 1), custom(CustomItem.VOID_SOLDER, 2), custom(CustomItem.CALIBRATION_WEIGHT, 1), vanilla(Material.IRON_INGOT, 3));
        addBench("pressure_seal", CustomItem.PRESSURE_SEAL, 2, ResearchNode.PRESSURE_DYNAMICS,
            "Reinforced gasket used to build and repair pressure-bound process chambers.", custom(CustomItem.COHERENCE_GEL, 2), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 1), custom(CustomItem.CERAMIC_INSULATOR, 1), vanilla(Material.IRON_TRAPDOOR, 1));
        addBench("pressure_vessel", CustomItem.PRESSURE_VESSEL, 1, ResearchNode.PRESSURE_DYNAMICS,
            "Actively compresses thermochemical feeds and enforces a second process envelope alongside heat.", custom(CustomItem.MACHINE_FRAME, 1), custom(CustomItem.PRESSURE_SEAL, 2), custom(CustomItem.TEMPERED_RESONANT_ALLOY, 2), custom(CustomItem.FLUX_COIL, 2), custom(CustomItem.HARMONIC_REGULATOR, 1));

        recipes.add(new VoidRecipe("charged_resonance", CustomItem.CHARGED_RESONANCE, 1, RecipeStation.FLUX_CRUCIBLE, ResearchNode.FLUX_HANDLING,
            List.of(custom(CustomItem.RESONANT_FRAGMENT, 1), vanilla(Material.REDSTONE, 2)),
            "Feed a Resonant Fragment into a powered Flux Crucible. The listed redstone is the approximate energy equivalent."));

        for (ProcessRecipe process : processRegistry.all()) {
            List<RecipeIngredient> ingredients = new ArrayList<>();
            ingredients.add(custom(process.input(), process.inputAmount()));
            if (process.requiresSecondaryInput()) ingredients.add(custom(process.secondaryInput(), process.secondaryInputAmount()));
            if (process.requiresCatalyst()) ingredients.add(custom(process.catalyst(), 1));
            String byproduct = process.hasByproduct() ? " Byproduct: " + process.byproductAmount() + "× " + process.byproduct().displayName() + "." : "";
            recipes.add(new VoidRecipe("process_" + process.id(), process.output(), process.outputAmount(), station(process.machine()), process.research(),
                ingredients,
                process.description() + " Heat: " + (int) process.minimumHeat() + "–" + (int) process.maximumHeat() + "°C;"
                    + (process.usesPressure() ? " pressure: " + String.format(java.util.Locale.ROOT, "%.1f–%.1f bar;", process.minimumPressure(), process.maximumPressure()) : "")
                    + (process.environment().constrained() ? " environment: " + process.environment().displayName() + ";" : "")
                    + (process.requiresMultiblock() ? " complete multiblock required;" : "")
                    + (process.usesSpatialField() ? " field stability: >=" + (int) process.minimumFieldStability() + "%;" : "")
                    + (process.entropyCost() > 0 ? " entropy cost: " + String.format(java.util.Locale.ROOT, "%.1f;", process.entropyCost()) : "")
                    + (process.computationCost() > 0 ? " computation: " + process.computationCost() + ";" : "")
                    + (process.entropyGenerated() > 0 ? " entropy generated: " + String.format(java.util.Locale.ROOT, "%.1f;", process.entropyGenerated()) : "")
                    + " flux: " + process.fluxCost() + "; nominal cycle: " + (int) process.durationSeconds() + "s." + byproduct));
        }
    }

    private RecipeStation station(MachineType type) {
        return switch (type) {
            case INDUCTION_HEATER -> RecipeStation.INDUCTION_HEATER;
            case CATALYTIC_REACTOR -> RecipeStation.CATALYTIC_REACTOR;
            case MATRIX_PURIFIER -> RecipeStation.MATRIX_PURIFIER;
            case CRYOGENIC_COLUMN -> RecipeStation.CRYOGENIC_COLUMN;
            case PRESSURE_VESSEL -> RecipeStation.PRESSURE_VESSEL;
            case ENTROPY_CONDENSER -> RecipeStation.ENTROPY_CONDENSER;
            case VOID_CORE -> RecipeStation.VOID_CORE;
            default -> throw new IllegalArgumentException("No process station for " + type);
        };
    }

    private void addBench(String id, CustomItem output, int amount, ResearchNode research, String description, RecipeIngredient... ingredients) {
        recipes.add(new VoidRecipe(id, output, amount, RecipeStation.PROTOTYPE_BENCH, research, List.of(ingredients), description));
    }

    public List<VoidRecipe> all() {
        return Collections.unmodifiableList(recipes);
    }

    public List<VoidRecipe> forStation(RecipeStation station) {
        return recipes.stream().filter(recipe -> recipe.station() == station).toList();
    }

    public VoidRecipe byId(String id) {
        if (id == null) return null;
        return recipes.stream().filter(recipe -> recipe.id().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    public VoidRecipe producing(CustomItem item) {
        return recipes.stream().filter(recipe -> recipe.output() == item).findFirst().orElse(null);
    }
}
