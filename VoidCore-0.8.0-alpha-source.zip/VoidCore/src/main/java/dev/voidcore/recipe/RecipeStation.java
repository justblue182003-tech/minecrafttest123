package dev.voidcore.recipe;

public enum RecipeStation {
    VANILLA_CRAFTING("Crafting Table"),
    PROTOTYPE_BENCH("Prototype Bench"),
    FLUX_CRUCIBLE("Flux Crucible"),
    SPECTRUM_ANALYZER("Spectrum Analyzer"),
    INDUCTION_HEATER("Induction Heater"),
    CATALYTIC_REACTOR("Catalytic Reactor"),
    MATRIX_PURIFIER("Matrix Purifier"),
    CRYOGENIC_COLUMN("Cryogenic Column"),
    PRESSURE_VESSEL("Pressure Vessel"),
    ENTROPY_CONDENSER("Entropy Condenser Array"),
    VOID_CORE("Void Core"),
    PROJECT_NULLSTAR("Project Nullstar Terminal");

    private final String displayName;

    RecipeStation(String displayName) { this.displayName = displayName; }
    public String displayName() { return displayName; }
}
