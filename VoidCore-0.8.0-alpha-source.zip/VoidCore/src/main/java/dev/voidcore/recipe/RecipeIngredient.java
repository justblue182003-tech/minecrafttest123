package dev.voidcore.recipe;

import dev.voidcore.item.CustomItem;
import org.bukkit.Material;

public record RecipeIngredient(Material material, CustomItem customItem, int amount) {
    public RecipeIngredient {
        if ((material == null) == (customItem == null)) {
            throw new IllegalArgumentException("Ingredient must be either vanilla or custom, exclusively.");
        }
        if (amount < 1) throw new IllegalArgumentException("Ingredient amount must be positive.");
    }

    public static RecipeIngredient vanilla(Material material, int amount) {
        return new RecipeIngredient(material, null, amount);
    }

    public static RecipeIngredient custom(CustomItem item, int amount) {
        return new RecipeIngredient(null, item, amount);
    }

    public String displayName() {
        if (customItem != null) return customItem.displayName();
        String[] words = material.name().toLowerCase(java.util.Locale.ROOT).split("_");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }
}
