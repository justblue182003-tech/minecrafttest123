package dev.voidcore.process;

import dev.voidcore.item.CustomItem;
import dev.voidcore.machine.MachineType;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchNode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ProcessRegistry {
    private final List<ProcessRecipe> recipes = new ArrayList<>();

    public ProcessRegistry() {
        add("annealed_matrix", MachineType.INDUCTION_HEATER,
            CustomItem.STABILIZED_MATRIX, 1, null, 0, null,
            CustomItem.ANNEALED_MATRIX, 1, null, 0,
            18.0, 300, 520.0, 680.0, 0.0, 999.0, 0.0, 0.0, 0.9,
            ResearchNode.THERMAL_ENGINEERING, ResearchExperiment.HEAT_TREAT_MATRIX, ProcessMode.STANDARD,
            "Relax internal stress in a Stabilized Matrix. Quality peaks near the center of the allowed heat window.");

        add("tempered_resonant_alloy", MachineType.INDUCTION_HEATER,
            CustomItem.RESONANT_ALLOY, 1, null, 0, null,
            CustomItem.TEMPERED_RESONANT_ALLOY, 1, null, 0,
            24.0, 420, 700.0, 880.0, 0.0, 999.0, 0.0, 0.0, 1.1,
            ResearchNode.THERMAL_ENGINEERING, null, ProcessMode.STANDARD,
            "Heat-treat Resonant Alloy into a tougher Tier-II structural phase.");

        add("catalyzed_matrix", MachineType.CATALYTIC_REACTOR,
            CustomItem.ANNEALED_MATRIX, 1, null, 0, CustomItem.CATALYST_MATRIX,
            CustomItem.CATALYZED_MATRIX, 1, null, 0,
            26.0, 480, 430.0, 570.0, 0.0, 999.0, 8.0, 0.0, 1.2,
            ResearchNode.CATALYTIC_MATRICES, ResearchExperiment.RUN_CATALYTIC_REACTION, ProcessMode.STANDARD,
            "Activate an Annealed Matrix across a reusable Catalyst Matrix. Contamination reduces effective cycle speed.");

        add("purified_catalyst_matrix", MachineType.MATRIX_PURIFIER,
            CustomItem.CATALYST_MATRIX, 1, null, 0, null,
            CustomItem.CATALYST_MATRIX, 1, null, 0,
            20.0, 360, 180.0, 320.0, 0.0, 999.0, 0.0, 38.0, 0.7,
            ResearchNode.CATALYTIC_MATRICES, ResearchExperiment.PURIFY_CATALYST, ProcessMode.PURIFY_CATALYST,
            "Strip reaction products from a Catalyst Matrix without rerolling or destroying its engineering quality.");

        add("reactive_slurry", MachineType.CATALYTIC_REACTOR,
            CustomItem.CATALYZED_MATRIX, 1, CustomItem.COHERENCE_GEL, 1, CustomItem.CATALYST_MATRIX,
            CustomItem.REACTIVE_SLURRY, 2, CustomItem.THERMAL_RESIDUE, 1,
            34.0, 620, 470.0, 610.0, 0.0, 999.0, 12.0, 0.0, 1.7,
            ResearchNode.THERMAL_INFRASTRUCTURE, ResearchExperiment.PREPARE_REACTIVE_SLURRY, ProcessMode.STANDARD,
            "Couple a catalyzed matrix with Coherence Gel. This is the first true two-feed reaction and creates a waste stream.");

        add("superheated_phase_glass", MachineType.INDUCTION_HEATER,
            CustomItem.PHASE_GLASS, 2, CustomItem.PYROGEL, 1, null,
            CustomItem.SUPERHEATED_PHASE_GLASS, 2, CustomItem.THERMAL_RESIDUE, 1,
            30.0, 560, 760.0, 900.0, 0.0, 999.0, 0.0, 0.0, 1.5,
            ResearchNode.THERMAL_INFRASTRUCTURE, null, ProcessMode.STANDARD,
            "Drive Phase Glass into a high-energy structural state using Pyrogel as a sacrificial thermal coupling feed.");

        add("purified_matrix", MachineType.CRYOGENIC_COLUMN,
            CustomItem.REACTIVE_SLURRY, 2, CustomItem.CRYO_SALT, 1, null,
            CustomItem.PURIFIED_MATRIX, 1, CustomItem.THERMAL_RESIDUE, 1,
            40.0, 800, -125.0, -70.0, 0.0, 999.0, 0.0, 0.0, 2.0,
            ResearchNode.THERMAL_INFRASTRUCTURE, ResearchExperiment.CRYOGENIC_SEPARATION, ProcessMode.STANDARD,
            "Separate Reactive Slurry below ambient temperature. Cooling capacity, not heating power, is the primary bottleneck.");

        add("phase_thread", MachineType.CRYOGENIC_COLUMN,
            CustomItem.SUPERHEATED_PHASE_GLASS, 1, CustomItem.CRYO_SALT, 1, null,
            CustomItem.PHASE_THREAD, 2, CustomItem.THERMAL_RESIDUE, 1,
            32.0, 720, -95.0, -45.0, 0.0, 999.0, 0.0, 0.0, 1.8,
            ResearchNode.QUANTUM_ROUTING, null, ProcessMode.STANDARD,
            "Quench a phase-bearing glass state into flexible Phase Thread for network interfaces.");

        add("pressurized_matrix", MachineType.PRESSURE_VESSEL,
            CustomItem.PURIFIED_MATRIX, 1, CustomItem.COHERENCE_GEL, 1, null,
            CustomItem.PRESSURIZED_MATRIX, 1, CustomItem.THERMAL_RESIDUE, 1,
            38.0, 960, 180.0, 280.0, 4.5, 6.5, 0.0, 0.0, 2.4,
            ResearchNode.PRESSURE_DYNAMICS, ResearchExperiment.PRESSURE_SYNTHESIS, ProcessMode.STANDARD,
            "Compress a Purified Matrix while polymerized coherence media seals its internal voids. Both heat and pressure accuracy affect quality.");

        add("dense_phase_composite", MachineType.PRESSURE_VESSEL,
            CustomItem.PRESSURIZED_MATRIX, 1, CustomItem.TEMPERED_RESONANT_ALLOY, 1, null,
            CustomItem.DENSE_PHASE_COMPOSITE, 1, CustomItem.THERMAL_RESIDUE, 1,
            46.0, 1250, 310.0, 430.0, 7.0, 9.5, 0.0, 0.0, 3.1,
            ResearchNode.PRESSURE_DYNAMICS, null, ProcessMode.STANDARD,
            "Pressure-sinter a stabilized matrix into tempered alloy, creating the first entropy-era structural composite.");

        addAdvanced("waste_reclamation", MachineType.ENTROPY_CONDENSER,
            CustomItem.THERMAL_RESIDUE, 3, CustomItem.PRESSURIZED_MATRIX, 1, null,
            CustomItem.RECOVERED_FEEDSTOCK, 3, CustomItem.ENTROPY_CONDENSATE, 1,
            55.0, 1500, 90.0, 180.0, 0.0, 999.0, 0.0, 0.0, 2.8,
            0.0, 42.0, 100, ProcessEnvironment.ANY, true, 0.0,
            ResearchNode.ENTROPY_CONDENSATION, ResearchExperiment.RECLAIM_WASTE, ProcessMode.STANDARD,
            "Strip useful matter from Thermal Residue while a complete condenser array captures the displaced entropy into a stable condensate." );

        addAdvanced("void_tempered_containment_plate", MachineType.INDUCTION_HEATER,
            CustomItem.DENSE_PHASE_COMPOSITE, 1, CustomItem.ENTROPY_CONDENSATE, 1, null,
            CustomItem.CONTAINMENT_PLATE, 1, CustomItem.THERMAL_RESIDUE, 1,
            62.0, 1680, 840.0, 940.0, 0.0, 999.0, 0.0, 0.0, 3.5,
            14.0, 0.0, 0, ProcessEnvironment.END, false, 0.0,
            ResearchNode.OBSERVATIONAL_COMPUTATION, ResearchExperiment.ENVIRONMENTAL_PROCESS, ProcessMode.STANDARD,
            "Void-temper a dense composite in the End, where the external field lets entropy-bearing defects collapse into a containment-grade plate." );

        addAdvanced("stabilized_condensate", MachineType.ENTROPY_CONDENSER,
            CustomItem.ENTROPY_CONDENSATE, 2, CustomItem.OBSERVATION_CRYSTAL, 1, null,
            CustomItem.STABILIZED_CONDENSATE, 2, null, 0,
            58.0, 1900, 110.0, 190.0, 0.0, 999.0, 0.0, 0.0, 2.6,
            2.0, 24.0, 120, ProcessEnvironment.ANY, true, 80.0,
            ResearchNode.SPATIAL_ENGINEERING, ResearchExperiment.FIELD_CALIBRATION, ProcessMode.STANDARD,
            "Reorder captured entropy against an observation crystal while a stabilized local field prevents the condensate from decohering." );

        addAdvanced("void_seed", MachineType.VOID_CORE,
            CustomItem.STABILIZED_CONDENSATE, 3, CustomItem.CONTAINMENT_PLATE, 1, null,
            CustomItem.VOID_SEED, 1, CustomItem.THERMAL_RESIDUE, 2,
            92.0, 4800, 95.0, 175.0, 0.0, 999.0, 0.0, 0.0, 5.5,
            6.0, 120.0, 400, ProcessEnvironment.ANY, true, 82.0,
            ResearchNode.VOID_CORE_ARCHITECTURE, ResearchExperiment.STABLE_VOID_CORE_RUN, ProcessMode.STANDARD,
            "Shape a bounded phase singularity inside the complete Void Core lattice. Spatial field stability is a hard process condition, not a quality bonus." );

        addAdvanced("compressed_void_seed", MachineType.VOID_CORE,
            CustomItem.VOID_SEED, 1, CustomItem.STABILIZED_CONDENSATE, 2, null,
            CustomItem.COMPRESSED_VOID_SEED, 1, CustomItem.THERMAL_RESIDUE, 2,
            126.0, 6500, 120.0, 190.0, 0.0, 999.0, 0.0, 0.0, 7.0,
            10.0, 180.0, 650, ProcessEnvironment.ANY, true, 88.0,
            ResearchNode.AUTOMATION_ARCHITECTURE, ResearchExperiment.REFINE_VOID_SEED, ProcessMode.STANDARD,
            "Compress a finished Void Seed inside a chamber-supported singularity state. Requires a compression-capable Void Core and a narrower field margin." );

        addAdvanced("dimensional_kernel", MachineType.VOID_CORE,
            CustomItem.COMPRESSED_VOID_SEED, 1, CustomItem.OBSERVATION_CRYSTAL, 2, null,
            CustomItem.DIMENSIONAL_KERNEL, 1, CustomItem.ENTROPY_CONDENSATE, 1,
            165.0, 8200, 105.0, 165.0, 0.0, 999.0, 0.0, 0.0, 9.0,
            14.0, 260.0, 850, ProcessEnvironment.END, true, 92.0,
            ResearchNode.DIMENSIONAL_INFRASTRUCTURE, null, ProcessMode.STANDARD,
            "Collapse a compressed seed against correlated observation data in the End. Extraction hardware and extreme field stability are required." );
    }

    private void add(String id, MachineType machine,
                     CustomItem input, int inputAmount, CustomItem secondaryInput, int secondaryInputAmount, CustomItem catalyst,
                     CustomItem output, int outputAmount, CustomItem byproduct, int byproductAmount,
                     double duration, int flux, double minHeat, double maxHeat, double minPressure, double maxPressure,
                     double contamination, double purification, double wear,
                     ResearchNode research, ResearchExperiment experiment, ProcessMode mode, String description) {
        double entropyGenerated = mode == ProcessMode.PURIFY_CATALYST ? 1.0 : Math.max(1.0, flux / 180.0);
        recipes.add(new ProcessRecipe(id, machine, input, inputAmount, secondaryInput, secondaryInputAmount, catalyst,
            output, outputAmount, byproduct, byproductAmount, duration, flux, minHeat, maxHeat, minPressure, maxPressure,
            contamination, purification, wear, entropyGenerated, 0.0, 0, ProcessEnvironment.ANY, false, 0.0,
            research, experiment, mode, description));
    }

    private void addAdvanced(String id, MachineType machine,
                             CustomItem input, int inputAmount, CustomItem secondaryInput, int secondaryInputAmount, CustomItem catalyst,
                             CustomItem output, int outputAmount, CustomItem byproduct, int byproductAmount,
                             double duration, int flux, double minHeat, double maxHeat, double minPressure, double maxPressure,
                             double contamination, double purification, double wear,
                             double entropyGenerated, double entropyCost, int computationCost, ProcessEnvironment environment, boolean requiresMultiblock,
                             double minimumFieldStability, ResearchNode research, ResearchExperiment experiment, ProcessMode mode, String description) {
        recipes.add(new ProcessRecipe(id, machine, input, inputAmount, secondaryInput, secondaryInputAmount, catalyst,
            output, outputAmount, byproduct, byproductAmount, duration, flux, minHeat, maxHeat, minPressure, maxPressure,
            contamination, purification, wear, entropyGenerated, entropyCost, computationCost, environment, requiresMultiblock, minimumFieldStability,
            research, experiment, mode, description));
    }

    public List<ProcessRecipe> all() { return Collections.unmodifiableList(recipes); }

    public List<ProcessRecipe> forMachine(MachineType type) {
        return recipes.stream().filter(recipe -> recipe.machine() == type).toList();
    }

    public List<ProcessRecipe> candidates(MachineType type, CustomItem primary) {
        if (type == null || primary == null) return List.of();
        return recipes.stream().filter(recipe -> recipe.machine() == type && recipe.input() == primary).toList();
    }

    public ProcessRecipe match(MachineType type, CustomItem primary, CustomItem secondary, String preferredId) {
        List<ProcessRecipe> candidates = candidates(type, primary);
        if (candidates.isEmpty()) return null;
        if (preferredId != null) {
            for (ProcessRecipe recipe : candidates) if (recipe.id().equalsIgnoreCase(preferredId)) return recipe;
        }
        if (secondary != null) {
            for (ProcessRecipe recipe : candidates) {
                if (!recipe.requiresSecondaryInput() || recipe.secondaryInput() == secondary) return recipe;
            }
        }
        return candidates.getFirst();
    }

    public boolean canBePrimary(MachineType type, CustomItem item) { return !candidates(type, item).isEmpty(); }

    public boolean canBeSecondary(MachineType type, CustomItem primary, CustomItem item) {
        if (type == null || item == null) return false;
        return candidates(type, primary).stream().anyMatch(recipe -> recipe.secondaryInput() == item);
    }

    public ProcessRecipe byId(String id) {
        if (id == null) return null;
        return recipes.stream().filter(recipe -> recipe.id().equalsIgnoreCase(id)).findFirst().orElse(null);
    }
}
