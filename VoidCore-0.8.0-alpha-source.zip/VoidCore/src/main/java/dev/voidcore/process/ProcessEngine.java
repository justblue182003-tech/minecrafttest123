package dev.voidcore.process;

import dev.voidcore.item.ItemService;
import dev.voidcore.machine.MachineInstance;
import org.bukkit.inventory.ItemStack;

public final class ProcessEngine {
    public enum TickState {
        NO_RECIPE,
        MISSING_SECONDARY_INPUT,
        MISSING_CATALYST,
        CATALYST_CLEAN,
        OUTPUT_BLOCKED,
        BYPRODUCT_BLOCKED,
        FAULTED,
        MAINTENANCE_REQUIRED,
        AUTOMATION_BLOCKED,
        SINGULARITY_UNSUPPORTED,
        TOO_COLD,
        TOO_HOT,
        PRESSURE_LOW,
        PRESSURE_HIGH,
        ENVIRONMENT_BLOCKED,
        STRUCTURE_INVALID,
        FIELD_UNSTABLE,
        ENTROPY_LOW,
        COMPUTATION_LOW,
        NO_FLUX,
        PROCESSING,
        COMPLETED
    }

    private final ItemService items;

    public ProcessEngine(ItemService items) { this.items = items; }

    public TickState tick(MachineInstance machine, ProcessRecipe recipe, ProcessTuning tuning) {
        if (machine.faulted()) {
            resetProgress(machine);
            return TickState.FAULTED;
        }
        if (machine.wear() >= 99.95) {
            resetProgress(machine);
            return TickState.MAINTENANCE_REQUIRED;
        }
        if (!machine.automationAllowsRun()) {
            resetProgress(machine);
            return TickState.AUTOMATION_BLOCKED;
        }
        if (recipe == null) {
            resetProgress(machine);
            return TickState.NO_RECIPE;
        }

        ItemStack input = machine.input();
        if (!items.is(input, recipe.input()) || input.getAmount() < recipe.inputAmount()) {
            resetProgress(machine);
            return TickState.NO_RECIPE;
        }

        ItemStack secondary = machine.secondaryInput();
        if (recipe.requiresSecondaryInput()
            && (!items.is(secondary, recipe.secondaryInput()) || secondary.getAmount() < recipe.secondaryInputAmount())) {
            resetProgress(machine);
            return TickState.MISSING_SECONDARY_INPUT;
        }

        ItemStack catalyst = machine.catalyst();
        if (recipe.requiresCatalyst() && !items.is(catalyst, recipe.catalyst())) {
            resetProgress(machine);
            return TickState.MISSING_CATALYST;
        }
        if (recipe.mode() == ProcessMode.PURIFY_CATALYST && items.contamination(input) <= 0.05) {
            resetProgress(machine);
            return TickState.CATALYST_CLEAN;
        }

        if (occupied(machine.output())) return TickState.OUTPUT_BLOCKED;
        if (recipe.hasByproduct() && occupied(machine.byproduct())) return TickState.BYPRODUCT_BLOCKED;
        if (machine.heat() < recipe.minimumHeat()) return TickState.TOO_COLD;
        if (machine.heat() > recipe.maximumHeat()) return TickState.TOO_HOT;
        if (recipe.usesPressure() && machine.pressure() < recipe.minimumPressure()) return TickState.PRESSURE_LOW;
        if (recipe.usesPressure() && machine.pressure() > recipe.maximumPressure()) return TickState.PRESSURE_HIGH;
        if (recipe.requiresMultiblock() && !machine.structureValid()) return TickState.STRUCTURE_INVALID;
        if (recipe.usesSpatialField() && machine.fieldStability() + 0.001 < recipe.minimumFieldStability()) return TickState.FIELD_UNSTABLE;
        if (!recipe.environment().matches(machine.location())) return TickState.ENVIRONMENT_BLOCKED;
        if (machine.entropy() + 0.001 < recipe.entropyCost()) return TickState.ENTROPY_LOW;
        if (machine.computation() < recipe.computationCost()) return TickState.COMPUTATION_LOW;

        int fluxPerSecond = Math.max(1, (int) Math.ceil((recipe.fluxCost() / recipe.durationSeconds()) * tuning.fluxMultiplier()));
        if (machine.flux() < fluxPerSecond) return TickState.NO_FLUX;

        double activity = 1.0;
        if (recipe.requiresCatalyst()) {
            double contamination = items.contamination(catalyst);
            activity = Math.max(0.35, 1.0 - (contamination * 0.0065));
        }
        if (machine.fault() == dev.voidcore.machine.MachineFault.COHERENCE_DRIFT) activity *= 0.78;

        if (!machine.consumeFlux(fluxPerSecond)) return TickState.NO_FLUX;
        machine.progress(machine.progress() + Math.max(0.05, tuning.speedMultiplier() * activity));
        if (machine.progress() < recipe.durationSeconds()) return TickState.PROCESSING;

        int outputQuality = calculateOutputQuality(machine, recipe, input, secondary, catalyst);
        ItemStack produced = produce(recipe, input, outputQuality);
        consume(input, recipe.inputAmount());
        machine.input(input.getAmount() <= 0 ? null : input);
        if (recipe.requiresSecondaryInput() && secondary != null) {
            consume(secondary, recipe.secondaryInputAmount());
            machine.secondaryInput(secondary.getAmount() <= 0 ? null : secondary);
        }
        if (recipe.requiresCatalyst() && catalyst != null) {
            items.setContamination(catalyst,
                items.contamination(catalyst) + recipe.catalystContamination() * tuning.contaminationMultiplier());
            machine.catalyst(catalyst);
        }
        machine.output(produced);
        if (recipe.hasByproduct()) machine.byproduct(items.create(recipe.byproduct(), recipe.byproductAmount()));
        double entropyGenerated = recipe.entropyGenerated() * machine.activeDirective().entropyMultiplier();
        if (machine.type() == dev.voidcore.machine.MachineType.VOID_CORE) {
            entropyGenerated *= machine.singularityMode().entropyMultiplier();
        }
        machine.entropy(Math.max(0.0, machine.entropy() - recipe.entropyCost()) + entropyGenerated);
        machine.computation(Math.max(0, machine.computation() - recipe.computationCost()));
        machine.completedProcessId(recipe.id());
        machine.progress(0.0);
        machine.recordCycle(recipe.outputAmount(), recipe.entropyCost());
        machine.recordProduction(recipe.output().id(), recipe.outputAmount());

        double heatError = normalizedError(machine.heat(), recipe.centerHeat(), recipe.minimumHeat(), recipe.maximumHeat());
        double pressureError = recipe.usesPressure()
            ? normalizedError(machine.pressure(), recipe.centerPressure(), recipe.minimumPressure(), recipe.maximumPressure()) : 0.0;
        double wear = recipe.wearPerCycle() * tuning.wearMultiplier()
            * (1.0 + heatError * 0.35 + pressureError * 0.45);
        machine.wear(machine.wear() + wear);
        return TickState.COMPLETED;
    }

    private ItemStack produce(ProcessRecipe recipe, ItemStack input, int outputQuality) {
        if (recipe.mode() == ProcessMode.PURIFY_CATALYST) {
            ItemStack purified = items.copyWithContamination(input,
                Math.max(0.0, items.contamination(input) - recipe.purificationAmount()));
            if (purified != null) return purified;
        }
        return items.createWithQuality(recipe.output(), recipe.outputAmount(), outputQuality);
    }

    public int calculateOutputQuality(MachineInstance machine, ProcessRecipe recipe,
                                      ItemStack input, ItemStack secondary, ItemStack catalyst) {
        double heatAccuracy = 1.0 - normalizedError(machine.heat(), recipe.centerHeat(), recipe.minimumHeat(), recipe.maximumHeat());
        double pressureAccuracy = recipe.usesPressure()
            ? 1.0 - normalizedError(machine.pressure(), recipe.centerPressure(), recipe.minimumPressure(), recipe.maximumPressure()) : 1.0;
        double machineQuality = machine.quality();
        double inputQuality = items.quality(input);
        double secondaryQuality = recipe.requiresSecondaryInput() ? items.quality(secondary) : inputQuality;
        double feedQuality = recipe.requiresSecondaryInput() ? inputQuality * 0.65 + secondaryQuality * 0.35 : inputQuality;
        double catalystQuality = recipe.requiresCatalyst()
            ? Math.max(1.0, items.quality(catalyst) - items.contamination(catalyst) * 0.30)
            : 50.0;

        double result;
        if (recipe.usesPressure()) {
            result = machineQuality * 0.27 + feedQuality * 0.30 + heatAccuracy * 100.0 * 0.18
                + pressureAccuracy * 100.0 * 0.25;
        } else if (recipe.requiresCatalyst()) {
            result = machineQuality * 0.32 + feedQuality * 0.33 + catalystQuality * 0.20 + heatAccuracy * 100.0 * 0.15;
        } else {
            result = machineQuality * 0.38 + feedQuality * 0.37 + heatAccuracy * 100.0 * 0.25;
        }
        if (recipe.usesSpatialField()) {
            double margin = Math.max(0.0, machine.fieldStability() - recipe.minimumFieldStability());
            result += Math.min(8.0, margin * 0.35);
        }
        if (machine.fault() == dev.voidcore.machine.MachineFault.COHERENCE_DRIFT) result -= 8.0;
        return Math.max(1, Math.min(100, (int) Math.round(result)));
    }

    private double normalizedError(double value, double center, double minimum, double maximum) {
        double span = Math.max(0.001, (maximum - minimum) / 2.0);
        return Math.min(1.0, Math.abs(value - center) / span);
    }

    private boolean occupied(ItemStack stack) { return stack != null && !stack.getType().isAir(); }
    private void resetProgress(MachineInstance machine) { if (machine.progress() != 0.0) machine.progress(0.0); }
    private void consume(ItemStack stack, int amount) { stack.setAmount(Math.max(0, stack.getAmount() - amount)); }
}
