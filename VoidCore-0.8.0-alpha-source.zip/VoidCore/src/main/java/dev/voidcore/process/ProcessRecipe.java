package dev.voidcore.process;

import dev.voidcore.item.CustomItem;
import dev.voidcore.machine.MachineType;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchNode;

public record ProcessRecipe(
    String id,
    MachineType machine,
    CustomItem input,
    int inputAmount,
    CustomItem secondaryInput,
    int secondaryInputAmount,
    CustomItem catalyst,
    CustomItem output,
    int outputAmount,
    CustomItem byproduct,
    int byproductAmount,
    double durationSeconds,
    int fluxCost,
    double minimumHeat,
    double maximumHeat,
    double minimumPressure,
    double maximumPressure,
    double catalystContamination,
    double purificationAmount,
    double wearPerCycle,
    double entropyGenerated,
    double entropyCost,
    int computationCost,
    ProcessEnvironment environment,
    boolean requiresMultiblock,
    double minimumFieldStability,
    ResearchNode research,
    ResearchExperiment completionExperiment,
    ProcessMode mode,
    String description
) {
    public ProcessRecipe {
        if (input == null || output == null) throw new IllegalArgumentException("Processes require primary input and output.");
        if (inputAmount < 1 || outputAmount < 1) throw new IllegalArgumentException("Process amounts must be positive.");
        if (secondaryInput == null && secondaryInputAmount != 0) throw new IllegalArgumentException("Secondary amount requires a secondary input.");
        if (secondaryInput != null && secondaryInputAmount < 1) throw new IllegalArgumentException("Secondary amount must be positive.");
        if (byproduct == null && byproductAmount != 0) throw new IllegalArgumentException("Byproduct amount requires a byproduct.");
        if (byproduct != null && byproductAmount < 1) throw new IllegalArgumentException("Byproduct amount must be positive.");
        if (durationSeconds <= 0.0) throw new IllegalArgumentException("Process duration must be positive.");
        if (minimumHeat > maximumHeat) throw new IllegalArgumentException("Minimum heat cannot exceed maximum heat.");
        if (minimumPressure > maximumPressure) throw new IllegalArgumentException("Minimum pressure cannot exceed maximum pressure.");
        if (wearPerCycle < 0.0) throw new IllegalArgumentException("Wear cannot be negative.");
        if (entropyGenerated < 0.0 || entropyCost < 0.0) throw new IllegalArgumentException("Entropy values cannot be negative.");
        if (computationCost < 0) throw new IllegalArgumentException("Computation cost cannot be negative.");
        if (minimumFieldStability < 0.0 || minimumFieldStability > 100.0) throw new IllegalArgumentException("Field stability must be 0..100.");
        if (environment == null) environment = ProcessEnvironment.ANY;
    }

    public boolean requiresSecondaryInput() { return secondaryInput != null; }
    public boolean requiresCatalyst() { return catalyst != null; }
    public boolean hasByproduct() { return byproduct != null; }
    public boolean usesPressure() { return minimumPressure > 0.01 || maximumPressure < 999.0; }
    public double centerHeat() { return (minimumHeat + maximumHeat) / 2.0; }
    public double centerPressure() { return (minimumPressure + maximumPressure) / 2.0; }
    public boolean usesEntropy() { return entropyCost > 0.001 || entropyGenerated > 0.001; }
    public boolean usesComputation() { return computationCost > 0; }
    public boolean usesSpatialField() { return minimumFieldStability > 0.001; }
}
