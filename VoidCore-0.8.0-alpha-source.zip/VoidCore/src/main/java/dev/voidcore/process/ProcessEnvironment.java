package dev.voidcore.process;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

/** Environmental predicates are explicit recipe data, never hidden random failure conditions. */
public enum ProcessEnvironment {
    ANY("Any environment", "No external environmental condition is required."),
    OPEN_SKY("Open sky", "The controller must have an unobstructed vertical path to the sky."),
    NIGHT_SKY("Clear night sky", "Requires open sky, nighttime, and no active storm."),
    SCULK_FIELD("Dense sculk field", "At least eight sculk-family blocks must exist within a 5×3×5 field around the machine."),
    NETHER("Nether environment", "The process must be operated in the Nether."),
    END("End environment", "The process must be operated in the End.");

    private final String displayName;
    private final String description;

    ProcessEnvironment(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String displayName() { return displayName; }
    public String description() { return description; }
    public boolean constrained() { return this != ANY; }

    public boolean matches(Location location) {
        if (this == ANY) return true;
        if (location == null || location.getWorld() == null) return false;
        World world = location.getWorld();
        return switch (this) {
            case ANY -> true;
            case OPEN_SKY -> openSky(location);
            case NIGHT_SKY -> openSky(location) && isNight(world) && !world.hasStorm();
            case SCULK_FIELD -> sculkCount(location) >= 8;
            case NETHER -> world.getEnvironment() == World.Environment.NETHER;
            case END -> world.getEnvironment() == World.Environment.THE_END;
        };
    }

    public String status(Location location) {
        return matches(location) ? "Satisfied: " + displayName : "Required: " + displayName;
    }

    private static boolean openSky(Location location) {
        World world = location.getWorld();
        if (world == null) return false;
        int highest = world.getHighestBlockYAt(location.getBlockX(), location.getBlockZ());
        return highest <= location.getBlockY() + 1;
    }

    private static boolean isNight(World world) {
        long time = world.getTime();
        return time >= 13000L && time <= 23000L;
    }

    private static int sculkCount(Location location) {
        World world = location.getWorld();
        if (world == null) return 0;
        int count = 0;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    Material type = world.getBlockAt(location.getBlockX() + dx, location.getBlockY() + dy, location.getBlockZ() + dz).getType();
                    if (type == Material.SCULK || type == Material.SCULK_CATALYST || type == Material.SCULK_SENSOR
                        || type == Material.CALIBRATED_SCULK_SENSOR || type == Material.SCULK_VEIN || type == Material.SCULK_SHRIEKER) {
                        count++;
                    }
                }
            }
        }
        return count;
    }
}
