package dev.voidcore.process;

public enum ProcessMode {
    STANDARD,
    PURIFY_CATALYST
}
