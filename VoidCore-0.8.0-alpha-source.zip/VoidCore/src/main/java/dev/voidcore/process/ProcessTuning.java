package dev.voidcore.process;

public record ProcessTuning(
    double speedMultiplier,
    double fluxMultiplier,
    double contaminationMultiplier,
    double heatingMultiplier,
    double coolingMultiplier,
    double wearMultiplier
) {
    public static ProcessTuning neutral() {
        return new ProcessTuning(1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
    }
}
