package dev.voidcore.simulation;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Computes a non-authoritative spatial coherence field from nearby VoidCore machinery.
 * The value is recomputed every server second and therefore does not need persistence.
 */
public final class SpatialFieldService {
    private final VoidCorePlugin plugin;
    private final MachineService machines;

    public SpatialFieldService(VoidCorePlugin plugin, MachineService machines) {
        this.plugin = plugin;
        this.machines = machines;
    }

    public void tick() {
        List<MachineInstance> loaded = new ArrayList<>();
        for (MachineInstance machine : machines.all()) {
            Location location = machine.location();
            if (location.getWorld() == null || !location.isChunkLoaded()) continue;
            loaded.add(machine);
        }
        for (MachineInstance target : loaded) target.fieldStability(calculate(target, loaded));
    }

    public int visualize(Player player, MachineInstance center) {
        if (player == null || center == null || center.location().getWorld() == null || !center.location().getWorld().equals(player.getWorld())) return 0;
        int sources = 0;
        Location origin = center.location().clone().add(0.5, 0.8, 0.5);
        for (MachineInstance machine : machines.all()) {
            Location location = machine.location();
            if (location.getWorld() == null || !location.getWorld().equals(player.getWorld())) continue;
            if (location.distance(center.location()) > 12.0) continue;
            boolean relevant = machine.type() == MachineType.FIELD_STABILIZER || machine.type() == MachineType.VOID_CORE
                || machine.type() == MachineType.PHASE_OBSERVER || machine.type() == MachineType.VOID_UPGRADE_CHAMBER;
            if (!relevant) continue;
            sources++;
            Location point = location.clone().add(0.5, 1.0, 0.5);
            player.spawnParticle(Particle.END_ROD, point, 8, 0.25, 0.25, 0.25, 0.0);
            double dx = point.getX() - origin.getX();
            double dy = point.getY() - origin.getY();
            double dz = point.getZ() - origin.getZ();
            for (int i = 1; i <= 8; i++) {
                double t = i / 9.0;
                player.spawnParticle(Particle.END_ROD, origin.getX() + dx * t, origin.getY() + dy * t, origin.getZ() + dz * t,
                    1, 0.0, 0.0, 0.0, 0.0);
            }
        }
        double radius = 3.0 + center.fieldStability() / 25.0;
        for (int i = 0; i < 32; i++) {
            double angle = Math.PI * 2.0 * i / 32.0;
            player.spawnParticle(Particle.END_ROD, origin.getX() + Math.cos(angle) * radius, origin.getY(),
                origin.getZ() + Math.sin(angle) * radius, 1, 0.0, 0.0, 0.0, 0.0);
        }
        return sources;
    }

    private double calculate(MachineInstance target, List<MachineInstance> all) {
        double field = 50.0;
        field += switch (target.activeDirective()) {
            case STABILITY -> 7.0;
            case THROUGHPUT -> -4.0;
            default -> 0.0;
        };
        for (MachineInstance source : all) {
            if (source == target || source.location().getWorld() == null || target.location().getWorld() == null) continue;
            if (!source.location().getWorld().getUID().equals(target.location().getWorld().getUID())) continue;
            double distance = source.location().distance(target.location());
            if (distance > 12.0) continue;

            double falloff = EngineeringMath.spatialFalloff(distance, 12.0);
            int stabilizerCost = Math.max(1, plugin.getConfig().getInt("field.stabilizer-flux-per-second", 10));
            if (source.type() == MachineType.FIELD_STABILIZER && source.flux() >= stabilizerCost && !source.maintenanceLocked()) {
                field += (18.0 + source.quality() * 0.16) * falloff;
            } else if (source.type() == MachineType.VOID_CORE) {
                double structure = source.structureValid() ? 1.0 : 0.25;
                double mode = switch (source.singularityMode()) {
                    case QUIESCENT -> 1.15;
                    case CONTAINED -> 1.0;
                    case COMPRESSED -> 0.84;
                    case EXTRACTION -> 0.66;
                };
                field += (22.0 + source.quality() * 0.12) * falloff * structure * mode;
            } else if (source.type() == MachineType.VOID_UPGRADE_CHAMBER
                && source.coreChamberMode() == dev.voidcore.machine.CoreChamberMode.STABILIZATION
                && source.flux() >= Math.max(1, plugin.getConfig().getInt("void-core.chamber-flux-per-second", 12))
                && !source.maintenanceLocked() && source.automationAllowsRun()) {
                field += (13.0 + source.quality() * 0.10) * falloff;
            } else if (source.type() == MachineType.PHASE_OBSERVER) {
                field -= (3.0 + source.computation() / 500.0) * falloff;
            }

            double capacity = machines.entropyCapacity(source.type());
            if (capacity > 0.0 && source.entropy() > capacity * 0.55) {
                double pressure = Math.min(1.5, source.entropy() / capacity);
                field -= 12.0 * pressure * falloff;
            }
        }
        return EngineeringMath.fieldStability(field);
    }
}
