package dev.voidcore.simulation;

/**
 * Pure engineering/network calculations kept independent from Bukkit so they can be unit-tested.
 */
public final class EngineeringMath {
    private EngineeringMath() { }

    public static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static double networkLossRate(double baseLoss, double perHopLoss, int hops) {
        return clamp(Math.max(0.0, baseLoss) + Math.max(0, hops) * Math.max(0.0, perHopLoss), 0.0, 0.30);
    }

    public static int deliveredFlux(int sent, double lossRate) {
        if (sent <= 0) return 0;
        double loss = clamp(lossRate, 0.0, 0.95);
        return Math.max(0, (int) Math.floor(sent * (1.0 - loss)));
    }

    public static int requiredSentFlux(int desiredDelivered, double lossRate) {
        if (desiredDelivered <= 0) return 0;
        double efficiency = Math.max(0.05, 1.0 - clamp(lossRate, 0.0, 0.95));
        return Math.max(1, (int) Math.ceil(desiredDelivered / efficiency));
    }

    public static double maintenanceReduction(int kitQuality) {
        int quality = Math.max(0, Math.min(100, kitQuality));
        return 38.0 + quality * 0.34;
    }

    public static double passiveTemperature(double current, double ambient, double equalization, double thermalMass) {
        double mass = Math.max(0.1, thermalMass);
        return current + (ambient - current) * (Math.max(0.0, equalization) / mass);
    }

    public static double passivePressure(double current, double ambient, double equalization) {
        double rate = clamp(equalization, 0.0, 1.0);
        return Math.max(0.0, current + (ambient - current) * rate);
    }

    public static double pressureAccuracy(double pressure, double minimum, double maximum) {
        if (maximum <= minimum) return 1.0;
        double center = (minimum + maximum) / 2.0;
        double halfSpan = Math.max(0.001, (maximum - minimum) / 2.0);
        return clamp(1.0 - Math.abs(pressure - center) / halfSpan, 0.0, 1.0);
    }

    public static int routingScore(int priority, int hops) {
        return Math.max(0, Math.min(9, priority)) * 1000 - Math.max(0, hops);
    }

    public static double spatialFalloff(double distance, double radius) {
        if (radius <= 0.0) return 0.0;
        return clamp(1.0 - Math.max(0.0, distance) / radius, 0.0, 1.0);
    }

    public static double fieldStability(double raw) {
        return clamp(raw, 0.0, 100.0);
    }

    public static double exchangerTransfer(double hot, double cold, double baseUnits, double quality) {
        double difference = Math.max(0.0, hot - cold);
        double qualityScale = 0.70 + clamp(quality, 0.0, 100.0) / 100.0 * 0.55;
        return Math.max(0.0, Math.min(Math.max(0.0, baseUnits) * qualityScale, difference * 0.22));
    }
}
