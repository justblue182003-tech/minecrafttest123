package dev.voidcore.discovery;

import dev.voidcore.Keys;
import dev.voidcore.item.CustomItem;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;

public final class DiscoveryService {
    private final Keys keys;

    public DiscoveryService(Keys keys) {
        this.keys = keys;
    }

    public boolean discover(Player player, CustomItem item) {
        return add(player, keys.discoveries, item);
    }

    public boolean scan(Player player, CustomItem item) {
        discover(player, item);
        return add(player, keys.scans, item);
    }

    public boolean isDiscovered(Player player, CustomItem item) {
        return read(player, keys.discoveries).contains(item);
    }

    public boolean isScanned(Player player, CustomItem item) {
        return read(player, keys.scans).contains(item);
    }

    public Set<CustomItem> discovered(Player player) {
        return read(player, keys.discoveries);
    }

    private boolean add(Player player, NamespacedKey key, CustomItem item) {
        Set<CustomItem> values = read(player, key);
        if (!values.add(item)) return false;
        save(player, key, values);
        return true;
    }

    private Set<CustomItem> read(Player player, NamespacedKey key) {
        String raw = player.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (raw == null || raw.isBlank()) return new LinkedHashSet<>();
        return Arrays.stream(raw.split(","))
            .map(CustomItem::fromId)
            .filter(java.util.Objects::nonNull)
            .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private void save(Player player, NamespacedKey key, Set<CustomItem> values) {
        String raw = values.stream().map(CustomItem::id).collect(Collectors.joining(","));
        player.getPersistentDataContainer().set(key, PersistentDataType.STRING, raw);
    }
}
