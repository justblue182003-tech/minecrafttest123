package dev.voidcore.item;

public enum QualityGrade {
    PROTOTYPE(0, "Prototype"),
    INDUSTRIAL(45, "Industrial"),
    REFINED(65, "Refined"),
    PRECISION(82, "Precision"),
    EXCEPTIONAL(95, "Exceptional");

    private final int minimum;
    private final String displayName;

    QualityGrade(int minimum, String displayName) {
        this.minimum = minimum;
        this.displayName = displayName;
    }

    public int minimum() { return minimum; }
    public String displayName() { return displayName; }

    public static QualityGrade fromScore(int score) {
        int clamped = Math.max(0, Math.min(100, score));
        QualityGrade result = PROTOTYPE;
        for (QualityGrade grade : values()) {
            if (clamped >= grade.minimum) result = grade;
        }
        return result;
    }
}
