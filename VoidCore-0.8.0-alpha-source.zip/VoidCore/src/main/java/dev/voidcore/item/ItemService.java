package dev.voidcore.item;

import dev.voidcore.Keys;
import dev.voidcore.machine.MachineFault;
import dev.voidcore.machine.ObserverProgram;
import dev.voidcore.machine.ControlDirective;
import dev.voidcore.machine.AutomationRule;
import dev.voidcore.machine.SignalGate;
import dev.voidcore.machine.SingularityMode;
import dev.voidcore.machine.CoreChamberMode;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ItemService {
    private final Keys keys;

    public ItemService(Keys keys) {
        this.keys = keys;
    }

    public ItemStack create(CustomItem type) {
        return create(type, 1);
    }

    public ItemStack create(CustomItem type, int amount) {
        ItemStack stack = new ItemStack(type.material(), Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(keys.itemId, PersistentDataType.STRING, type.id());
        stack.setItemMeta(meta);
        refreshPresentation(stack);
        return stack;
    }

    public ItemStack createWithQuality(CustomItem type, int amount, int quality) {
        ItemStack stack = create(type, amount);
        setQuality(stack, quality);
        if (type == CustomItem.CATALYST_MATRIX) setContamination(stack, 0.0);
        return stack;
    }

    public CustomItem identify(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) return null;
        String id = stack.getItemMeta().getPersistentDataContainer().get(keys.itemId, PersistentDataType.STRING);
        return CustomItem.fromId(id);
    }

    public boolean is(ItemStack stack, CustomItem item) {
        return identify(stack) == item;
    }

    public boolean hasQuality(ItemStack stack) {
        return stack != null && stack.hasItemMeta()
            && stack.getItemMeta().getPersistentDataContainer().has(keys.itemQuality, PersistentDataType.INTEGER);
    }

    public int quality(ItemStack stack) {
        if (!hasQuality(stack)) return 50;
        Integer value = stack.getItemMeta().getPersistentDataContainer().get(keys.itemQuality, PersistentDataType.INTEGER);
        return clampQuality(value == null ? 50 : value);
    }

    public void setQuality(ItemStack stack, int quality) {
        if (stack == null || stack.getType().isAir() || identify(stack) == null) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(keys.itemQuality, PersistentDataType.INTEGER, clampQuality(quality));
        stack.setItemMeta(meta);
        refreshPresentation(stack);
    }

    public double contamination(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0.0;
        Double value = stack.getItemMeta().getPersistentDataContainer().get(keys.catalystContamination, PersistentDataType.DOUBLE);
        return clampPercent(value == null ? 0.0 : value);
    }

    public void setContamination(ItemStack stack, double contamination) {
        if (!is(stack, CustomItem.CATALYST_MATRIX)) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(keys.catalystContamination, PersistentDataType.DOUBLE, clampPercent(contamination));
        stack.setItemMeta(meta);
        refreshPresentation(stack);
    }


    public double machineWear(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0.0;
        Double value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineWear, PersistentDataType.DOUBLE);
        return clampPercent(value == null ? 0.0 : value);
    }

    public void setMachineWear(ItemStack stack, double wear) {
        CustomItem type = identify(stack);
        if (stack == null || type == null || type.category() != CustomItem.Category.MACHINE) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(keys.machineWear, PersistentDataType.DOUBLE, clampPercent(wear));
        stack.setItemMeta(meta);
        refreshPresentation(stack);
    }

    public double machineEntropy(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0.0;
        Double value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineEntropy, PersistentDataType.DOUBLE);
        return Math.max(0.0, value == null ? 0.0 : value);
    }

    public void setMachineEntropy(ItemStack stack, double entropy) {
        CustomItem type = identify(stack);
        if (stack == null || type == null || type.category() != CustomItem.Category.MACHINE) return;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(keys.machineEntropy, PersistentDataType.DOUBLE, Math.max(0.0, entropy));
        stack.setItemMeta(meta);
        refreshPresentation(stack);
    }

    public MachineFault machineFault(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return MachineFault.NONE;
        String value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineFault, PersistentDataType.STRING);
        return MachineFault.fromId(value);
    }

    public int machineFaultTicks(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0;
        Integer value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineFaultTicks, PersistentDataType.INTEGER);
        return Math.max(0, value == null ? 0 : value);
    }

    public void setMachineFault(ItemStack stack, MachineFault fault, int ticks) {
        CustomItem type = identify(stack);
        if (stack == null || type == null || type.category() != CustomItem.Category.MACHINE) return;
        ItemMeta meta = stack.getItemMeta();
        MachineFault safe = fault == null ? MachineFault.NONE : fault;
        meta.getPersistentDataContainer().set(keys.machineFault, PersistentDataType.STRING, safe.id());
        meta.getPersistentDataContainer().set(keys.machineFaultTicks, PersistentDataType.INTEGER, Math.max(0, ticks));
        stack.setItemMeta(meta);
        refreshPresentation(stack);
    }

    public ObserverProgram machineObserverProgram(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return ObserverProgram.BROAD_SPECTRUM;
        String value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineObserverProgram, PersistentDataType.STRING);
        return ObserverProgram.fromId(value);
    }

    public ControlDirective machineControlDirective(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return ControlDirective.BALANCED;
        String value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineControlDirective, PersistentDataType.STRING);
        return ControlDirective.fromId(value);
    }

    public long machineCycles(ItemStack stack) { return longData(stack, keys.machineCycles); }
    public long machineItemsProduced(ItemStack stack) { return longData(stack, keys.machineItemsProduced); }
    public long machineFluxConsumed(ItemStack stack) { return longData(stack, keys.machineFluxConsumed); }
    public long machineIncidents(ItemStack stack) { return longData(stack, keys.machineIncidents); }
    public int machineAutomationGroup(ItemStack stack) { return intData(stack, keys.machineAutomationGroup, 0, 0, 7); }
    public int machineSignalChannel(ItemStack stack) { return intData(stack, keys.machineSignalChannel, 0, 0, 15); }
    public SignalGate machineSignalGate(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return SignalGate.IGNORE;
        return SignalGate.fromId(stack.getItemMeta().getPersistentDataContainer().get(keys.machineSignalGate, PersistentDataType.STRING));
    }
    public AutomationRule machineAutomationRule(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return AutomationRule.ALWAYS;
        return AutomationRule.fromId(stack.getItemMeta().getPersistentDataContainer().get(keys.machineAutomationRule, PersistentDataType.STRING));
    }
    public SingularityMode machineSingularityMode(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return SingularityMode.CONTAINED;
        return SingularityMode.fromId(stack.getItemMeta().getPersistentDataContainer().get(keys.machineSingularityMode, PersistentDataType.STRING));
    }
    public CoreChamberMode machineCoreChamberMode(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return CoreChamberMode.STABILIZATION;
        return CoreChamberMode.fromId(stack.getItemMeta().getPersistentDataContainer().get(keys.machineCoreChamberMode, PersistentDataType.STRING));
    }
    public Map<String, Long> machineProductionLedger(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return Map.of();
        String encoded = stack.getItemMeta().getPersistentDataContainer().get(keys.machineProductionLedger, PersistentDataType.STRING);
        return decodeLedger(encoded);
    }
    public double machineEntropyProcessed(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return 0.0;
        Double value = stack.getItemMeta().getPersistentDataContainer().get(keys.machineEntropyProcessed, PersistentDataType.DOUBLE);
        return Math.max(0.0, value == null ? 0.0 : value);
    }

    public void setMachineExtendedState(ItemStack stack, ObserverProgram program, ControlDirective directive,
                                        long cycles, long itemsProduced, long fluxConsumed, double entropyProcessed, long incidents,
                                        int automationGroup, int signalChannel, SignalGate signalGate, AutomationRule automationRule,
                                        SingularityMode singularityMode, CoreChamberMode coreChamberMode, Map<String, Long> productionLedger) {
        CustomItem type = identify(stack);
        if (stack == null || type == null || type.category() != CustomItem.Category.MACHINE) return;
        ItemMeta meta = stack.getItemMeta();
        var data = meta.getPersistentDataContainer();
        data.set(keys.machineObserverProgram, PersistentDataType.STRING, (program == null ? ObserverProgram.BROAD_SPECTRUM : program).id());
        data.set(keys.machineControlDirective, PersistentDataType.STRING, (directive == null ? ControlDirective.BALANCED : directive).id());
        data.set(keys.machineCycles, PersistentDataType.LONG, Math.max(0L, cycles));
        data.set(keys.machineItemsProduced, PersistentDataType.LONG, Math.max(0L, itemsProduced));
        data.set(keys.machineFluxConsumed, PersistentDataType.LONG, Math.max(0L, fluxConsumed));
        data.set(keys.machineEntropyProcessed, PersistentDataType.DOUBLE, Math.max(0.0, entropyProcessed));
        data.set(keys.machineIncidents, PersistentDataType.LONG, Math.max(0L, incidents));
        data.set(keys.machineAutomationGroup, PersistentDataType.INTEGER, Math.max(0, Math.min(7, automationGroup)));
        data.set(keys.machineSignalChannel, PersistentDataType.INTEGER, Math.max(0, Math.min(15, signalChannel)));
        data.set(keys.machineSignalGate, PersistentDataType.STRING, (signalGate == null ? SignalGate.IGNORE : signalGate).id());
        data.set(keys.machineAutomationRule, PersistentDataType.STRING, (automationRule == null ? AutomationRule.ALWAYS : automationRule).id());
        data.set(keys.machineSingularityMode, PersistentDataType.STRING, (singularityMode == null ? SingularityMode.CONTAINED : singularityMode).id());
        data.set(keys.machineCoreChamberMode, PersistentDataType.STRING, (coreChamberMode == null ? CoreChamberMode.STABILIZATION : coreChamberMode).id());
        data.set(keys.machineProductionLedger, PersistentDataType.STRING, encodeLedger(productionLedger));
        stack.setItemMeta(meta);
        refreshPresentation(stack);
    }

    private long longData(ItemStack stack, org.bukkit.NamespacedKey key) {
        if (stack == null || !stack.hasItemMeta()) return 0L;
        Long value = stack.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.LONG);
        return Math.max(0L, value == null ? 0L : value);
    }

    private int intData(ItemStack stack, org.bukkit.NamespacedKey key, int fallback, int minimum, int maximum) {
        if (stack == null || !stack.hasItemMeta()) return fallback;
        Integer value = stack.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.INTEGER);
        return Math.max(minimum, Math.min(maximum, value == null ? fallback : value));
    }

    public String encodeLedger(Map<String, Long> ledger) {
        if (ledger == null || ledger.isEmpty()) return "";
        return ledger.entrySet().stream()
            .filter(entry -> entry.getKey() != null && entry.getKey().matches("[a-z0-9_]+") && entry.getValue() != null && entry.getValue() > 0L)
            .sorted(Map.Entry.comparingByKey())
            .map(entry -> entry.getKey() + "=" + entry.getValue())
            .collect(java.util.stream.Collectors.joining(";"));
    }

    public Map<String, Long> decodeLedger(String encoded) {
        if (encoded == null || encoded.isBlank()) return Map.of();
        Map<String, Long> result = new LinkedHashMap<>();
        for (String part : encoded.split(";")) {
            String[] pair = part.split("=", 2);
            if (pair.length != 2 || !pair[0].matches("[a-z0-9_]+")) continue;
            try {
                long value = Long.parseLong(pair[1]);
                if (value > 0L) result.put(pair[0], value);
            } catch (NumberFormatException ignored) { }
        }
        return Map.copyOf(result);
    }

    public ItemStack copyWithContamination(ItemStack source, double contamination) {
        if (!is(source, CustomItem.CATALYST_MATRIX)) return null;
        ItemStack copy = source.clone();
        copy.setAmount(1);
        setContamination(copy, contamination);
        return copy;
    }

    public void refreshPresentation(ItemStack stack) {
        CustomItem type = identify(stack);
        if (type == null) return;
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.name(type.displayName(), color(type)));
        meta.lore(lore(type, stack));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        stack.setItemMeta(meta);
    }

    private NamedTextColor color(CustomItem type) {
        return switch (type.category()) {
            case TOOL -> NamedTextColor.LIGHT_PURPLE;
            case MATERIAL -> NamedTextColor.AQUA;
            case COMPONENT -> NamedTextColor.GOLD;
            case UPGRADE -> NamedTextColor.YELLOW;
            case MACHINE -> NamedTextColor.DARK_PURPLE;
        };
    }

    private List<Component> lore(CustomItem type, ItemStack stack) {
        List<Component> lines = new ArrayList<>();
        lines.add(Text.lore(type.description()));
        lines.add(Text.muted(type.detail()));
        if (hasQuality(stack)) {
            int quality = quality(stack);
            lines.add(Component.empty());
            lines.add(Text.accent("Engineering quality: " + quality + "/100 • " + QualityGrade.fromScore(quality).displayName()));
        }
        if (type == CustomItem.CATALYST_MATRIX) {
            double contamination = contamination(stack);
            lines.add(Text.lore(String.format(java.util.Locale.ROOT, "Contamination: %.1f%%", contamination)));
            lines.add(contamination >= 70.0 ? Text.bad("Activity severely degraded")
                : contamination >= 35.0 ? Text.accent("Activity partially degraded") : Text.good("Catalyst surface healthy"));
        }
        if (type == CustomItem.VOID_CODEX) {
            lines.add(Component.empty());
            lines.add(Text.accent("Right-click to open."));
        }
        if (type.category() == CustomItem.Category.MACHINE) {
            lines.add(Component.empty());
            lines.add(Text.accent("VoidCore machine"));
            double wear = machineWear(stack);
            if (wear > 0.05) {
                lines.add(wear >= 99.95 ? Text.bad(String.format(java.util.Locale.ROOT, "Wear: %.1f%% • SERVICE LOCKOUT", wear))
                    : Text.lore(String.format(java.util.Locale.ROOT, "Wear: %.1f%%", wear)));
            }
            double entropy = machineEntropy(stack);
            if (entropy > 0.05) lines.add(Text.lore(String.format(java.util.Locale.ROOT, "Stored entropy: %.1f", entropy)));
            MachineFault fault = machineFault(stack);
            if (fault != MachineFault.NONE) lines.add(fault.hardLock() ? Text.bad("Fault: " + fault.displayName()) : Text.accent("Fault: " + fault.displayName()));
            long cycles = machineCycles(stack);
            if (cycles > 0) lines.add(Text.muted("Lifetime cycles: " + cycles + " • items: " + machineItemsProduced(stack)));
            long incidents = machineIncidents(stack);
            if (incidents > 0) lines.add(Text.bad("Recovered incidents: " + incidents));
            if (machineAutomationGroup(stack) > 0 || machineSignalChannel(stack) > 0 || machineSignalGate(stack) != SignalGate.IGNORE) {
                lines.add(Text.muted("Automation: G" + machineAutomationGroup(stack) + " • CH" + machineSignalChannel(stack) + " • " + machineSignalGate(stack).displayName()));
            }
        }
        if (type.category() == CustomItem.Category.UPGRADE) {
            lines.add(Component.empty());
            lines.add(Text.accent("Install in an engineering machine upgrade socket."));
        }
        return lines;
    }

    private int clampQuality(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private double clampPercent(double value) {
        return Math.max(0.0, Math.min(100.0, value));
    }
}
