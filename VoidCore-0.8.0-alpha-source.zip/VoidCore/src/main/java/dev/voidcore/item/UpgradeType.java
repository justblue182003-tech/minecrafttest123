package dev.voidcore.item;

public enum UpgradeType {
    SPEED_GOVERNOR(CustomItem.SPEED_GOVERNOR, "Cycle Governor", "Increases process throughput at the cost of tighter tuning."),
    FLUX_REGULATOR(CustomItem.FLUX_REGULATOR, "Flux Regulator", "Reduces flux consumed per completed process."),
    THERMAL_COUPLER(CustomItem.THERMAL_COUPLER, "Thermal Coupler", "Improves active heating response without removing thermal inertia."),
    COOLING_JACKET(CustomItem.COOLING_JACKET, "Cooling Jacket", "Improves active cooling response below ambient temperature."),
    CATALYST_FILTER(CustomItem.CATALYST_FILTER, "Catalyst Filter", "Reduces contamination gained during catalytic reactions."),
    PHASE_INTERFACE(CustomItem.PHASE_INTERFACE, "Phase Interface", "Allows automatic item transfer across a connected Flux Bus graph.");

    private final CustomItem item;
    private final String displayName;
    private final String description;

    UpgradeType(CustomItem item, String displayName, String description) {
        this.item = item;
        this.displayName = displayName;
        this.description = description;
    }

    public CustomItem item() { return item; }
    public String displayName() { return displayName; }
    public String description() { return description; }

    public static UpgradeType fromItem(CustomItem item) {
        if (item == null) return null;
        for (UpgradeType type : values()) if (type.item == item) return type;
        return null;
    }
}
