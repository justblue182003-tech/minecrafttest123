package dev.voidcore.machine;

import org.bukkit.Material;

/** Condition evaluated by an Automation Terminal before it drives a signal channel. */
public enum AutomationRule {
    ALWAYS("always", "Always High", Material.LIME_DYE, "Continuously drives the selected signal channel."),
    ENTROPY_HIGH("entropy_high", "Entropy High", Material.SCULK, "High when any machine in the selected group is above 70% entropy capacity."),
    FLUX_LOW("flux_low", "Flux Low", Material.REDSTONE, "High when any powered machine in the selected group is below 20% Flux."),
    OUTPUT_BLOCKED("output_blocked", "Output Blocked", Material.HOPPER, "High when any selected machine has a blocked process output."),
    FIELD_UNSTABLE("field_unstable", "Field Unstable", Material.LODESTONE, "High when any selected machine falls below 75% spatial stability."),
    WEAR_HIGH("wear_high", "Wear High", Material.ANVIL, "High when any selected machine exceeds 80% wear."),
    FAULT_ACTIVE("fault_active", "Fault Active", Material.REDSTONE_TORCH, "High when any selected machine has an active fault."),
    COMPUTATION_LOW("computation_low", "Computation Low", Material.DAYLIGHT_DETECTOR, "High when a computation-capable selected machine falls below 20% buffer.");

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String description;

    AutomationRule(String id, String displayName, Material icon, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public String description() { return description; }

    public static AutomationRule fromId(String id) {
        if (id == null) return ALWAYS;
        for (AutomationRule rule : values()) if (rule.id.equalsIgnoreCase(id)) return rule;
        return ALWAYS;
    }
}
