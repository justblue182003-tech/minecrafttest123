package dev.voidcore.machine;

import dev.voidcore.item.CustomItem;
import dev.voidcore.research.ResearchNode;

public enum MachineType {
    FLUX_CRUCIBLE("flux_crucible", "Flux Crucible", CustomItem.FLUX_CRUCIBLE, ResearchNode.FLUX_HANDLING, 0, 1.0, 20.0, 20.0, 250.0, 1.0, 0.2, 2.0),
    PROTOTYPE_BENCH("prototype_bench", "Prototype Bench", CustomItem.PROTOTYPE_BENCH, ResearchNode.FIELD_FABRICATION, 0, 1.0, 20.0, 20.0, 100.0, 1.0, 0.2, 2.0),
    SPECTRUM_ANALYZER("spectrum_analyzer", "Spectrum Analyzer", CustomItem.SPECTRUM_ANALYZER, ResearchNode.SPECTRAL_ANALYSIS, 0, 1.0, 20.0, 20.0, 100.0, 1.0, 0.2, 2.0),
    INDUCTION_HEATER("induction_heater", "Induction Heater", CustomItem.INDUCTION_HEATER, ResearchNode.THERMAL_ENGINEERING, 3, 7.0, 600.0, 20.0, 980.0, 1.0, 0.2, 2.0),
    CATALYTIC_REACTOR("catalytic_reactor", "Catalytic Reactor", CustomItem.CATALYTIC_REACTOR, ResearchNode.CATALYTIC_MATRICES, 3, 10.0, 500.0, 20.0, 760.0, 1.0, 0.2, 2.0),
    MATRIX_PURIFIER("matrix_purifier", "Matrix Purifier", CustomItem.MATRIX_PURIFIER, ResearchNode.CATALYTIC_MATRICES, 3, 8.0, 250.0, 20.0, 520.0, 1.0, 0.2, 2.0),
    CRYOGENIC_COLUMN("cryogenic_column", "Cryogenic Column", CustomItem.CRYOGENIC_COLUMN, ResearchNode.THERMAL_INFRASTRUCTURE, 3, 14.0, -80.0, -180.0, 180.0, 1.0, 0.2, 2.0),
    THERMAL_EXCHANGER("thermal_exchanger", "Thermal Exchanger", CustomItem.THERMAL_EXCHANGER, ResearchNode.THERMAL_INFRASTRUCTURE, 0, 12.0, 20.0, -120.0, 980.0, 1.0, 0.2, 2.0),
    FLUX_BUS("flux_bus", "Flux Bus", CustomItem.FLUX_BUS, ResearchNode.QUANTUM_ROUTING, 0, 1.0, 20.0, 20.0, 20.0, 1.0, 0.2, 2.0),
    ADDRESS_NODE("address_node", "Address Node", CustomItem.ADDRESS_NODE, ResearchNode.QUANTUM_ROUTING, 0, 1.0, 20.0, 20.0, 20.0, 1.0, 0.2, 2.0),
    PHASE_ROUTER("phase_router", "Phase Router", CustomItem.PHASE_ROUTER, ResearchNode.QUANTUM_ROUTING, 0, 1.0, 20.0, 20.0, 20.0, 1.0, 0.2, 2.0),
    PRIORITY_BUFFER("priority_buffer", "Priority Buffer", CustomItem.PRIORITY_BUFFER, ResearchNode.QUANTUM_ROUTING, 0, 1.0, 20.0, 20.0, 20.0, 1.0, 0.2, 2.0),
    FREQUENCY_SPLITTER("frequency_splitter", "Frequency Splitter", CustomItem.FREQUENCY_SPLITTER, ResearchNode.QUANTUM_ROUTING, 0, 1.0, 20.0, 20.0, 20.0, 1.0, 0.2, 2.0),
    PRESSURE_VESSEL("pressure_vessel", "Pressure Vessel", CustomItem.PRESSURE_VESSEL, ResearchNode.PRESSURE_DYNAMICS, 3, 16.0, 220.0, 20.0, 540.0, 5.0, 0.5, 12.0),
    PHASE_OBSERVER("phase_observer", "Phase Observer", CustomItem.PHASE_OBSERVER, ResearchNode.ENTROPY_CONDENSATION, 0, 4.0, 20.0, -80.0, 180.0, 1.0, 0.2, 2.0),
    ENTROPY_CONDENSER("entropy_condenser", "Entropy Condenser Array", CustomItem.ENTROPY_CONDENSER, ResearchNode.ENTROPY_CONDENSATION, 3, 22.0, 140.0, -20.0, 520.0, 1.0, 0.2, 2.0),
    FIELD_STABILIZER("field_stabilizer", "Field Stabilizer", CustomItem.FIELD_STABILIZER, ResearchNode.SPATIAL_ENGINEERING, 0, 8.0, 20.0, -40.0, 220.0, 1.0, 0.2, 2.0),
    CONTROL_MATRIX("control_matrix", "Control Matrix", CustomItem.CONTROL_MATRIX, ResearchNode.SPATIAL_ENGINEERING, 0, 4.0, 20.0, 20.0, 80.0, 1.0, 0.2, 2.0),
    VOID_CORE("void_core", "Void Core", CustomItem.VOID_CORE, ResearchNode.VOID_CORE_ARCHITECTURE, 3, 30.0, 120.0, -40.0, 480.0, 1.0, 0.2, 2.0),
    AUTOMATION_TERMINAL("automation_terminal", "Automation Terminal", CustomItem.AUTOMATION_TERMINAL, ResearchNode.AUTOMATION_ARCHITECTURE, 0, 1.0, 20.0, 20.0, 80.0, 1.0, 0.2, 2.0),
    VOID_UPGRADE_CHAMBER("void_upgrade_chamber", "Void Core Upgrade Chamber", CustomItem.VOID_UPGRADE_CHAMBER, ResearchNode.AUTOMATION_ARCHITECTURE, 0, 14.0, 20.0, -40.0, 280.0, 1.0, 0.2, 2.0),
    DIMENSIONAL_ANCHOR("dimensional_anchor", "Dimensional Anchor", CustomItem.DIMENSIONAL_ANCHOR, ResearchNode.DIMENSIONAL_INFRASTRUCTURE, 0, 1.0, 20.0, -40.0, 180.0, 1.0, 0.2, 2.0),
    PROJECT_TERMINAL("project_terminal", "Project Nullstar Terminal", CustomItem.PROJECT_TERMINAL, ResearchNode.DIMENSIONAL_INFRASTRUCTURE, 0, 1.0, 20.0, 20.0, 80.0, 1.0, 0.2, 2.0);

    private final String id;
    private final String displayName;
    private final CustomItem item;
    private final ResearchNode research;
    private final int upgradeSlots;
    private final double thermalMass;
    private final double defaultTargetHeat;
    private final double minimumSafeHeat;
    private final double maximumSafeHeat;
    private final double defaultTargetPressure;
    private final double minimumSafePressure;
    private final double maximumSafePressure;

    MachineType(String id, String displayName, CustomItem item, ResearchNode research,
                int upgradeSlots, double thermalMass, double defaultTargetHeat,
                double minimumSafeHeat, double maximumSafeHeat,
                double defaultTargetPressure, double minimumSafePressure, double maximumSafePressure) {
        this.id = id;
        this.displayName = displayName;
        this.item = item;
        this.research = research;
        this.upgradeSlots = upgradeSlots;
        this.thermalMass = thermalMass;
        this.defaultTargetHeat = defaultTargetHeat;
        this.minimumSafeHeat = minimumSafeHeat;
        this.maximumSafeHeat = maximumSafeHeat;
        this.defaultTargetPressure = defaultTargetPressure;
        this.minimumSafePressure = minimumSafePressure;
        this.maximumSafePressure = maximumSafePressure;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public CustomItem item() { return item; }
    public ResearchNode research() { return research; }
    public int upgradeSlots() { return upgradeSlots; }
    public double thermalMass() { return thermalMass; }
    public double defaultTargetHeat() { return defaultTargetHeat; }
    public double minimumSafeHeat() { return minimumSafeHeat; }
    public double maximumSafeHeat() { return maximumSafeHeat; }
    public double defaultTargetPressure() { return defaultTargetPressure; }
    public double minimumSafePressure() { return minimumSafePressure; }
    public double maximumSafePressure() { return maximumSafePressure; }

    public boolean isEngineeringProcessor() {
        return this == INDUCTION_HEATER || this == CATALYTIC_REACTOR || this == MATRIX_PURIFIER
            || this == CRYOGENIC_COLUMN || this == PRESSURE_VESSEL || this == ENTROPY_CONDENSER || this == VOID_CORE;
    }

    public boolean usesPressure() { return this == PRESSURE_VESSEL; }

    public boolean isObserver() { return this == PHASE_OBSERVER; }

    public boolean isMultiblockController() { return this == ENTROPY_CONDENSER || this == VOID_CORE; }

    public boolean isFieldStabilizer() { return this == FIELD_STABILIZER; }
    public boolean isControlMatrix() { return this == CONTROL_MATRIX; }
    public boolean isAutomationTerminal() { return this == AUTOMATION_TERMINAL; }
    public boolean isCoreUpgradeChamber() { return this == VOID_UPGRADE_CHAMBER; }
    public boolean isDimensionalAnchor() { return this == DIMENSIONAL_ANCHOR; }
    public boolean isProjectTerminal() { return this == PROJECT_TERMINAL; }

    public boolean isThermalInfrastructure() { return this == THERMAL_EXCHANGER; }

    public boolean isNetworkBlock() {
        return this == FLUX_BUS || this == ADDRESS_NODE || this == PHASE_ROUTER
            || this == PRIORITY_BUFFER || this == FREQUENCY_SPLITTER || this == CONTROL_MATRIX
            || this == AUTOMATION_TERMINAL || this == DIMENSIONAL_ANCHOR || this == PROJECT_TERMINAL;
    }

    public boolean isConfigurableLogisticsNode() {
        return this == PHASE_ROUTER || this == PRIORITY_BUFFER || this == FREQUENCY_SPLITTER;
    }

    public boolean isRoutingBuffer() { return this == PRIORITY_BUFFER; }

    public boolean canConnectToFluxBus() {
        return this == FLUX_CRUCIBLE || isEngineeringProcessor() || this == PHASE_OBSERVER || this == FIELD_STABILIZER
            || this == VOID_UPGRADE_CHAMBER;
    }

    public static MachineType fromId(String id) {
        if (id == null) return null;
        for (MachineType type : values()) if (type.id.equalsIgnoreCase(id)) return type;
        return null;
    }

    public static MachineType fromItem(CustomItem item) {
        if (item == null) return null;
        for (MachineType type : values()) if (type.item == item) return type;
        return null;
    }
}
