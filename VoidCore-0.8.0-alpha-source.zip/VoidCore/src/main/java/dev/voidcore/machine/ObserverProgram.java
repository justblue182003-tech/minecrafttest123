package dev.voidcore.machine;

import org.bukkit.Material;

public enum ObserverProgram {
    BROAD_SPECTRUM("broad_spectrum", "Broad Spectrum", Material.SPYGLASS,
        "Combine every detectable environmental correlation into one general signal."),
    CELESTIAL_TRACKING("celestial_tracking", "Celestial Tracking", Material.CLOCK,
        "Favor open-sky and clear-night observations."),
    SCULK_CORRELATION("sculk_correlation", "Sculk Correlation", Material.SCULK_SENSOR,
        "Favor dense local sculk resonance and suppress unrelated dimensional noise."),
    DIMENSIONAL_BASELINE("dimensional_baseline", "Dimensional Baseline", Material.ENDER_EYE,
        "Measure dimension-specific phase offsets, strongest in the End."),
    ENTROPY_WATCH("entropy_watch", "Entropy Watch", Material.CALIBRATED_SCULK_SENSOR,
        "Observe nearby machines for elevated entropy pressure and convert anomalies into computation.");

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String description;

    ObserverProgram(String id, String displayName, Material icon, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public String description() { return description; }

    public ObserverProgram next(int direction) {
        ObserverProgram[] values = values();
        return values[Math.floorMod(ordinal() + (direction >= 0 ? 1 : -1), values.length)];
    }

    public static ObserverProgram fromId(String id) {
        if (id == null) return BROAD_SPECTRUM;
        for (ObserverProgram program : values()) if (program.id.equalsIgnoreCase(id)) return program;
        return BROAD_SPECTRUM;
    }
}
