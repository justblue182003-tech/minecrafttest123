package dev.voidcore.machine;

import dev.voidcore.item.CustomItem;
import org.bukkit.Material;

public enum MachineFault {
    NONE("none", "No Fault", Material.LIME_DYE, null,
        "All protected systems report nominal."),
    BEARING_FAILURE("bearing_failure", "Bearing Failure", Material.ANVIL, CustomItem.REPAIR_PARTS,
        "Mechanical wear has exceeded the safe operating envelope."),
    THERMAL_RUNAWAY("thermal_runaway", "Thermal Runaway", Material.FIRE_CHARGE, CustomItem.REPAIR_PARTS,
        "A control element failed while the chamber was outside its safe thermal range."),
    SEAL_LEAK("seal_leak", "Pressure Seal Leak", Material.IRON_TRAPDOOR, CustomItem.PRESSURE_SEAL,
        "The pressure boundary can no longer hold the requested compression ratio."),
    ROUTING_DESYNC("routing_desync", "Routing Desynchronization", Material.ENDER_EYE, CustomItem.REPAIR_PARTS,
        "The phase-routing controller lost deterministic address lock."),
    COHERENCE_DRIFT("coherence_drift", "Coherence Drift", Material.CALIBRATED_SCULK_SENSOR, CustomItem.COHERENCE_DAMPER,
        "Entropy noise is corrupting process timing. The machine still runs, but efficiency and output quality are degraded."),
    ENTROPY_SURGE("entropy_surge", "Entropy Surge", Material.SCULK_CATALYST, CustomItem.CONTAINMENT_FUSE,
        "Unrecovered coherence drift has escalated into a hard entropy surge."),
    CONTAINMENT_BREACH("containment_breach", "Containment Breach", Material.REINFORCED_DEEPSLATE, CustomItem.CONTAINMENT_FUSE,
        "The entropy path has breached containment. Operation is locked until the failed cutoff is replaced."),
    FIELD_DESYNC("field_desync", "Spatial Field Desynchronization", Material.ENDER_EYE, CustomItem.SPATIAL_ANCHOR,
        "The local coherence field is oscillating below the controller's stable operating margin."),
    FIELD_COLLAPSE("field_collapse", "Spatial Field Collapse", Material.CRYING_OBSIDIAN, CustomItem.SPATIAL_ANCHOR,
        "The Void Core dropped out of spatial lock. Nearby machinery absorbed a recoverable entropy and wear pulse." );

    private final String id;
    private final String displayName;
    private final Material icon;
    private final CustomItem repairItem;
    private final String description;

    MachineFault(String id, String displayName, Material icon, CustomItem repairItem, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.repairItem = repairItem;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public CustomItem repairItem() { return repairItem; }
    public String description() { return description; }

    public boolean hardLock() {
        return switch (this) {
            case NONE, COHERENCE_DRIFT, FIELD_DESYNC -> false;
            default -> true;
        };
    }

    public boolean entropyChain() {
        return this == COHERENCE_DRIFT || this == ENTROPY_SURGE || this == CONTAINMENT_BREACH;
    }

    public boolean fieldChain() { return this == FIELD_DESYNC || this == FIELD_COLLAPSE; }

    public MachineFault nextEntropyStage() {
        return switch (this) {
            case COHERENCE_DRIFT -> ENTROPY_SURGE;
            case ENTROPY_SURGE -> CONTAINMENT_BREACH;
            default -> this;
        };
    }

    public static MachineFault fromId(String id) {
        if (id == null) return NONE;
        for (MachineFault fault : values()) if (fault.id.equalsIgnoreCase(id)) return fault;
        return NONE;
    }
}
