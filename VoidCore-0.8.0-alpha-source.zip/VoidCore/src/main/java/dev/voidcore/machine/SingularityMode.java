package dev.voidcore.machine;

import org.bukkit.Material;

/** Operator-selected Void Core state. More aggressive states require matching upgrade chambers. */
public enum SingularityMode {
    CONTAINED("contained", "Contained", Material.BLUE_STAINED_GLASS, 1.00, 1.00, 1.00, 1.00,
        "Conservative containment. Baseline throughput and lowest incident pressure."),
    COMPRESSED("compressed", "Compressed", Material.PURPLE_STAINED_GLASS, 1.24, 1.16, 1.45, 1.35,
        "Compresses the singularity for faster cycles at higher Flux, wear, and entropy cost."),
    EXTRACTION("extraction", "Extraction", Material.MAGENTA_STAINED_GLASS, 1.42, 1.30, 1.90, 1.65,
        "Aggressive extraction. Highest throughput and the narrowest safety margin."),
    QUIESCENT("quiescent", "Quiescent", Material.BLACK_STAINED_GLASS, 0.55, 0.70, 0.35, 0.55,
        "Low-activity hold state for safe stabilization and maintenance.");

    private final String id;
    private final String displayName;
    private final Material icon;
    private final double speedMultiplier;
    private final double fluxMultiplier;
    private final double entropyMultiplier;
    private final double wearMultiplier;
    private final String description;

    SingularityMode(String id, String displayName, Material icon, double speedMultiplier, double fluxMultiplier,
                    double entropyMultiplier, double wearMultiplier, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.speedMultiplier = speedMultiplier;
        this.fluxMultiplier = fluxMultiplier;
        this.entropyMultiplier = entropyMultiplier;
        this.wearMultiplier = wearMultiplier;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public double speedMultiplier() { return speedMultiplier; }
    public double fluxMultiplier() { return fluxMultiplier; }
    public double entropyMultiplier() { return entropyMultiplier; }
    public double wearMultiplier() { return wearMultiplier; }
    public String description() { return description; }

    public static SingularityMode fromId(String id) {
        if (id == null) return CONTAINED;
        for (SingularityMode mode : values()) if (mode.id.equalsIgnoreCase(id)) return mode;
        return CONTAINED;
    }
}
