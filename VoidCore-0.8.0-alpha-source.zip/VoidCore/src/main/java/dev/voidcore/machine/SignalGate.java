package dev.voidcore.machine;

import org.bukkit.Material;

/** How a machine reacts to the boolean state of its configured signal channel. */
public enum SignalGate {
    IGNORE("ignore", "Ignore Signal", Material.GRAY_DYE, "Automation never blocks this machine."),
    REQUIRE_HIGH("require_high", "Require High", Material.LIME_DYE, "The machine may process only while its signal channel is high."),
    REQUIRE_LOW("require_low", "Require Low", Material.RED_DYE, "The machine may process only while its signal channel is low.");

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String description;

    SignalGate(String id, String displayName, Material icon, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public String description() { return description; }

    public static SignalGate fromId(String id) {
        if (id == null) return IGNORE;
        for (SignalGate gate : values()) if (gate.id.equalsIgnoreCase(id)) return gate;
        return IGNORE;
    }
}
