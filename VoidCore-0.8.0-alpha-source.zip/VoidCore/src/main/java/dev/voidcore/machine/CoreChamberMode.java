package dev.voidcore.machine;

import org.bukkit.Material;

/** Function of a Void Core Upgrade Chamber placed near a controller. */
public enum CoreChamberMode {
    STABILIZATION("stabilization", "Stabilization Chamber", Material.LODESTONE,
        "Raises local field stability and reduces singularity incident pressure."),
    COMPRESSION("compression", "Compression Chamber", Material.PISTON,
        "Enables the Compressed singularity state and improves controlled density."),
    EXTRACTION("extraction", "Extraction Chamber", Material.HOPPER,
        "Enables Extraction state and improves endgame material recovery.");

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String description;

    CoreChamberMode(String id, String displayName, Material icon, String description) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public String description() { return description; }

    public static CoreChamberMode fromId(String id) {
        if (id == null) return STABILIZATION;
        for (CoreChamberMode mode : values()) if (mode.id.equalsIgnoreCase(id)) return mode;
        return STABILIZATION;
    }
}
