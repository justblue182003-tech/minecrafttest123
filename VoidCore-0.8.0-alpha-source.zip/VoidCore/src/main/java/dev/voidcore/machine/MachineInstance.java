package dev.voidcore.machine;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;

public final class MachineInstance {
    private final Location location;
    private final MachineType type;
    private final ItemStack[] upgrades = new ItemStack[3];
    private int flux;
    private double progress;
    private double heat = 20.0;
    private double targetHeat;
    private double pressure = 1.0;
    private double targetPressure;
    private int quality = 50;
    private double wear;
    private double entropy;
    private int computation;
    private MachineFault fault = MachineFault.NONE;
    private int faultTicks;
    private boolean structureValid = true;
    private String structureIssue = "Not applicable";
    private ItemStack input;
    private ItemStack secondaryInput;
    private ItemStack catalyst;
    private ItemStack fuel;
    private ItemStack output;
    private ItemStack byproduct;
    private String completedProcessId;
    private String selectedProcessId;
    private int networkFrequency = 1;
    private int secondaryNetworkFrequency = 2;
    private int routingPriority = 5;
    private String routingFilterId;
    private double lastHeatTransfer;
    private ObserverProgram observerProgram = ObserverProgram.BROAD_SPECTRUM;
    private ControlDirective controlDirective = ControlDirective.BALANCED;
    private ControlDirective activeDirective = ControlDirective.BALANCED;
    private double fieldStability = 50.0;
    private long lifetimeCycles;
    private long lifetimeItemsProduced;
    private long lifetimeFluxConsumed;
    private double lifetimeEntropyProcessed;
    private long incidentCount;
    private int automationGroup;
    private int signalChannel;
    private SignalGate signalGate = SignalGate.IGNORE;
    private AutomationRule automationRule = AutomationRule.ALWAYS;
    private boolean signalHigh;
    private SingularityMode singularityMode = SingularityMode.CONTAINED;
    private CoreChamberMode coreChamberMode = CoreChamberMode.STABILIZATION;
    private final Map<String, Long> productionLedger = new LinkedHashMap<>();

    public MachineInstance(Location location, MachineType type) {
        this.location = location.clone();
        this.type = type;
        this.targetHeat = type.defaultTargetHeat();
        this.targetPressure = type.defaultTargetPressure();
    }

    public Location location() { return location.clone(); }
    public MachineType type() { return type; }
    public int flux() { return flux; }
    public void flux(int flux) { this.flux = Math.max(0, flux); }
    public double progress() { return progress; }
    public void progress(double progress) { this.progress = Math.max(0.0, progress); }
    public double heat() { return heat; }
    public void heat(double heat) { this.heat = heat; }
    public double targetHeat() { return targetHeat; }
    public void targetHeat(double targetHeat) { this.targetHeat = targetHeat; }
    public double pressure() { return pressure; }
    public void pressure(double pressure) { this.pressure = Math.max(0.0, pressure); }
    public double targetPressure() { return targetPressure; }
    public void targetPressure(double targetPressure) { this.targetPressure = Math.max(0.0, targetPressure); }
    public int quality() { return quality; }
    public void quality(int quality) { this.quality = Math.max(0, Math.min(100, quality)); }
    public double wear() { return wear; }
    public void wear(double wear) { this.wear = Math.max(0.0, Math.min(100.0, wear)); }
    public double entropy() { return entropy; }
    public void entropy(double entropy) { this.entropy = Math.max(0.0, Math.min(10000.0, entropy)); }
    public int computation() { return computation; }
    public void computation(int computation) { this.computation = Math.max(0, Math.min(100000, computation)); }
    public MachineFault fault() { return fault; }
    public void fault(MachineFault fault) { this.fault = fault == null ? MachineFault.NONE : fault; }
    public int faultTicks() { return faultTicks; }
    public void faultTicks(int ticks) { this.faultTicks = Math.max(0, ticks); }
    public boolean hasFault() { return fault != MachineFault.NONE; }
    public boolean faulted() { return fault.hardLock(); }
    public boolean maintenanceLocked() { return wear >= 99.95 || faulted(); }
    public boolean structureValid() { return structureValid; }
    public void structureStatus(boolean valid, String issue) { this.structureValid = valid; this.structureIssue = issue == null ? "Unknown" : issue; }
    public String structureIssue() { return structureIssue; }
    public ItemStack input() { return cloneOrNull(input); }
    public void input(ItemStack input) { this.input = cloneOrNull(input); }
    public ItemStack secondaryInput() { return cloneOrNull(secondaryInput); }
    public void secondaryInput(ItemStack secondaryInput) { this.secondaryInput = cloneOrNull(secondaryInput); }
    public ItemStack catalyst() { return cloneOrNull(catalyst); }
    public void catalyst(ItemStack catalyst) { this.catalyst = cloneOrNull(catalyst); }
    public ItemStack fuel() { return cloneOrNull(fuel); }
    public void fuel(ItemStack fuel) { this.fuel = cloneOrNull(fuel); }
    public ItemStack output() { return cloneOrNull(output); }
    public void output(ItemStack output) { this.output = cloneOrNull(output); }
    public ItemStack byproduct() { return cloneOrNull(byproduct); }
    public void byproduct(ItemStack byproduct) { this.byproduct = cloneOrNull(byproduct); }
    public String completedProcessId() { return completedProcessId; }
    public void completedProcessId(String completedProcessId) { this.completedProcessId = completedProcessId; }
    public String selectedProcessId() { return selectedProcessId; }
    public void selectedProcessId(String selectedProcessId) { this.selectedProcessId = selectedProcessId; }
    public int networkFrequency() { return networkFrequency; }
    public void networkFrequency(int networkFrequency) { this.networkFrequency = Math.max(1, Math.min(999, networkFrequency)); }
    public int secondaryNetworkFrequency() { return secondaryNetworkFrequency; }
    public void secondaryNetworkFrequency(int frequency) { this.secondaryNetworkFrequency = Math.max(1, Math.min(999, frequency)); }
    public int routingPriority() { return routingPriority; }
    public void routingPriority(int priority) { this.routingPriority = Math.max(0, Math.min(9, priority)); }
    public String routingFilterId() { return routingFilterId; }
    public void routingFilterId(String routingFilterId) { this.routingFilterId = routingFilterId == null || routingFilterId.isBlank() ? null : routingFilterId; }
    public double lastHeatTransfer() { return lastHeatTransfer; }
    public void lastHeatTransfer(double lastHeatTransfer) { this.lastHeatTransfer = Math.max(0.0, lastHeatTransfer); }
    public ObserverProgram observerProgram() { return observerProgram; }
    public void observerProgram(ObserverProgram observerProgram) { this.observerProgram = observerProgram == null ? ObserverProgram.BROAD_SPECTRUM : observerProgram; }
    public ControlDirective controlDirective() { return controlDirective; }
    public void controlDirective(ControlDirective directive) { this.controlDirective = directive == null ? ControlDirective.BALANCED : directive; }
    public ControlDirective activeDirective() { return activeDirective; }
    public void activeDirective(ControlDirective directive) { this.activeDirective = directive == null ? ControlDirective.BALANCED : directive; }
    public double fieldStability() { return fieldStability; }
    public void fieldStability(double fieldStability) { this.fieldStability = Math.max(0.0, Math.min(100.0, fieldStability)); }
    public long lifetimeCycles() { return lifetimeCycles; }
    public void lifetimeCycles(long value) { this.lifetimeCycles = Math.max(0L, value); }
    public long lifetimeItemsProduced() { return lifetimeItemsProduced; }
    public void lifetimeItemsProduced(long value) { this.lifetimeItemsProduced = Math.max(0L, value); }
    public long lifetimeFluxConsumed() { return lifetimeFluxConsumed; }
    public void lifetimeFluxConsumed(long value) { this.lifetimeFluxConsumed = Math.max(0L, value); }
    public double lifetimeEntropyProcessed() { return lifetimeEntropyProcessed; }
    public void lifetimeEntropyProcessed(double value) { this.lifetimeEntropyProcessed = Math.max(0.0, value); }
    public long incidentCount() { return incidentCount; }
    public void incidentCount(long value) { this.incidentCount = Math.max(0L, value); }
    public int automationGroup() { return automationGroup; }
    public void automationGroup(int group) { this.automationGroup = Math.max(0, Math.min(7, group)); }
    public int signalChannel() { return signalChannel; }
    public void signalChannel(int channel) { this.signalChannel = Math.max(0, Math.min(15, channel)); }
    public SignalGate signalGate() { return signalGate; }
    public void signalGate(SignalGate gate) { this.signalGate = gate == null ? SignalGate.IGNORE : gate; }
    public AutomationRule automationRule() { return automationRule; }
    public void automationRule(AutomationRule rule) { this.automationRule = rule == null ? AutomationRule.ALWAYS : rule; }
    public boolean signalHigh() { return signalHigh; }
    public void signalHigh(boolean high) { this.signalHigh = high; }
    public boolean automationAllowsRun() {
        return switch (signalGate) {
            case IGNORE -> true;
            case REQUIRE_HIGH -> signalHigh;
            case REQUIRE_LOW -> !signalHigh;
        };
    }
    public SingularityMode singularityMode() { return singularityMode; }
    public void singularityMode(SingularityMode mode) { this.singularityMode = mode == null ? SingularityMode.CONTAINED : mode; }
    public CoreChamberMode coreChamberMode() { return coreChamberMode; }
    public void coreChamberMode(CoreChamberMode mode) { this.coreChamberMode = mode == null ? CoreChamberMode.STABILIZATION : mode; }
    public Map<String, Long> productionLedger() { return Map.copyOf(productionLedger); }
    public void productionLedger(Map<String, Long> values) {
        productionLedger.clear();
        if (values == null) return;
        values.forEach((id, amount) -> {
            if (id != null && !id.isBlank() && amount != null && amount > 0L) productionLedger.put(id, amount);
        });
    }
    public void recordProduction(String itemId, long amount) {
        if (itemId == null || itemId.isBlank() || amount <= 0L) return;
        productionLedger.merge(itemId, amount, Long::sum);
    }
    public long produced(String itemId) { return productionLedger.getOrDefault(itemId, 0L); }

    public boolean consumeFlux(int amount) {
        if (amount <= 0 || flux < amount) return false;
        flux -= amount;
        lifetimeFluxConsumed += amount;
        return true;
    }

    public void recordCycle(int producedItems, double entropyProcessed) {
        lifetimeCycles++;
        lifetimeItemsProduced += Math.max(0, producedItems);
        lifetimeEntropyProcessed += Math.max(0.0, entropyProcessed);
    }

    public void recordIncident() { incidentCount++; }

    public ItemStack upgrade(int slot) {
        if (slot < 0 || slot >= upgrades.length) return null;
        return cloneOrNull(upgrades[slot]);
    }

    public void upgrade(int slot, ItemStack item) {
        if (slot < 0 || slot >= upgrades.length) return;
        upgrades[slot] = cloneOrNull(item);
    }

    private static ItemStack cloneOrNull(ItemStack item) {
        return item == null ? null : item.clone();
    }
}
