package dev.voidcore.machine;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.item.UpgradeType;
import dev.voidcore.multiblock.EntropyCondenserStructure;
import dev.voidcore.multiblock.VoidCoreStructure;
import dev.voidcore.process.ProcessEnvironment;
import dev.voidcore.persistence.MachineRepository;
import dev.voidcore.persistence.MachineSnapshot;
import dev.voidcore.process.ProcessEngine;
import dev.voidcore.process.ProcessMode;
import dev.voidcore.process.ProcessRecipe;
import dev.voidcore.process.ProcessRegistry;
import dev.voidcore.process.ProcessTuning;
import dev.voidcore.simulation.EngineeringMath;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class MachineService {
    private static final double AMBIENT_HEAT = 20.0;

    private final VoidCorePlugin plugin;
    private final ItemService items;
    private final ProcessRegistry processRecipes;
    private final ProcessEngine processEngine;
    private final MachineRepository repository;
    private final Map<String, MachineInstance> machines = new HashMap<>();
    private final Map<String, ProcessEngine.TickState> processStates = new HashMap<>();
    private boolean dirty;
    private long revision;
    private boolean saveInFlight;

    public MachineService(VoidCorePlugin plugin, ItemService items, ProcessRegistry processRecipes,
                          ProcessEngine processEngine, MachineRepository repository) {
        this.plugin = plugin;
        this.items = items;
        this.processRecipes = processRecipes;
        this.processEngine = processEngine;
        this.repository = repository;
    }

    public void load() {
        machines.clear();
        processStates.clear();
        for (MachineInstance machine : repository.loadAll()) machines.put(key(machine.location()), machine);
        if (machines.isEmpty()) migrateLegacyYaml();
        dirty = false;
        revision = 0L;
        saveInFlight = false;
    }

    /** Main-thread snapshot + asynchronous JDBC write. No Bukkit objects cross into the async phase. */
    public void saveAsync() {
        if (!dirty || saveInFlight) return;
        List<MachineSnapshot> snapshot = machines.values().stream().map(MachineSnapshot::capture).toList();
        long capturedRevision = revision;
        saveInFlight = true;
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            boolean ok = repository.saveSnapshots(snapshot);
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                saveInFlight = false;
                if (ok && revision == capturedRevision) dirty = false;
            });
        });
    }

    public void saveNow() {
        if (!dirty) return;
        List<MachineSnapshot> snapshot = machines.values().stream().map(MachineSnapshot::capture).toList();
        long capturedRevision = revision;
        if (repository.saveSnapshots(snapshot) && revision == capturedRevision) dirty = false;
    }

    public void save() { saveNow(); }

    public MachineInstance register(Location location, MachineType type) {
        return register(location, type, null);
    }

    public MachineInstance register(Location location, MachineType type, ItemStack sourceItem) {
        MachineInstance instance = new MachineInstance(location.getBlock().getLocation(), type);
        if (sourceItem != null && items.hasQuality(sourceItem)) instance.quality(items.quality(sourceItem));
        if (sourceItem != null) {
            instance.wear(items.machineWear(sourceItem));
            instance.entropy(Math.min(entropyCapacity(type), items.machineEntropy(sourceItem)));
            instance.fault(items.machineFault(sourceItem));
            instance.faultTicks(items.machineFaultTicks(sourceItem));
            instance.observerProgram(items.machineObserverProgram(sourceItem));
            instance.controlDirective(items.machineControlDirective(sourceItem));
            instance.lifetimeCycles(items.machineCycles(sourceItem));
            instance.lifetimeItemsProduced(items.machineItemsProduced(sourceItem));
            instance.lifetimeFluxConsumed(items.machineFluxConsumed(sourceItem));
            instance.lifetimeEntropyProcessed(items.machineEntropyProcessed(sourceItem));
            instance.incidentCount(items.machineIncidents(sourceItem));
            instance.automationGroup(items.machineAutomationGroup(sourceItem));
            instance.signalChannel(items.machineSignalChannel(sourceItem));
            instance.signalGate(items.machineSignalGate(sourceItem));
            instance.automationRule(items.machineAutomationRule(sourceItem));
            instance.singularityMode(items.machineSingularityMode(sourceItem));
            instance.coreChamberMode(items.machineCoreChamberMode(sourceItem));
            instance.productionLedger(items.machineProductionLedger(sourceItem));
        }
        machines.put(key(location), instance);
        markDirty();
        return instance;
    }

    public MachineInstance get(Location location) { return machines.get(key(location)); }

    public Collection<MachineInstance> all() { return List.copyOf(machines.values()); }

    public MachineInstance unregister(Location location) {
        String key = key(location);
        processStates.remove(key);
        MachineInstance removed = machines.remove(key);
        if (removed != null) markDirty();
        return removed;
    }

    public boolean isMachine(Location location) { return machines.containsKey(key(location)); }
    public void markDirty() { dirty = true; revision++; }

    public void tick() {
        for (MachineInstance machine : new ArrayList<>(machines.values())) {
            if (machine.location().getWorld() == null) continue;
            if (!machine.location().isChunkLoaded()) continue;
            if (machine.location().getBlock().getType() != machine.type().item().material()) continue;

            machine.lastHeatTransfer(0.0);
            if (machine.type() == MachineType.PHASE_OBSERVER) {
                refuel(machine);
                tickObserver(machine);
                applyEntropyStress(machine);
                evaluateFaults(machine);
                clampResourceCaps(machine);
                continue;
            }
            if (machine.type() == MachineType.FIELD_STABILIZER) {
                refuel(machine);
                tickFieldStabilizer(machine);
                applyEntropyStress(machine);
                evaluateFaults(machine);
                clampResourceCaps(machine);
                continue;
            }
            if (machine.type() == MachineType.CONTROL_MATRIX || machine.type() == MachineType.AUTOMATION_TERMINAL
                || machine.type() == MachineType.DIMENSIONAL_ANCHOR || machine.type() == MachineType.PROJECT_TERMINAL) {
                clampResourceCaps(machine);
                continue;
            }
            if (machine.type() == MachineType.VOID_UPGRADE_CHAMBER) {
                refuel(machine);
                tickCoreUpgradeChamber(machine);
                clampResourceCaps(machine);
                continue;
            }
            if (machine.type() == MachineType.FLUX_CRUCIBLE) {
                refuel(machine);
                processFluxCrucible(machine);
                applyEntropyStress(machine);
                evaluateFaults(machine);
                clampResourceCaps(machine);
                continue;
            }
            if (machine.type() == MachineType.THERMAL_EXCHANGER) {
                tickThermalExchanger(machine);
                continue;
            }
            if (!machine.type().isEngineeringProcessor()) continue;

            if (machine.type().isMultiblockController()) refreshStructure(machine);
            refuel(machine);
            simulateHeat(machine);
            if (machine.type().usesPressure()) simulatePressure(machine);
            applyThermalStress(machine);
            applyEntropyStress(machine);
            evaluateFaults(machine);
            ProcessRecipe recipe = currentRecipe(machine);
            ProcessEngine.TickState state;
            if (!singularitySupports(machine, recipe)) {
                if (machine.progress() != 0.0) machine.progress(0.0);
                state = ProcessEngine.TickState.SINGULARITY_UNSUPPORTED;
            } else {
                state = processEngine.tick(machine, recipe, tuning(machine));
            }
            processStates.put(key(machine.location()), state);
            clampResourceCaps(machine);
            markDirty();
        }
    }

    private void refuel(MachineInstance machine) {
        if (!supportsFuel(machine.type()) || machine.flux() >= maxFlux(machine.type())) return;
        ItemStack fuel = machine.fuel();
        if (fuel == null) return;

        int value;
        if (fuel.getType() == Material.REDSTONE && items.identify(fuel) == null) value = redstoneFlux();
        else if (fuel.getType() == Material.REDSTONE_BLOCK && items.identify(fuel) == null) value = redstoneBlockFlux();
        else return;

        machine.flux(Math.min(maxFlux(machine.type()), machine.flux() + value));
        consumeOne(fuel);
        machine.fuel(fuel.getAmount() <= 0 ? null : fuel);
        markDirty();
    }

    private void processFluxCrucible(MachineInstance machine) {
        if (machine.maintenanceLocked() || !machine.automationAllowsRun()) return;
        ItemStack input = machine.input();
        if (!items.is(input, CustomItem.RESONANT_FRAGMENT)) {
            if (machine.progress() != 0.0) {
                machine.progress(0.0);
                markDirty();
            }
            return;
        }

        ItemStack output = machine.output();
        if (output != null && (!items.is(output, CustomItem.CHARGED_RESONANCE) || output.getAmount() >= output.getMaxStackSize())) return;

        int seconds = operationSeconds();
        int costPerSecond = Math.max(1, (int) Math.ceil(operationCost() / (double) seconds));
        if (machine.flux() < costPerSecond) return;

        machine.consumeFlux(costPerSecond);
        machine.progress(machine.progress() + 1.0);
        markDirty();
        if (machine.progress() < seconds) return;

        consumeOne(input);
        machine.input(input.getAmount() <= 0 ? null : input);
        if (output == null) machine.output(items.create(CustomItem.CHARGED_RESONANCE));
        else {
            output.setAmount(output.getAmount() + 1);
            machine.output(output);
        }
        machine.progress(0.0);
        machine.wear(machine.wear() + 0.35 * tuning(machine).wearMultiplier());
        machine.entropy(machine.entropy() + 0.8 * machine.activeDirective().entropyMultiplier());
        machine.recordCycle(1, 0.0);
        machine.recordProduction(CustomItem.CHARGED_RESONANCE.id(), 1);
    }

    private void simulateHeat(MachineInstance machine) {
        double beforeHeat = machine.heat();
        double passive = Math.max(0.001, plugin.getConfig().getDouble("thermal.passive-equalization", 0.075));
        double equalized = EngineeringMath.passiveTemperature(beforeHeat, AMBIENT_HEAT, passive, machine.type().thermalMass());
        machine.heat(equalized);

        double target = machine.targetHeat();
        if (target > machine.heat() + 0.5) {
            int heatFlux = Math.max(1, plugin.getConfig().getInt("thermal.heating-flux-per-second", 6));
            if (machine.flux() >= heatFlux) {
                double rate = Math.max(1.0, plugin.getConfig().getDouble("thermal.base-heating-rate", 140.0));
                double delta = (rate / machine.type().thermalMass()) * tuning(machine).heatingMultiplier();
                machine.consumeFlux(heatFlux);
                machine.heat(Math.min(target, machine.heat() + delta));
            }
        } else if (target < machine.heat() - 0.5) {
            int coolFlux = Math.max(1, plugin.getConfig().getInt("thermal.cooling-flux-per-second", 8));
            if (machine.flux() >= coolFlux) {
                double rate = Math.max(1.0, plugin.getConfig().getDouble("thermal.base-cooling-rate", 105.0));
                double delta = (rate / machine.type().thermalMass()) * tuning(machine).coolingMultiplier();
                machine.consumeFlux(coolFlux);
                machine.heat(Math.max(target, machine.heat() - delta));
            }
        }
        if (Math.abs(beforeHeat - machine.heat()) > 0.001) markDirty();
    }

    private void simulatePressure(MachineInstance machine) {
        double before = machine.pressure();
        double passive = Math.max(0.001, plugin.getConfig().getDouble("pressure.passive-equalization", 0.08));
        machine.pressure(EngineeringMath.passivePressure(before, 1.0, passive));
        double target = machine.targetPressure();
        if (target > machine.pressure() + 0.05) {
            int flux = Math.max(1, plugin.getConfig().getInt("pressure.compression-flux-per-second", 10));
            if (machine.flux() >= flux) {
                double rate = Math.max(0.05, plugin.getConfig().getDouble("pressure.compression-rate", 0.65));
                double qualityScale = 0.75 + machine.quality() / 200.0;
                machine.consumeFlux(flux);
                machine.pressure(Math.min(target, machine.pressure() + rate * qualityScale));
            }
        } else if (target < machine.pressure() - 0.05) {
            double rate = Math.max(0.05, plugin.getConfig().getDouble("pressure.vent-rate", 0.85));
            machine.pressure(Math.max(target, machine.pressure() - rate));
        }
        if (machine.fault() == MachineFault.SEAL_LEAK) {
            machine.pressure(Math.max(1.0, machine.pressure() - 0.9));
        }
        if (Math.abs(before - machine.pressure()) > 0.001) markDirty();
    }

    private void evaluateFaults(MachineInstance machine) {
        double entropyRatio = entropyCapacity(machine.type()) <= 0 ? 0.0 : machine.entropy() / entropyCapacity(machine.type());

        if (machine.hasFault()) {
            machine.faultTicks(machine.faultTicks() + 1);
            if (machine.fault().entropyChain() && supportsEntropyFaultChain(machine.type())) {
                int driftSeconds = Math.max(5, plugin.getConfig().getInt("entropy.drift-escalation-seconds", 30));
                int surgeSeconds = Math.max(5, plugin.getConfig().getInt("entropy.surge-escalation-seconds", 20));
                if (machine.fault() == MachineFault.COHERENCE_DRIFT && entropyRatio >= 0.85 && machine.faultTicks() >= driftSeconds) {
                    machine.fault(MachineFault.ENTROPY_SURGE);
                    machine.faultTicks(0);
                    machine.progress(0.0);
                    markDirty();
                } else if (machine.fault() == MachineFault.ENTROPY_SURGE && entropyRatio >= 0.95 && machine.faultTicks() >= surgeSeconds) {
                    machine.fault(MachineFault.CONTAINMENT_BREACH);
                    machine.faultTicks(0);
                    machine.progress(0.0);
                    markDirty();
                }
            }
            if (machine.fault() == MachineFault.FIELD_DESYNC && machine.type() == MachineType.VOID_CORE) {
                int collapseSeconds = Math.max(5, plugin.getConfig().getInt("field.collapse-escalation-seconds", 18));
                double collapseThreshold = plugin.getConfig().getDouble("field.collapse-threshold", 45.0) + singularityFieldPenalty(machine) * 0.55;
                if (machine.fieldStability() < collapseThreshold && machine.faultTicks() >= collapseSeconds) {
                    machine.fault(MachineFault.FIELD_COLLAPSE);
                    machine.faultTicks(0);
                    machine.progress(0.0);
                    triggerSpatialIncident(machine);
                    markDirty();
                }
            }
            if (machine.faulted()) return;
        }

        double sealThreshold = plugin.getConfig().getDouble("faults.pressure-seal-wear-threshold", 82.0);
        if (machine.type().usesPressure() && (machine.pressure() > machine.type().maximumSafePressure()
            || (machine.wear() >= sealThreshold && machine.pressure() >= machine.type().maximumSafePressure() * 0.72))) {
            machine.fault(MachineFault.SEAL_LEAK);
            machine.faultTicks(0);
            machine.progress(0.0);
            markDirty();
            return;
        }
        boolean unsafeHeat = machine.heat() > machine.type().maximumSafeHeat() || machine.heat() < machine.type().minimumSafeHeat();
        if (machine.wear() >= 90.0 && unsafeHeat) {
            machine.fault(MachineFault.THERMAL_RUNAWAY);
            machine.faultTicks(0);
            machine.progress(0.0);
            markDirty();
        } else if (machine.wear() >= plugin.getConfig().getDouble("faults.general-bearing-wear-threshold", 96.0)) {
            machine.fault(MachineFault.BEARING_FAILURE);
            machine.faultTicks(0);
            machine.progress(0.0);
            markDirty();
        } else if (!machine.hasFault() && machine.type() == MachineType.VOID_CORE && currentRecipe(machine) != null
            && machine.structureValid() && machine.progress() > 0.0) {
            double threshold = plugin.getConfig().getDouble("field.desync-threshold", 68.0) + singularityFieldPenalty(machine);
            if (machine.fieldStability() < threshold) {
                machine.faultTicks(machine.faultTicks() + 1);
                int onset = Math.max(3, plugin.getConfig().getInt("field.desync-onset-seconds", 8));
                if (machine.faultTicks() >= onset) {
                    machine.fault(MachineFault.FIELD_DESYNC);
                    machine.faultTicks(0);
                    machine.progress(0.0);
                }
                markDirty();
            } else if (machine.faultTicks() != 0) {
                machine.faultTicks(0);
                markDirty();
            }
        } else if (!machine.hasFault() && supportsEntropyFaultChain(machine.type())) {
            double threshold = plugin.getConfig().getDouble("entropy.drift-threshold", 0.72);
            if (entropyRatio >= threshold) {
                machine.faultTicks(machine.faultTicks() + 1);
                int onset = Math.max(2, plugin.getConfig().getInt("entropy.drift-onset-seconds", 5));
                if (machine.faultTicks() >= onset) {
                    machine.fault(MachineFault.COHERENCE_DRIFT);
                    machine.faultTicks(0);
                }
                markDirty();
            } else if (machine.faultTicks() != 0) {
                machine.faultTicks(0);
                markDirty();
            }
        }
    }

    private double singularityFieldPenalty(MachineInstance core) {
        if (core == null || core.type() != MachineType.VOID_CORE) return 0.0;
        double base = switch (core.singularityMode()) {
            case QUIESCENT -> -10.0;
            case CONTAINED -> 0.0;
            case COMPRESSED -> 6.0;
            case EXTRACTION -> 12.0;
        };
        return Math.max(-12.0, base - coreChamberCount(core, CoreChamberMode.STABILIZATION) * 3.0);
    }

    private boolean supportsEntropyFaultChain(MachineType type) {
        return type == MachineType.PRESSURE_VESSEL || type == MachineType.PHASE_OBSERVER || type == MachineType.ENTROPY_CONDENSER;
    }

    private void triggerSpatialIncident(MachineInstance core) {
        core.recordIncident();
        core.entropy(Math.min(entropyCapacity(core.type()), core.entropy() + 180.0));
        core.wear(core.wear() + 8.0);
        for (MachineInstance nearby : new ArrayList<>(machines.values())) {
            if (nearby == core || nearby.location().getWorld() == null || core.location().getWorld() == null) continue;
            if (!nearby.location().getWorld().getUID().equals(core.location().getWorld().getUID())) continue;
            double distance = nearby.location().distance(core.location());
            if (distance > 8.0) continue;
            double scale = Math.max(0.15, 1.0 - distance / 8.0);
            double capacity = entropyCapacity(nearby.type());
            if (capacity > 0.0) nearby.entropy(Math.min(capacity, nearby.entropy() + 45.0 * scale));
            nearby.wear(nearby.wear() + 6.0 * scale);
            nearby.progress(0.0);
        }
        markDirty();
    }

    private void applyThermalStress(MachineInstance machine) {
        double stress = 0.0;
        if (machine.heat() > machine.type().maximumSafeHeat()) {
            stress = (machine.heat() - machine.type().maximumSafeHeat()) / 80.0;
        } else if (machine.heat() < machine.type().minimumSafeHeat()) {
            stress = (machine.type().minimumSafeHeat() - machine.heat()) / 50.0;
        }
        if (stress > 0.0) {
            machine.wear(machine.wear() + Math.max(0.1, stress) * tuning(machine).wearMultiplier());
            markDirty();
        }
    }

    private void applyEntropyStress(MachineInstance machine) {
        double capacity = entropyCapacity(machine.type());
        if (capacity <= 0.0) return;
        double ratio = machine.entropy() / capacity;
        if (ratio <= 0.60) return;
        double excess = (ratio - 0.60) / 0.40;
        machine.wear(machine.wear() + Math.max(0.02, excess * 0.18) * tuning(machine).wearMultiplier());
        markDirty();
    }

    private void tickFieldStabilizer(MachineInstance machine) {
        if (machine.maintenanceLocked() || !machine.automationAllowsRun()) return;
        int cost = Math.max(1, plugin.getConfig().getInt("field.stabilizer-flux-per-second", 10));
        if (!machine.consumeFlux(cost)) return;
        machine.entropy(machine.entropy() + 0.12 * machine.activeDirective().entropyMultiplier());
        machine.wear(machine.wear() + 0.012 * tuning(machine).wearMultiplier());
        markDirty();
    }

    private void tickObserver(MachineInstance machine) {
        if (machine.maintenanceLocked() || !machine.automationAllowsRun()) return;
        int cost = Math.max(1, plugin.getConfig().getInt("observer.flux-per-second", 8));
        if (machine.flux() < cost || machine.computation() >= computationCapacity(machine.type())) return;
        int yield = observerYield(machine);
        if (yield <= 0) return;
        machine.consumeFlux(cost);
        machine.computation(Math.min(computationCapacity(machine.type()), machine.computation() + yield));
        machine.entropy(machine.entropy() + Math.max(0.05, yield * 0.035));
        machine.wear(machine.wear() + 0.025 * tuning(machine).wearMultiplier());
        markDirty();
    }

    public int observerYield(MachineInstance machine) {
        if (machine == null || machine.type() != MachineType.PHASE_OBSERVER) return 0;
        int base = switch (machine.observerProgram()) {
            case BROAD_SPECTRUM -> {
                int value = 1;
                if (ProcessEnvironment.OPEN_SKY.matches(machine.location())) value += 3;
                if (ProcessEnvironment.NIGHT_SKY.matches(machine.location())) value += 5;
                if (ProcessEnvironment.SCULK_FIELD.matches(machine.location())) value += 4;
                if (ProcessEnvironment.END.matches(machine.location())) value += 6;
                if (ProcessEnvironment.NETHER.matches(machine.location())) value += 1;
                yield value;
            }
            case CELESTIAL_TRACKING -> (ProcessEnvironment.OPEN_SKY.matches(machine.location()) ? 5 : 0)
                + (ProcessEnvironment.NIGHT_SKY.matches(machine.location()) ? 9 : 0);
            case SCULK_CORRELATION -> ProcessEnvironment.SCULK_FIELD.matches(machine.location()) ? 12 : 0;
            case DIMENSIONAL_BASELINE -> ProcessEnvironment.END.matches(machine.location()) ? 14
                : ProcessEnvironment.NETHER.matches(machine.location()) ? 7 : 2;
            case ENTROPY_WATCH -> Math.min(16, (int) Math.round(nearbyEntropyPressure(machine) * 14.0));
        };
        if (base <= 0) return 0;
        double quality = 0.70 + machine.quality() / 170.0;
        if (machine.fault() == MachineFault.COHERENCE_DRIFT) quality *= 0.70;
        return Math.max(1, (int) Math.round(base * quality));
    }

    public String observerStatus(MachineInstance machine) {
        if (machine == null || machine.type() != MachineType.PHASE_OBSERVER) return "No observer";
        return switch (machine.observerProgram()) {
            case BROAD_SPECTRUM -> {
                List<String> signals = new ArrayList<>();
                if (ProcessEnvironment.OPEN_SKY.matches(machine.location())) signals.add("open sky");
                if (ProcessEnvironment.NIGHT_SKY.matches(machine.location())) signals.add("clear night");
                if (ProcessEnvironment.SCULK_FIELD.matches(machine.location())) signals.add("sculk field");
                if (ProcessEnvironment.END.matches(machine.location())) signals.add("End field");
                if (ProcessEnvironment.NETHER.matches(machine.location())) signals.add("Nether field");
                yield signals.isEmpty() ? "weak local baseline" : String.join(" + ", signals);
            }
            case CELESTIAL_TRACKING -> ProcessEnvironment.NIGHT_SKY.matches(machine.location()) ? "clear-night lock"
                : ProcessEnvironment.OPEN_SKY.matches(machine.location()) ? "open-sky daylight baseline" : "sky occluded";
            case SCULK_CORRELATION -> ProcessEnvironment.SCULK_FIELD.matches(machine.location()) ? "dense sculk correlation" : "no sculk correlation";
            case DIMENSIONAL_BASELINE -> machine.location().getWorld() == null ? "world unavailable"
                : "dimension " + machine.location().getWorld().getEnvironment().name().toLowerCase(java.util.Locale.ROOT);
            case ENTROPY_WATCH -> String.format(java.util.Locale.ROOT, "nearby entropy pressure %.0f%%", nearbyEntropyPressure(machine) * 100.0);
        };
    }

    private double nearbyEntropyPressure(MachineInstance observer) {
        if (observer == null || observer.location().getWorld() == null) return 0.0;
        double pressure = 0.0;
        for (MachineInstance machine : machines.values()) {
            if (machine == observer || machine.location().getWorld() == null) continue;
            if (!machine.location().getWorld().getUID().equals(observer.location().getWorld().getUID())) continue;
            if (machine.location().distanceSquared(observer.location()) > 100.0) continue;
            double capacity = entropyCapacity(machine.type());
            if (capacity <= 0.0) continue;
            pressure += Math.min(1.25, machine.entropy() / capacity);
        }
        return Math.min(1.0, pressure / 3.0);
    }

    public void cycleObserverProgram(MachineInstance machine, int direction) {
        if (machine == null || machine.type() != MachineType.PHASE_OBSERVER) return;
        machine.observerProgram(machine.observerProgram().next(direction));
        markDirty();
    }

    public void cycleControlDirective(MachineInstance machine, int direction) {
        if (machine == null || machine.type() != MachineType.CONTROL_MATRIX) return;
        machine.controlDirective(machine.controlDirective().next(direction));
        markDirty();
    }

    public void resetActiveDirectives() {
        for (MachineInstance machine : machines.values()) machine.activeDirective(ControlDirective.BALANCED);
    }

    public void resetSignals() {
        for (MachineInstance machine : machines.values()) machine.signalHigh(false);
    }

    public void applySignal(MachineInstance machine, boolean high) {
        if (machine != null && high) machine.signalHigh(true);
    }

    public void applyActiveDirective(MachineInstance machine, ControlDirective directive) {
        if (machine == null) return;
        machine.activeDirective(directive);
    }

    private void refreshStructure(MachineInstance machine) {
        StructureStatus status = structureStatus(machine);
        machine.structureStatus(status.valid(), status.firstProblem());
    }

    public record StructureStatus(boolean valid, int matched, int required, String firstProblem) {
        public double completeness() { return required <= 0 ? 1.0 : matched / (double) required; }
    }

    public StructureStatus structureStatus(MachineInstance machine) {
        if (machine == null || !machine.type().isMultiblockController())
            return new StructureStatus(true, 0, 0, "Not a multiblock controller.");
        if (machine.type() == MachineType.VOID_CORE) {
            VoidCoreStructure.Status status = VoidCoreStructure.validate(machine.location());
            machine.structureStatus(status.valid(), status.firstProblem());
            return new StructureStatus(status.valid(), status.matched(), status.required(), status.firstProblem());
        }
        EntropyCondenserStructure.Status status = EntropyCondenserStructure.validate(machine.location());
        machine.structureStatus(status.valid(), status.firstProblem());
        return new StructureStatus(status.valid(), status.matched(), status.required(), status.firstProblem());
    }

    private void clampResourceCaps(MachineInstance machine) {
        machine.entropy(Math.min(machine.entropy(), entropyCapacity(machine.type())));
        machine.computation(Math.min(machine.computation(), computationCapacity(machine.type())));
    }

    private void tickThermalExchanger(MachineInstance exchanger) {
        if (exchanger.maintenanceLocked() || !exchanger.automationAllowsRun()) return;
        List<MachineInstance> adjacent = adjacentMachines(exchanger.location()).stream()
            .filter(machine -> machine.type().isEngineeringProcessor())
            .toList();
        if (adjacent.size() < 2) return;

        MachineInstance hottest = adjacent.stream().max(java.util.Comparator.comparingDouble(MachineInstance::heat)).orElse(null);
        MachineInstance coldest = adjacent.stream().min(java.util.Comparator.comparingDouble(MachineInstance::heat)).orElse(null);
        if (hottest == null || coldest == null || hottest == coldest) return;
        double difference = hottest.heat() - coldest.heat();
        if (difference < 25.0) return;

        double base = Math.max(1.0, plugin.getConfig().getDouble("thermal.exchanger-units-per-second", 90.0));
        double transfer = EngineeringMath.exchangerTransfer(hottest.heat(), coldest.heat(), base, exchanger.quality());
        double efficiency = Math.max(0.50, Math.min(0.98, plugin.getConfig().getDouble("thermal.exchanger-efficiency", 0.88)
            + (exchanger.quality() - 50.0) * 0.001));

        hottest.heat(hottest.heat() - transfer / hottest.type().thermalMass());
        coldest.heat(coldest.heat() + (transfer * efficiency) / coldest.type().thermalMass());
        exchanger.lastHeatTransfer(transfer);
        exchanger.wear(exchanger.wear() + transfer * 0.0007 * tuning(exchanger).wearMultiplier());
        markDirty();
    }

    public ProcessRecipe currentRecipe(MachineInstance machine) {
        if (machine == null || !machine.type().isEngineeringProcessor()) return null;
        return processRecipes.match(machine.type(), items.identify(machine.input()), items.identify(machine.secondaryInput()), machine.selectedProcessId());
    }

    public List<ProcessRecipe> processCandidates(MachineInstance machine) {
        if (machine == null) return List.of();
        return processRecipes.candidates(machine.type(), items.identify(machine.input()));
    }

    public void cycleProcess(MachineInstance machine, int direction) {
        List<ProcessRecipe> candidates = processCandidates(machine);
        if (candidates.isEmpty()) {
            machine.selectedProcessId(null);
            return;
        }
        int current = -1;
        for (int i = 0; i < candidates.size(); i++) {
            if (candidates.get(i).id().equalsIgnoreCase(machine.selectedProcessId())) current = i;
        }
        int next = Math.floorMod(current + (direction >= 0 ? 1 : -1), candidates.size());
        machine.selectedProcessId(candidates.get(next).id());
        machine.progress(0.0);
        markDirty();
    }

    public ProcessRecipe completedProcess(MachineInstance machine) {
        if (machine == null || machine.completedProcessId() == null) return null;
        return processRecipes.byId(machine.completedProcessId());
    }

    public void acknowledgeCompletedProcess(MachineInstance machine) {
        if (machine == null || machine.completedProcessId() == null) return;
        machine.completedProcessId(null);
        markDirty();
    }

    public int projectedOutputQuality(MachineInstance machine) {
        ProcessRecipe recipe = currentRecipe(machine);
        if (recipe == null || machine.input() == null) return 0;
        if (recipe.mode() == ProcessMode.PURIFY_CATALYST) return items.quality(machine.input());
        return processEngine.calculateOutputQuality(machine, recipe, machine.input(), machine.secondaryInput(), machine.catalyst());
    }

    public ProcessEngine.TickState processState(MachineInstance machine) {
        if (machine == null) return ProcessEngine.TickState.NO_RECIPE;
        return processStates.getOrDefault(key(machine.location()), inferState(machine));
    }

    private ProcessEngine.TickState inferState(MachineInstance machine) {
        if (machine.faulted()) return ProcessEngine.TickState.FAULTED;
        if (machine.wear() >= 99.95) return ProcessEngine.TickState.MAINTENANCE_REQUIRED;
        if (!machine.automationAllowsRun()) return ProcessEngine.TickState.AUTOMATION_BLOCKED;
        ProcessRecipe recipe = currentRecipe(machine);
        if (recipe == null) return ProcessEngine.TickState.NO_RECIPE;
        if (!singularitySupports(machine, recipe)) return ProcessEngine.TickState.SINGULARITY_UNSUPPORTED;
        if (recipe.requiresSecondaryInput() && (!items.is(machine.secondaryInput(), recipe.secondaryInput())
            || machine.secondaryInput().getAmount() < recipe.secondaryInputAmount())) return ProcessEngine.TickState.MISSING_SECONDARY_INPUT;
        if (recipe.requiresCatalyst() && !items.is(machine.catalyst(), recipe.catalyst())) return ProcessEngine.TickState.MISSING_CATALYST;
        if (recipe.mode() == ProcessMode.PURIFY_CATALYST && items.contamination(machine.input()) <= 0.05) return ProcessEngine.TickState.CATALYST_CLEAN;
        if (machine.output() != null) return ProcessEngine.TickState.OUTPUT_BLOCKED;
        if (recipe.hasByproduct() && machine.byproduct() != null) return ProcessEngine.TickState.BYPRODUCT_BLOCKED;
        if (machine.heat() < recipe.minimumHeat()) return ProcessEngine.TickState.TOO_COLD;
        if (machine.heat() > recipe.maximumHeat()) return ProcessEngine.TickState.TOO_HOT;
        if (recipe.usesPressure() && machine.pressure() < recipe.minimumPressure()) return ProcessEngine.TickState.PRESSURE_LOW;
        if (recipe.usesPressure() && machine.pressure() > recipe.maximumPressure()) return ProcessEngine.TickState.PRESSURE_HIGH;
        if (recipe.requiresMultiblock() && !machine.structureValid()) return ProcessEngine.TickState.STRUCTURE_INVALID;
        if (recipe.usesSpatialField() && machine.fieldStability() + 0.001 < recipe.minimumFieldStability()) return ProcessEngine.TickState.FIELD_UNSTABLE;
        if (!recipe.environment().matches(machine.location())) return ProcessEngine.TickState.ENVIRONMENT_BLOCKED;
        if (machine.entropy() + 0.001 < recipe.entropyCost()) return ProcessEngine.TickState.ENTROPY_LOW;
        if (machine.computation() < recipe.computationCost()) return ProcessEngine.TickState.COMPUTATION_LOW;
        return machine.flux() <= 0 ? ProcessEngine.TickState.NO_FLUX : ProcessEngine.TickState.PROCESSING;
    }

    public ProcessTuning tuning(MachineInstance machine) {
        double qualityScale = (machine.quality() - 50.0) / 50.0;
        double speed = 1.0 + qualityScale * 0.08;
        double flux = 1.0 - qualityScale * 0.08;
        double contamination = 1.0 - qualityScale * 0.08;
        double heating = 1.0 + qualityScale * 0.08;
        double cooling = 1.0 + qualityScale * 0.08;
        double wear = 1.0 - qualityScale * 0.12;

        if (machine.fault() == MachineFault.COHERENCE_DRIFT) {
            speed *= 0.80;
            flux *= 1.12;
            wear *= 1.35;
        }

        for (int i = 0; i < machine.type().upgradeSlots(); i++) {
            ItemStack stack = machine.upgrade(i);
            UpgradeType upgrade = UpgradeType.fromItem(items.identify(stack));
            if (upgrade == null) continue;
            double q = items.quality(stack) / 100.0;
            switch (upgrade) {
                case SPEED_GOVERNOR -> speed += 0.08 + q * 0.10;
                case FLUX_REGULATOR -> flux *= 1.0 - (0.10 + q * 0.12);
                case THERMAL_COUPLER -> heating += 0.15 + q * 0.22;
                case COOLING_JACKET -> cooling += 0.18 + q * 0.28;
                case CATALYST_FILTER -> contamination *= 1.0 - (0.20 + q * 0.28);
                case PHASE_INTERFACE -> { }
            }
        }
        ControlDirective directive = machine.activeDirective();
        speed *= directive.speedMultiplier();
        flux *= directive.fluxMultiplier();
        wear *= directive.wearMultiplier();
        if (machine.type() == MachineType.VOID_CORE) {
            speed *= machine.singularityMode().speedMultiplier();
            flux *= machine.singularityMode().fluxMultiplier();
            wear *= machine.singularityMode().wearMultiplier();
            int stabilization = coreChamberCount(machine, CoreChamberMode.STABILIZATION);
            if (stabilization > 0) wear *= Math.max(0.70, 1.0 - stabilization * 0.08);
        }
        return new ProcessTuning(
            Math.max(0.5, speed),
            Math.max(0.55, flux),
            Math.max(0.30, contamination),
            Math.max(0.5, heating),
            Math.max(0.5, cooling),
            Math.max(0.45, wear)
        );
    }

    private void tickCoreUpgradeChamber(MachineInstance chamber) {
        if (chamber.maintenanceLocked() || !chamber.automationAllowsRun()) return;
        MachineInstance core = nearestVoidCore(chamber.location(), 6.0);
        if (core == null) return;
        int cost = Math.max(1, plugin.getConfig().getInt("void-core.chamber-flux-per-second", 12));
        if (!chamber.consumeFlux(cost)) return;
        chamber.entropy(chamber.entropy() + 0.08);
        chamber.wear(chamber.wear() + 0.01 * tuning(chamber).wearMultiplier());
        markDirty();
    }

    public MachineInstance nearestVoidCore(Location origin, double radius) {
        if (origin == null || origin.getWorld() == null) return null;
        MachineInstance best = null;
        double bestDistance = radius + 0.001;
        for (MachineInstance candidate : machines.values()) {
            if (candidate.type() != MachineType.VOID_CORE || candidate.location().getWorld() == null) continue;
            if (!candidate.location().getWorld().getUID().equals(origin.getWorld().getUID())) continue;
            double distance = candidate.location().distance(origin);
            if (distance <= radius && distance < bestDistance) { best = candidate; bestDistance = distance; }
        }
        return best;
    }

    public int coreChamberCount(MachineInstance core, CoreChamberMode mode) {
        if (core == null || core.type() != MachineType.VOID_CORE || core.location().getWorld() == null) return 0;
        int requiredFlux = Math.max(1, plugin.getConfig().getInt("void-core.chamber-flux-per-second", 12));
        int count = 0;
        for (MachineInstance chamber : machines.values()) {
            if (chamber.type() != MachineType.VOID_UPGRADE_CHAMBER || chamber.coreChamberMode() != mode) continue;
            if (chamber.location().getWorld() == null || !chamber.location().getWorld().getUID().equals(core.location().getWorld().getUID())) continue;
            if (chamber.location().distance(core.location()) > 6.0) continue;
            if (chamber.maintenanceLocked() || !chamber.automationAllowsRun() || chamber.flux() < requiredFlux) continue;
            count++;
        }
        return count;
    }

    public boolean singularitySupports(MachineInstance machine, ProcessRecipe recipe) {
        if (machine == null || recipe == null || machine.type() != MachineType.VOID_CORE) return true;
        if (recipe.id().equals("compressed_void_seed")) {
            return (machine.singularityMode() == SingularityMode.COMPRESSED || machine.singularityMode() == SingularityMode.EXTRACTION)
                && coreChamberCount(machine, CoreChamberMode.COMPRESSION) > 0;
        }
        if (recipe.id().equals("dimensional_kernel")) {
            return machine.singularityMode() == SingularityMode.EXTRACTION
                && coreChamberCount(machine, CoreChamberMode.COMPRESSION) > 0
                && coreChamberCount(machine, CoreChamberMode.EXTRACTION) > 0;
        }
        return machine.singularityMode() != SingularityMode.QUIESCENT;
    }

    public void cycleAutomationGroup(MachineInstance machine, int direction) {
        if (machine == null) return;
        machine.automationGroup(Math.floorMod(machine.automationGroup() + (direction >= 0 ? 1 : -1), 8));
        markDirty();
    }

    public void cycleSignalChannel(MachineInstance machine, int direction) {
        if (machine == null) return;
        machine.signalChannel(Math.floorMod(machine.signalChannel() + (direction >= 0 ? 1 : -1), 16));
        markDirty();
    }

    public void cycleSignalGate(MachineInstance machine, int direction) {
        if (machine == null) return;
        SignalGate[] values = SignalGate.values();
        int next = Math.floorMod(machine.signalGate().ordinal() + (direction >= 0 ? 1 : -1), values.length);
        machine.signalGate(values[next]);
        markDirty();
    }

    public void cycleAutomationRule(MachineInstance machine, int direction) {
        if (machine == null) return;
        AutomationRule[] values = AutomationRule.values();
        int next = Math.floorMod(machine.automationRule().ordinal() + (direction >= 0 ? 1 : -1), values.length);
        machine.automationRule(values[next]);
        markDirty();
    }

    public void cycleSingularityMode(MachineInstance machine, int direction) {
        if (machine == null || machine.type() != MachineType.VOID_CORE) return;
        SingularityMode[] values = SingularityMode.values();
        int next = Math.floorMod(machine.singularityMode().ordinal() + (direction >= 0 ? 1 : -1), values.length);
        machine.singularityMode(values[next]);
        machine.progress(0.0);
        markDirty();
    }

    public void cycleCoreChamberMode(MachineInstance machine, int direction) {
        if (machine == null || machine.type() != MachineType.VOID_UPGRADE_CHAMBER) return;
        CoreChamberMode[] values = CoreChamberMode.values();
        int next = Math.floorMod(machine.coreChamberMode().ordinal() + (direction >= 0 ? 1 : -1), values.length);
        machine.coreChamberMode(values[next]);
        markDirty();
    }

    public Map<String, Long> serverProductionLedger() {
        Map<String, Long> result = new HashMap<>();
        for (MachineInstance machine : machines.values()) {
            machine.productionLedger().forEach((id, count) -> result.merge(id, count, Long::sum));
        }
        return Map.copyOf(result);
    }

    public long serverLifetimeCycles() { return machines.values().stream().mapToLong(MachineInstance::lifetimeCycles).sum(); }

    public int loadedDimensionalAnchorCount() {
        return (int) machines.values().stream().filter(machine -> machine.type() == MachineType.DIMENSIONAL_ANCHOR)
            .filter(machine -> machine.location().isChunkLoaded()).count();
    }

    public int dimensionalAnchorWorldCount() {
        return (int) machines.values().stream().filter(machine -> machine.type() == MachineType.DIMENSIONAL_ANCHOR)
            .map(machine -> machine.location().getWorld()).filter(java.util.Objects::nonNull)
            .map(world -> world.getUID()).distinct().count();
    }

    public boolean supportsSecondaryInput(MachineType type) {
        return processRecipes.forMachine(type).stream().anyMatch(ProcessRecipe::requiresSecondaryInput);
    }

    public boolean supportsCatalyst(MachineType type) {
        return processRecipes.forMachine(type).stream().anyMatch(ProcessRecipe::requiresCatalyst);
    }

    public boolean isValidInput(MachineType type, ItemStack stack) {
        CustomItem custom = items.identify(stack);
        return custom != null && processRecipes.canBePrimary(type, custom);
    }

    public boolean isValidSecondaryInput(MachineInstance machine, ItemStack stack) {
        if (machine == null) return false;
        return processRecipes.canBeSecondary(machine.type(), items.identify(machine.input()), items.identify(stack));
    }

    public boolean isValidCatalyst(MachineType type, ItemStack stack) {
        CustomItem custom = items.identify(stack);
        if (custom == null) return false;
        return processRecipes.forMachine(type).stream().anyMatch(recipe -> recipe.catalyst() == custom);
    }

    public boolean isUpgrade(ItemStack stack) {
        return UpgradeType.fromItem(items.identify(stack)) != null;
    }

    public boolean hasUpgrade(MachineInstance machine, UpgradeType type) {
        if (machine == null) return false;
        for (int i = 0; i < machine.type().upgradeSlots(); i++) {
            if (UpgradeType.fromItem(items.identify(machine.upgrade(i))) == type) return true;
        }
        return false;
    }

    public void adjustTargetHeat(MachineInstance machine, double delta) {
        if (machine == null || !machine.type().isEngineeringProcessor()) return;
        double target = Math.max(machine.type().minimumSafeHeat(), Math.min(machine.type().maximumSafeHeat(), machine.targetHeat() + delta));
        machine.targetHeat(target);
        markDirty();
    }

    public void adjustTargetPressure(MachineInstance machine, double delta) {
        if (machine == null || !machine.type().usesPressure()) return;
        double target = Math.max(machine.type().minimumSafePressure(), Math.min(machine.type().maximumSafePressure(), machine.targetPressure() + delta));
        machine.targetPressure(target);
        markDirty();
    }

    public boolean repairFault(MachineInstance machine) {
        if (machine == null || !machine.hasFault()) return false;
        boolean entropyFault = machine.fault().entropyChain();
        boolean fieldFault = machine.fault().fieldChain();
        machine.fault(MachineFault.NONE);
        machine.faultTicks(0);
        machine.wear(Math.max(0.0, machine.wear() - 12.0));
        if (entropyFault) machine.entropy(Math.min(machine.entropy(), entropyCapacity(machine.type()) * 0.45));
        if (fieldFault) machine.entropy(Math.min(machine.entropy(), entropyCapacity(machine.type()) * 0.35));
        if (machine.type().usesPressure()) machine.pressure(Math.min(machine.pressure(), 1.5));
        machine.progress(0.0);
        markDirty();
        return true;
    }

    public double service(MachineInstance machine, int kitQuality) {
        if (machine == null || machine.wear() <= 0.05) return 0.0;
        double before = machine.wear();
        double restored = EngineeringMath.maintenanceReduction(kitQuality);
        machine.wear(Math.max(0.0, before - restored));
        markDirty();
        return before - machine.wear();
    }

    public ItemStack machineDrop(MachineInstance machine) {
        ItemStack drop = items.createWithQuality(machine.type().item(), 1, machine.quality());
        items.setMachineWear(drop, machine.wear());
        items.setMachineEntropy(drop, machine.entropy());
        items.setMachineFault(drop, machine.fault(), machine.faultTicks());
        items.setMachineExtendedState(drop, machine.observerProgram(), machine.controlDirective(),
            machine.lifetimeCycles(), machine.lifetimeItemsProduced(), machine.lifetimeFluxConsumed(),
            machine.lifetimeEntropyProcessed(), machine.incidentCount(), machine.automationGroup(), machine.signalChannel(),
            machine.signalGate(), machine.automationRule(), machine.singularityMode(), machine.coreChamberMode(), machine.productionLedger());
        return drop;
    }

    public int maxFlux() { return maxFlux(MachineType.FLUX_CRUCIBLE); }

    public int maxFlux(MachineType type) {
        int fallback = switch (type) {
            case FLUX_CRUCIBLE -> 1000;
            case CRYOGENIC_COLUMN -> 3400;
            case CATALYTIC_REACTOR -> 2800;
            case PRESSURE_VESSEL -> 4200;
            case PHASE_OBSERVER -> 1600;
            case ENTROPY_CONDENSER -> 5200;
            case VOID_CORE -> 7200;
            case FIELD_STABILIZER -> 1800;
            case VOID_UPGRADE_CHAMBER -> 2200;
            case CONTROL_MATRIX, AUTOMATION_TERMINAL, DIMENSIONAL_ANCHOR, PROJECT_TERMINAL -> 0;
            default -> type.isEngineeringProcessor() ? 2400 : 0;
        };
        return plugin.getConfig().getInt("machines." + type.id().replace('_', '-') + ".max-flux", fallback);
    }

    public double entropyCapacity(MachineType type) {
        double fallback = switch (type) {
            case ENTROPY_CONDENSER -> 900.0;
            case VOID_CORE -> 1400.0;
            case FIELD_STABILIZER -> 120.0;
            case PHASE_OBSERVER -> 80.0;
            case PRESSURE_VESSEL -> 220.0;
            case CATALYTIC_REACTOR -> 180.0;
            case CRYOGENIC_COLUMN -> 200.0;
            case INDUCTION_HEATER -> 160.0;
            case MATRIX_PURIFIER -> 140.0;
            case FLUX_CRUCIBLE -> 100.0;
            case VOID_UPGRADE_CHAMBER -> 160.0;
            default -> 0.0;
        };
        return plugin.getConfig().getDouble("machines." + type.id().replace('_', '-') + ".entropy-capacity", fallback);
    }

    public int computationCapacity(MachineType type) {
        int fallback = switch (type) {
            case PHASE_OBSERVER -> 1000;
            case ENTROPY_CONDENSER -> 600;
            case CONTROL_MATRIX -> 800;
            case AUTOMATION_TERMINAL -> 1000;
            case DIMENSIONAL_ANCHOR -> 600;
            case VOID_CORE -> 1200;
            default -> 0;
        };
        return plugin.getConfig().getInt("machines." + type.id().replace('_', '-') + ".computation-capacity", fallback);
    }

    public double addEntropy(MachineInstance machine, double amount) {
        if (machine == null || amount <= 0.0 || entropyCapacity(machine.type()) <= 0.0) return 0.0;
        double before = machine.entropy();
        machine.entropy(Math.min(entropyCapacity(machine.type()), before + amount));
        double accepted = machine.entropy() - before;
        if (accepted > 0.0001) markDirty();
        return accepted;
    }

    public double takeEntropy(MachineInstance machine, double amount) {
        if (machine == null || amount <= 0.0) return 0.0;
        double taken = Math.min(machine.entropy(), amount);
        machine.entropy(machine.entropy() - taken);
        if (taken > 0.0001) markDirty();
        return taken;
    }

    public int addComputation(MachineInstance machine, int amount) {
        if (machine == null || amount <= 0 || computationCapacity(machine.type()) <= 0) return 0;
        int before = machine.computation();
        machine.computation(Math.min(computationCapacity(machine.type()), before + amount));
        int accepted = machine.computation() - before;
        if (accepted > 0) markDirty();
        return accepted;
    }

    public int takeComputation(MachineInstance machine, int amount) {
        if (machine == null || amount <= 0) return 0;
        int taken = Math.min(machine.computation(), amount);
        machine.computation(machine.computation() - taken);
        if (taken > 0) markDirty();
        return taken;
    }

    public int operationCost() { return plugin.getConfig().getInt("machines.flux-crucible.operation-cost", 200); }
    public int operationSeconds() { return Math.max(1, plugin.getConfig().getInt("machines.flux-crucible.operation-seconds", 10)); }
    public int redstoneFlux() { return plugin.getConfig().getInt("power.redstone-flux", plugin.getConfig().getInt("machines.flux-crucible.redstone-flux", 100)); }
    public int redstoneBlockFlux() { return plugin.getConfig().getInt("power.redstone-block-flux", plugin.getConfig().getInt("machines.flux-crucible.redstone-block-flux", 900)); }
    public double ambientHeat() { return AMBIENT_HEAT; }

    public String networkAddress(MachineInstance machine) {
        Location location = machine.location();
        int hash = java.util.Objects.hash(location.getWorld().getUID(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
        return "VC-" + String.format(java.util.Locale.ROOT, "%08X", hash);
    }

    public boolean acceptRoutedItem(MachineInstance machine, ItemStack offered) {
        if (machine == null || offered == null || offered.getType().isAir()) return false;
        if (machine.type().isRoutingBuffer()) return mergeIntoOutput(machine, offered);
        if (machine.type() == MachineType.FLUX_CRUCIBLE) {
            if (!items.is(offered, CustomItem.RESONANT_FRAGMENT)) return false;
            return mergeIntoPrimary(machine, offered);
        }
        if (!machine.type().isEngineeringProcessor()) return false;
        CustomItem custom = items.identify(offered);
        if (custom == null) return false;

        if (processRecipes.canBePrimary(machine.type(), custom)) return mergeIntoPrimary(machine, offered);
        if (processRecipes.canBeSecondary(machine.type(), items.identify(machine.input()), custom)) return mergeIntoSecondary(machine, offered);
        return false;
    }

    public ItemStack takeRoutableOutput(MachineInstance machine, int maxAmount) {
        if (machine == null || maxAmount <= 0) return null;
        ItemStack output = machine.output();
        if (output == null || output.getType().isAir()) return null;
        int amount = Math.min(maxAmount, output.getAmount());
        ItemStack moved = output.clone();
        moved.setAmount(amount);
        output.setAmount(output.getAmount() - amount);
        machine.output(output.getAmount() <= 0 ? null : output);
        markDirty();
        return moved;
    }

    public void finalizeRoutedOutput(MachineInstance machine) {
        if (machine != null && machine.output() == null && machine.completedProcessId() != null) {
            machine.completedProcessId(null);
            markDirty();
        }
    }

    public void returnRoutedOutput(MachineInstance machine, ItemStack returned) {
        if (machine == null || returned == null || returned.getType().isAir()) return;
        ItemStack output = machine.output();
        if (output == null) machine.output(returned);
        else if (output.isSimilar(returned) && output.getAmount() + returned.getAmount() <= output.getMaxStackSize()) {
            output.setAmount(output.getAmount() + returned.getAmount());
            machine.output(output);
        }
        markDirty();
    }

    public int addFlux(MachineInstance machine, int amount) {
        if (machine == null || amount <= 0 || maxFlux(machine.type()) <= 0) return 0;
        int before = machine.flux();
        machine.flux(Math.min(maxFlux(machine.type()), before + amount));
        int accepted = machine.flux() - before;
        if (accepted > 0) markDirty();
        return accepted;
    }

    public List<MachineInstance> adjacentMachines(Location location) {
        List<MachineInstance> result = new ArrayList<>();
        int[][] offsets = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
        for (int[] d : offsets) {
            MachineInstance machine = get(location.clone().add(d[0], d[1], d[2]));
            if (machine != null) result.add(machine);
        }
        return result;
    }

    private boolean mergeIntoPrimary(MachineInstance machine, ItemStack offered) {
        ItemStack current = machine.input();
        if (current == null) {
            machine.input(offered);
            markDirty();
            return true;
        }
        if (!current.isSimilar(offered) || current.getAmount() + offered.getAmount() > current.getMaxStackSize()) return false;
        current.setAmount(current.getAmount() + offered.getAmount());
        machine.input(current);
        markDirty();
        return true;
    }

    private boolean mergeIntoSecondary(MachineInstance machine, ItemStack offered) {
        ItemStack current = machine.secondaryInput();
        if (current == null) {
            machine.secondaryInput(offered);
            markDirty();
            return true;
        }
        if (!current.isSimilar(offered) || current.getAmount() + offered.getAmount() > current.getMaxStackSize()) return false;
        current.setAmount(current.getAmount() + offered.getAmount());
        machine.secondaryInput(current);
        markDirty();
        return true;
    }

    private boolean mergeIntoOutput(MachineInstance machine, ItemStack offered) {
        ItemStack current = machine.output();
        if (current == null) { machine.output(offered); markDirty(); return true; }
        if (!current.isSimilar(offered) || current.getAmount() + offered.getAmount() > current.getMaxStackSize()) return false;
        current.setAmount(current.getAmount() + offered.getAmount());
        machine.output(current);
        markDirty();
        return true;
    }

    public void adjustRoutingPriority(MachineInstance machine, int delta) {
        if (machine == null) return;
        machine.routingPriority(machine.routingPriority() + delta);
        markDirty();
    }

    public void setRoutingFilter(MachineInstance machine, CustomItem filter) {
        if (machine == null) return;
        machine.routingFilterId(filter == null ? null : filter.id());
        markDirty();
    }

    public CustomItem routingFilter(MachineInstance machine) {
        return machine == null ? null : CustomItem.fromId(machine.routingFilterId());
    }

    public boolean routingFilterMatches(String filterId, ItemStack offered) {
        if (filterId == null || filterId.isBlank()) return true;
        CustomItem expected = CustomItem.fromId(filterId);
        return expected != null && items.is(offered, expected);
    }

    public boolean supportsAutomaticRouting(MachineInstance machine) {
        return machine != null && (machine.type().isRoutingBuffer() || hasUpgrade(machine, UpgradeType.PHASE_INTERFACE));
    }

    public void adjustSecondaryFrequency(MachineInstance machine, int delta) {
        if (machine == null || machine.type() != MachineType.FREQUENCY_SPLITTER) return;
        machine.secondaryNetworkFrequency(machine.secondaryNetworkFrequency() + delta);
        markDirty();
    }

    private boolean supportsFuel(MachineType type) {
        return type == MachineType.FLUX_CRUCIBLE || type.isEngineeringProcessor() || type == MachineType.PHASE_OBSERVER
            || type == MachineType.FIELD_STABILIZER || type == MachineType.VOID_UPGRADE_CHAMBER;
    }

    private void consumeOne(ItemStack stack) { stack.setAmount(stack.getAmount() - 1); }

    private String key(Location location) {
        World world = location.getWorld();
        if (world == null) throw new IllegalArgumentException("Machine location must have a world");
        return world.getUID() + ";" + location.getBlockX() + ";" + location.getBlockY() + ";" + location.getBlockZ();
    }

    private Location parseKey(String key) {
        String[] parts = key.split(";");
        if (parts.length != 4) return null;
        try {
            World world = Bukkit.getWorld(UUID.fromString(parts[0]));
            if (world == null) return null;
            return new Location(world, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private void migrateLegacyYaml() {
        File file = new File(plugin.getDataFolder(), "machines.yml");
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("machines");
        if (root == null) return;
        int migrated = 0;
        for (String legacyKey : root.getKeys(false)) {
            Location location = parseKey(legacyKey);
            if (location == null) continue;
            MachineType type = MachineType.fromId(root.getString(legacyKey + ".type"));
            if (type == null) continue;
            MachineInstance machine = new MachineInstance(location, type);
            machine.flux(root.getInt(legacyKey + ".flux", 0));
            machine.progress(root.getDouble(legacyKey + ".progress", 0.0));
            machine.heat(root.getDouble(legacyKey + ".heat", AMBIENT_HEAT));
            machine.targetHeat(root.getDouble(legacyKey + ".target-heat", type.defaultTargetHeat()));
            machine.quality(root.getInt(legacyKey + ".quality", 50));
            machine.input(root.getItemStack(legacyKey + ".input"));
            machine.catalyst(root.getItemStack(legacyKey + ".catalyst"));
            machine.fuel(root.getItemStack(legacyKey + ".fuel"));
            machine.output(root.getItemStack(legacyKey + ".output"));
            machine.completedProcessId(root.getString(legacyKey + ".completed-process"));
            for (int i = 0; i < 3; i++) machine.upgrade(i, root.getItemStack(legacyKey + ".upgrades." + i));
            machines.put(key(location), machine);
            migrated++;
        }
        if (migrated > 0) {
            boolean persisted = repository.saveAll(machines.values());
            if (!persisted) {
                plugin.getLogger().severe("Legacy machines.yml migration could not be committed; leaving the source file untouched.");
                return;
            }
            File backup = new File(plugin.getDataFolder(), "machines.yml.migrated");
            if (!file.renameTo(backup)) plugin.getLogger().warning("Migrated machines.yml to SQLite but could not rename the legacy file.");
            plugin.getLogger().info("Migrated " + migrated + " machines from machines.yml into voidcore.db.");
        }
    }
}
