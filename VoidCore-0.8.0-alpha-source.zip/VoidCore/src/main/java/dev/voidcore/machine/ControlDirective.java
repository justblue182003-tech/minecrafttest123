package dev.voidcore.machine;

import org.bukkit.Material;

public enum ControlDirective {
    BALANCED("balanced", "Balanced", Material.COMPASS,
        "Neutral policy with no artificial production bias.", 1.00, 1.00, 1.00, 1.00),
    THROUGHPUT("throughput", "Throughput", Material.SUGAR,
        "Push cycle rate harder at the cost of flux, wear, and entropy.", 1.18, 1.30, 1.22, 1.18),
    EFFICIENCY("efficiency", "Efficiency", Material.REDSTONE,
        "Reduce flux demand and entropy generation with a small cycle-rate penalty.", 0.92, 0.84, 0.92, 0.80),
    STABILITY("stability", "Stability", Material.AMETHYST_BLOCK,
        "Prioritize coherence and component life over raw throughput.", 0.86, 0.94, 0.72, 0.62);

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String description;
    private final double speedMultiplier;
    private final double fluxMultiplier;
    private final double wearMultiplier;
    private final double entropyMultiplier;

    ControlDirective(String id, String displayName, Material icon, String description,
                     double speedMultiplier, double fluxMultiplier, double wearMultiplier, double entropyMultiplier) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
        this.speedMultiplier = speedMultiplier;
        this.fluxMultiplier = fluxMultiplier;
        this.wearMultiplier = wearMultiplier;
        this.entropyMultiplier = entropyMultiplier;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public Material icon() { return icon; }
    public String description() { return description; }
    public double speedMultiplier() { return speedMultiplier; }
    public double fluxMultiplier() { return fluxMultiplier; }
    public double wearMultiplier() { return wearMultiplier; }
    public double entropyMultiplier() { return entropyMultiplier; }

    public ControlDirective next(int direction) {
        ControlDirective[] values = values();
        return values[Math.floorMod(ordinal() + (direction >= 0 ? 1 : -1), values.length)];
    }

    public static ControlDirective fromId(String id) {
        if (id == null) return BALANCED;
        for (ControlDirective directive : values()) if (directive.id.equalsIgnoreCase(id)) return directive;
        return BALANCED;
    }
}
