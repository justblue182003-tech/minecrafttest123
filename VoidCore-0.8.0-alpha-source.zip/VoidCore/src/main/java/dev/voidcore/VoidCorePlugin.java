package dev.voidcore;

import dev.voidcore.command.VoidCoreCommand;
import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.listener.CraftingListener;
import dev.voidcore.listener.MachineListener;
import dev.voidcore.listener.MenuListener;
import dev.voidcore.listener.ProgressionListener;
import dev.voidcore.machine.MachineService;
import dev.voidcore.network.NetworkService;
import dev.voidcore.persistence.MachineRepository;
import dev.voidcore.persistence.VoidDatabase;
import dev.voidcore.process.ProcessEngine;
import dev.voidcore.process.ProcessRegistry;
import dev.voidcore.recipe.RecipeCraftingService;
import dev.voidcore.recipe.RecipeRegistry;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchService;
import dev.voidcore.simulation.SpatialFieldService;
import dev.voidcore.ui.AutomationConfigMenu;
import dev.voidcore.ui.AutomationTerminalMenu;
import dev.voidcore.ui.CodexMenu;
import dev.voidcore.ui.ControlMatrixMenu;
import dev.voidcore.ui.CoreChamberMenu;
import dev.voidcore.ui.EngineeringMachineMenu;
import dev.voidcore.ui.ExperimentMenu;
import dev.voidcore.ui.FieldStabilizerMenu;
import dev.voidcore.ui.MachineDiagnosticsMenu;
import dev.voidcore.ui.MachineIndexMenu;
import dev.voidcore.ui.MachineMenu;
import dev.voidcore.ui.MaterialIndexMenu;
import dev.voidcore.ui.LogisticsNodeMenu;
import dev.voidcore.ui.NetworkDiagnosticsMenu;
import dev.voidcore.ui.ObserverMenu;
import dev.voidcore.ui.ProjectTerminalMenu;
import dev.voidcore.ui.PrototypeBenchMenu;
import dev.voidcore.ui.RecipeBrowserMenu;
import dev.voidcore.ui.ResearchMenu;
import dev.voidcore.ui.SpectrumAnalyzerMenu;
import dev.voidcore.ui.ThermalExchangerMenu;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.java.JavaPlugin;

public final class VoidCorePlugin extends JavaPlugin {
    private Keys keys;
    private ItemService items;
    private ResearchService research;
    private ExperimentService experiments;
    private DiscoveryService discoveries;
    private MachineService machines;
    private NetworkService networks;
    private SpatialFieldService spatialFields;
    private VoidDatabase database;
    private MachineMenu machineMenu;
    private EngineeringMachineMenu engineeringMenu;
    private MachineDiagnosticsMenu diagnosticsMenu;
    private ThermalExchangerMenu exchangerMenu;
    private NetworkDiagnosticsMenu networkMenu;
    private LogisticsNodeMenu logisticsMenu;
    private ObserverMenu observerMenu;
    private ControlMatrixMenu controlMatrixMenu;
    private FieldStabilizerMenu fieldStabilizerMenu;
    private AutomationConfigMenu automationConfigMenu;
    private AutomationTerminalMenu automationTerminalMenu;
    private CoreChamberMenu coreChamberMenu;
    private ProjectTerminalMenu projectTerminalMenu;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        keys = new Keys(this);
        items = new ItemService(keys);
        experiments = new ExperimentService(keys);
        research = new ResearchService(keys, experiments);
        discoveries = new DiscoveryService(keys);

        database = new VoidDatabase(this);
        database.open();

        ProcessRegistry processRecipes = new ProcessRegistry();
        ProcessEngine processEngine = new ProcessEngine(items);
        RecipeRegistry recipes = new RecipeRegistry(processRecipes);
        RecipeCraftingService crafting = new RecipeCraftingService(items, research, experiments, discoveries);

        MachineRepository machineRepository = new MachineRepository(this, database);
        machines = new MachineService(this, items, processRecipes, processEngine, machineRepository);
        machines.load();
        networks = new NetworkService(this, machines);
        spatialFields = new SpatialFieldService(this, machines);

        CodexMenu codexMenu = new CodexMenu(research, experiments, items);
        ResearchMenu researchMenu = new ResearchMenu(research, experiments);
        ExperimentMenu experimentMenu = new ExperimentMenu(experiments);
        RecipeBrowserMenu recipeBrowser = new RecipeBrowserMenu(recipes, items, research);
        MaterialIndexMenu materialIndex = new MaterialIndexMenu(items, discoveries, recipes);
        MachineIndexMenu machineIndex = new MachineIndexMenu(items, research, recipes);
        machineMenu = new MachineMenu(machines);
        engineeringMenu = new EngineeringMachineMenu(machines, items);
        diagnosticsMenu = new MachineDiagnosticsMenu(machines, items);
        exchangerMenu = new ThermalExchangerMenu(machines);
        networkMenu = new NetworkDiagnosticsMenu(machines, networks, experiments);
        logisticsMenu = new LogisticsNodeMenu(machines);
        observerMenu = new ObserverMenu(machines);
        controlMatrixMenu = new ControlMatrixMenu(machines, networks);
        fieldStabilizerMenu = new FieldStabilizerMenu(machines);
        automationConfigMenu = new AutomationConfigMenu(machines);
        automationTerminalMenu = new AutomationTerminalMenu(machines, networks);
        coreChamberMenu = new CoreChamberMenu(machines);
        projectTerminalMenu = new ProjectTerminalMenu(this, machines, networks, research, experiments, items, discoveries);
        PrototypeBenchMenu prototypeBench = new PrototypeBenchMenu(recipes, crafting, items, research);
        SpectrumAnalyzerMenu spectrumAnalyzer = new SpectrumAnalyzerMenu(items, discoveries, experiments, research);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new ProgressionListener(this, items, research, experiments, discoveries, codexMenu), this);
        pm.registerEvents(new MenuListener(codexMenu, researchMenu, experimentMenu, recipeBrowser, materialIndex,
            machineIndex, prototypeBench, spectrumAnalyzer, engineeringMenu, diagnosticsMenu, research, crafting, machines), this);
        pm.registerEvents(new CraftingListener(items, research), this);
        pm.registerEvents(new MachineListener(this, keys, items, research, experiments, discoveries, machines, networks,
            machineMenu, prototypeBench, spectrumAnalyzer, engineeringMenu, diagnosticsMenu, exchangerMenu, networkMenu, logisticsMenu, observerMenu,
            controlMatrixMenu, fieldStabilizerMenu, automationConfigMenu, automationTerminalMenu, coreChamberMenu, projectTerminalMenu, spatialFields), this);

        VoidCoreCommand commandHandler = new VoidCoreCommand(this, codexMenu, researchMenu, recipeBrowser,
            materialIndex, experimentMenu, machineIndex, research, items);
        PluginCommand command = getCommand("voidcore");
        if (command == null) throw new IllegalStateException("voidcore command missing from plugin.yml");
        command.setExecutor(commandHandler);
        command.setTabCompleter(commandHandler);

        registerRecipes();

        getServer().getScheduler().runTaskTimer(this, () -> {
            machineMenu.syncOpenMenus();
            engineeringMenu.syncOpenMenus();
            logisticsMenu.syncOpenMenus();
            networks.tick();
            spatialFields.tick();
            machines.tick();
            machineMenu.refreshOpenMenus();
            engineeringMenu.refreshOpenMenus();
            diagnosticsMenu.refreshOpenMenus();
            exchangerMenu.refreshOpenMenus();
            networkMenu.refreshOpenMenus();
            logisticsMenu.refreshOpenMenus();
            observerMenu.refreshOpenMenus();
            controlMatrixMenu.refreshOpenMenus();
            fieldStabilizerMenu.refreshOpenMenus();
            automationConfigMenu.refreshOpenMenus();
            automationTerminalMenu.refreshOpenMenus();
            coreChamberMenu.refreshOpenMenus();
            projectTerminalMenu.refreshOpenMenus();
        }, 20L, 20L);

        getServer().getScheduler().runTaskTimer(this, machines::saveAsync, 200L, 200L);
        getLogger().info("VoidCore 0.8 enabled: automation signals, dimensional infrastructure, singularity refinement, remote operations, and Project Nullstar online.");
    }

    @Override
    public void onDisable() {
        if (machineMenu != null) machineMenu.syncOpenMenus();
        if (engineeringMenu != null) engineeringMenu.syncOpenMenus();
        if (logisticsMenu != null) logisticsMenu.syncOpenMenus();
        if (machines != null) machines.saveNow();
        if (database != null) database.close();
    }

    private void registerRecipes() {
        NamespacedKey codexKey = new NamespacedKey(this, "void_codex");
        getServer().removeRecipe(codexKey);
        ShapedRecipe codex = new ShapedRecipe(codexKey, items.create(CustomItem.VOID_CODEX));
        codex.shape(" A ", "CBC", " A ");
        codex.setIngredient('A', Material.AMETHYST_SHARD);
        codex.setIngredient('B', Material.BOOK);
        codex.setIngredient('C', Material.COMPASS);
        getServer().addRecipe(codex);

        getServer().removeRecipe(new NamespacedKey(this, "flux_crucible"));

        NamespacedKey benchKey = new NamespacedKey(this, "prototype_bench");
        getServer().removeRecipe(benchKey);
        ShapedRecipe bench = new ShapedRecipe(benchKey, items.create(CustomItem.PROTOTYPE_BENCH));
        bench.shape("CIC", "FTI", "CIC");
        bench.setIngredient('C', Material.COPPER_INGOT);
        bench.setIngredient('I', Material.IRON_INGOT);
        bench.setIngredient('F', new RecipeChoice.ExactChoice(items.create(CustomItem.RESONANT_FRAGMENT)));
        bench.setIngredient('T', Material.CRAFTING_TABLE);
        getServer().addRecipe(bench);
    }
}
