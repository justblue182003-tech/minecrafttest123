package dev.voidcore.listener;

import dev.voidcore.item.CustomItem;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.recipe.RecipeCraftingService;
import dev.voidcore.recipe.VoidRecipe;
import dev.voidcore.research.ResearchNode;
import dev.voidcore.research.ResearchService;
import dev.voidcore.ui.CodexMenu;
import dev.voidcore.ui.ExperimentMenu;
import dev.voidcore.ui.EngineeringMachineMenu;
import dev.voidcore.ui.MachineDiagnosticsMenu;
import dev.voidcore.ui.MachineIndexMenu;
import dev.voidcore.ui.MachineMenu;
import dev.voidcore.ui.MachineMenuHolder;
import dev.voidcore.ui.MaterialIndexMenu;
import dev.voidcore.ui.MenuHolder;
import dev.voidcore.ui.PrototypeBenchMenu;
import dev.voidcore.ui.RecipeBrowserMenu;
import dev.voidcore.ui.ResearchMenu;
import dev.voidcore.ui.SpectrumAnalyzerMenu;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class MenuListener implements Listener {
    private final CodexMenu codex;
    private final ResearchMenu researchMenu;
    private final ExperimentMenu experimentMenu;
    private final RecipeBrowserMenu recipeBrowser;
    private final MaterialIndexMenu materialIndex;
    private final MachineIndexMenu machineIndex;
    private final PrototypeBenchMenu prototypeBench;
    private final SpectrumAnalyzerMenu spectrumAnalyzer;
    private final EngineeringMachineMenu engineeringMenu;
    private final MachineDiagnosticsMenu diagnosticsMenu;
    private final ResearchService research;
    private final RecipeCraftingService crafting;
    private final MachineService machines;

    public MenuListener(CodexMenu codex, ResearchMenu researchMenu, ExperimentMenu experimentMenu,
                        RecipeBrowserMenu recipeBrowser, MaterialIndexMenu materialIndex, MachineIndexMenu machineIndex,
                        PrototypeBenchMenu prototypeBench, SpectrumAnalyzerMenu spectrumAnalyzer,
                        EngineeringMachineMenu engineeringMenu, MachineDiagnosticsMenu diagnosticsMenu,
                        ResearchService research, RecipeCraftingService crafting, MachineService machines) {
        this.codex = codex;
        this.researchMenu = researchMenu;
        this.experimentMenu = experimentMenu;
        this.recipeBrowser = recipeBrowser;
        this.materialIndex = materialIndex;
        this.machineIndex = machineIndex;
        this.prototypeBench = prototypeBench;
        this.spectrumAnalyzer = spectrumAnalyzer;
        this.engineeringMenu = engineeringMenu;
        this.diagnosticsMenu = diagnosticsMenu;
        this.research = research;
        this.crafting = crafting;
        this.machines = machines;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        if (holder instanceof MachineMenuHolder && (holder.menuId().equals(MachineMenu.MENU_ID)
            || engineeringMenu.isMenu(holder) || holder.menuId().equals(MachineDiagnosticsMenu.MENU_ID))) return;

        event.setCancelled(true);
        int raw = event.getRawSlot();
        if (raw < 0 || raw >= event.getView().getTopInventory().getSize()) return;

        if (holder.menuId().equals("codex")) {
            handleCodex(player, raw);
            return;
        }
        if (holder.menuId().equals("research")) {
            handleResearch(player, raw);
            return;
        }
        if (holder.menuId().startsWith(ExperimentMenu.MENU_PREFIX)) {
            int page = experimentMenu.page(holder);
            if (raw == ExperimentMenu.BACK_SLOT) { click(player); codex.open(player); }
            else if (raw == ExperimentMenu.PREVIOUS_SLOT) { click(player); experimentMenu.open(player, page - 1); }
            else if (raw == ExperimentMenu.NEXT_SLOT) { click(player); experimentMenu.open(player, page + 1); }
            return;
        }
        if (holder.menuId().startsWith(MaterialIndexMenu.MENU_PREFIX)) {
            handleMaterials(player, holder, raw);
            return;
        }
        if (holder.menuId().equals("machines")) {
            handleMachineIndex(player, raw);
            return;
        }
        if (holder.menuId().startsWith("recipes:")) {
            handleRecipes(player, holder, raw);
            return;
        }
        if (holder.menuId().startsWith("recipe-detail:")) {
            if (raw == RecipeBrowserMenu.BACK_SLOT) {
                click(player);
                recipeBrowser.open(player, recipeBrowser.detailReturnPage(holder));
            }
            return;
        }
        if (holder instanceof MachineMenuHolder machineHolder && prototypeBench.isPrototypeMenu(holder)) {
            handlePrototype(player, machineHolder, raw, event.isShiftClick());
            return;
        }
        if (holder instanceof MachineMenuHolder machineHolder && holder.menuId().equals(SpectrumAnalyzerMenu.MENU_ID)) {
            handleAnalyzer(player, machineHolder, raw);
        }
    }

    private void handleCodex(Player player, int raw) {
        switch (raw) {
            case CodexMenu.RESEARCH_SLOT -> { click(player); researchMenu.open(player); }
            case CodexMenu.RECIPES_SLOT -> { click(player); recipeBrowser.open(player); }
            case CodexMenu.MATERIALS_SLOT -> { click(player); materialIndex.open(player); }
            case CodexMenu.MACHINES_SLOT -> { click(player); machineIndex.open(player); }
            case CodexMenu.EXPERIMENTS_SLOT -> { click(player); experimentMenu.open(player); }
            default -> { }
        }
    }

    private void handleResearch(Player player, int raw) {
        if (raw == ResearchMenu.BACK_SLOT) {
            click(player);
            codex.open(player);
            return;
        }
        ResearchNode node = researchMenu.nodeAt(raw);
        if (node == null) return;

        ResearchService.UnlockResult result = research.unlock(player, node);
        switch (result) {
            case UNLOCKED -> {
                player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_CLUSTER_HIT, 0.8f, 1.6f);
                player.sendMessage(Component.text("Research unlocked: ", NamedTextColor.GREEN)
                    .append(Component.text(node.displayName(), NamedTextColor.LIGHT_PURPLE)));
            }
            case ALREADY_UNLOCKED -> player.sendActionBar(Text.muted("Already researched."));
            case MISSING_PREREQUISITE -> player.sendActionBar(Text.bad("Complete the prerequisite research first."));
            case MISSING_EXPERIMENT -> player.sendActionBar(Text.bad("Complete the listed experiments first."));
            case NOT_ENOUGH_INSIGHT -> player.sendActionBar(Text.bad("You need more Insight."));
        }
        researchMenu.open(player);
    }

    private void handleMaterials(Player player, MenuHolder holder, int raw) {
        int page = materialIndex.page(holder);
        if (raw == MaterialIndexMenu.BACK_SLOT) {
            click(player);
            codex.open(player);
            return;
        }
        if (raw == MaterialIndexMenu.PREVIOUS_SLOT) {
            click(player);
            materialIndex.open(player, page - 1);
            return;
        }
        if (raw == MaterialIndexMenu.NEXT_SLOT) {
            click(player);
            materialIndex.open(player, page + 1);
            return;
        }
        CustomItem item = materialIndex.itemAt(holder, raw);
        if (item == null) return;
        VoidRecipe recipe = materialIndex.recipeFor(item);
        if (recipe == null) {
            player.sendActionBar(Text.muted("No fabrication recipe is registered for this material."));
            return;
        }
        click(player);
        recipeBrowser.openDetail(player, recipe, 0);
    }

    private void handleMachineIndex(Player player, int raw) {
        if (raw == MachineIndexMenu.BACK_SLOT) {
            click(player);
            codex.open(player);
            return;
        }
        MachineType type = machineIndex.typeAt(raw);
        if (type == null) return;
        VoidRecipe recipe = machineIndex.recipeFor(type);
        if (recipe == null) {
            player.sendActionBar(Text.muted("This machine has no registered fabrication recipe."));
            return;
        }
        click(player);
        recipeBrowser.openDetail(player, recipe, 0);
    }

    private void handleRecipes(Player player, MenuHolder holder, int raw) {
        int page = recipeBrowser.page(holder);
        if (raw == RecipeBrowserMenu.BACK_SLOT) {
            click(player);
            codex.open(player);
            return;
        }
        if (raw == RecipeBrowserMenu.PREVIOUS_SLOT) {
            click(player);
            recipeBrowser.open(player, page - 1);
            return;
        }
        if (raw == RecipeBrowserMenu.NEXT_SLOT) {
            click(player);
            recipeBrowser.open(player, page + 1);
            return;
        }
        VoidRecipe recipe = recipeBrowser.recipeAt(holder, raw);
        if (recipe != null) {
            click(player);
            recipeBrowser.openDetail(player, recipe, page);
        }
    }

    private void handlePrototype(Player player, MachineMenuHolder holder, int raw, boolean shiftClick) {
        MachineInstance machine = machines.get(holder.machineLocation());
        if (machine == null || machine.type() != MachineType.PROTOTYPE_BENCH) {
            player.closeInventory();
            return;
        }
        int page = prototypeBench.page(holder);
        if (raw == PrototypeBenchMenu.CLOSE_SLOT) {
            player.closeInventory();
            return;
        }
        if (raw == PrototypeBenchMenu.PREVIOUS_SLOT) {
            click(player);
            prototypeBench.open(player, machine, page - 1);
            return;
        }
        if (raw == PrototypeBenchMenu.NEXT_SLOT) {
            click(player);
            prototypeBench.open(player, machine, page + 1);
            return;
        }

        VoidRecipe recipe = prototypeBench.recipeAt(holder, raw);
        if (recipe == null) return;
        if (recipe.research() != null && !research.isUnlocked(player, recipe.research())) {
            player.sendActionBar(Text.bad("Requires " + recipe.research().displayName() + "."));
            return;
        }
        if (!crafting.canCraft(player, recipe)) {
            player.sendActionBar(Text.bad("Missing one or more ingredients."));
            return;
        }

        int crafted;
        if (shiftClick) crafted = crafting.craftBatch(player, recipe, 16);
        else crafted = crafting.craftOne(player, recipe) == RecipeCraftingService.CraftResult.CRAFTED ? 1 : 0;

        if (crafted > 0) {
            player.playSound(player.getLocation(), Sound.BLOCK_SMITHING_TABLE_USE, 0.6f, 1.25f);
            player.sendActionBar(Text.good("Assembled " + (crafted * recipe.outputAmount()) + "x " + recipe.output().displayName() + "."));
        }
        prototypeBench.open(player, machine, page);
    }

    private void handleAnalyzer(Player player, MachineMenuHolder holder, int raw) {
        MachineInstance machine = machines.get(holder.machineLocation());
        if (machine == null || machine.type() != MachineType.SPECTRUM_ANALYZER) {
            player.closeInventory();
            return;
        }
        if (raw == SpectrumAnalyzerMenu.CLOSE_SLOT) {
            player.closeInventory();
            return;
        }
        CustomItem item = spectrumAnalyzer.itemAt(raw);
        if (item == null) return;

        SpectrumAnalyzerMenu.AnalyzeResult result = spectrumAnalyzer.analyze(player, item);
        switch (result) {
            case NEW_DISCOVERY -> {
                player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.8f, 1.4f);
                player.sendActionBar(Text.good("New spectral signature catalogued: " + item.displayName()));
            }
            case ALREADY_KNOWN -> player.sendActionBar(Text.muted("That spectral signature is already catalogued."));
            case MISSING_SAMPLE -> player.sendActionBar(Text.bad("Carry a " + item.displayName() + " in your inventory to scan it."));
        }
        spectrumAnalyzer.open(player, machine);
    }

    private void click(Player player) {
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.35f, 1.4f);
    }
    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder)) return;
        int topSize = event.getView().getTopInventory().getSize();
        if (event.getRawSlots().stream().anyMatch(slot -> slot < topSize)) event.setCancelled(true);
    }

}
