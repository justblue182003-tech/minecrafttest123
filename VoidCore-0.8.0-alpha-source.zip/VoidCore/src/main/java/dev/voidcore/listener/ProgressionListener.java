package dev.voidcore.listener;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchService;
import dev.voidcore.ui.CodexMenu;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.concurrent.ThreadLocalRandom;

public final class ProgressionListener implements Listener {
    private final VoidCorePlugin plugin;
    private final ItemService items;
    private final ResearchService research;
    private final ExperimentService experiments;
    private final DiscoveryService discoveries;
    private final CodexMenu codex;

    public ProgressionListener(VoidCorePlugin plugin, ItemService items, ResearchService research,
                               ExperimentService experiments, DiscoveryService discoveries, CodexMenu codex) {
        this.plugin = plugin;
        this.items = items;
        this.research = research;
        this.experiments = experiments;
        this.discoveries = discoveries;
        this.codex = codex;
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent event) {
        DropProfile profile = profile(event.getBlock().getType());
        if (profile == null) return;

        double chance = plugin.getConfig().getDouble("progression.fragment-drop-chance." + profile.configKey, profile.defaultChance);
        if (ThreadLocalRandom.current().nextDouble() > chance) return;

        int insight = plugin.getConfig().getInt("progression.insight." + profile.configKey, profile.defaultInsight);
        event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), items.create(CustomItem.RESONANT_FRAGMENT));
        research.addInsight(event.getPlayer(), insight);
        discoveries.discover(event.getPlayer(), CustomItem.RESONANT_FRAGMENT);
        experiments.advance(event.getPlayer(), ResearchExperiment.DISCOVER_RESONANCE);
        event.getPlayer().sendActionBar(
            Component.text("+" + insight + " Insight", NamedTextColor.AQUA)
                .append(Component.text(" • Resonant Fragment discovered", NamedTextColor.DARK_GRAY))
        );
    }

    @EventHandler(ignoreCancelled = true)
    public void onUseCodex(PlayerInteractEvent event) {
        if (!event.getAction().isRightClick()) return;
        if (!items.is(event.getItem(), CustomItem.VOID_CODEX)) return;
        event.setCancelled(true);
        codex.open(event.getPlayer());
    }

    private DropProfile profile(Material material) {
        return switch (material) {
            case DEEPSLATE_REDSTONE_ORE -> new DropProfile("deepslate-redstone", 0.08, 1);
            case DEEPSLATE_LAPIS_ORE -> new DropProfile("deepslate-lapis", 0.06, 1);
            case DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE -> new DropProfile("diamond", 0.12, 2);
            case ANCIENT_DEBRIS -> new DropProfile("ancient-debris", 0.25, 4);
            default -> null;
        };
    }

    private record DropProfile(String configKey, double defaultChance, int defaultInsight) {}
}
