package dev.voidcore.listener;

import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.research.ResearchNode;
import dev.voidcore.research.ResearchService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;

public final class CraftingListener implements Listener {
    private final ItemService items;
    private final ResearchService research;

    public CraftingListener(ItemService items, ResearchService research) {
        this.items = items;
        this.research = research;
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();
        if (!(event.getView().getPlayer() instanceof Player player)) return;

        if (items.is(result, CustomItem.PROTOTYPE_BENCH)
            && !research.isUnlocked(player, ResearchNode.FIELD_FABRICATION)) {
            event.getInventory().setResult(null);
        }
    }
}
