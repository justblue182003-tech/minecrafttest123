package dev.voidcore.listener;

import dev.voidcore.Keys;
import dev.voidcore.VoidCorePlugin;
import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.item.UpgradeType;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineFault;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.network.NetworkMetrics;
import dev.voidcore.network.NetworkService;
import dev.voidcore.process.ProcessRecipe;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchService;
import dev.voidcore.ui.AutomationConfigMenu;
import dev.voidcore.ui.AutomationTerminalMenu;
import dev.voidcore.ui.ControlMatrixMenu;
import dev.voidcore.ui.CoreChamberMenu;
import dev.voidcore.ui.EngineeringMachineMenu;
import dev.voidcore.ui.FieldStabilizerMenu;
import dev.voidcore.ui.MachineDiagnosticsMenu;
import dev.voidcore.ui.LogisticsNodeMenu;
import dev.voidcore.ui.MachineMenu;
import dev.voidcore.ui.MachineMenuHolder;
import dev.voidcore.ui.NetworkDiagnosticsMenu;
import dev.voidcore.ui.ObserverMenu;
import dev.voidcore.ui.ProjectTerminalMenu;
import dev.voidcore.ui.PrototypeBenchMenu;
import dev.voidcore.ui.SpectrumAnalyzerMenu;
import dev.voidcore.ui.ThermalExchangerMenu;
import dev.voidcore.simulation.SpatialFieldService;
import dev.voidcore.util.Text;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.TileState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.Set;

public final class MachineListener implements Listener {
    private static final Set<Integer> CRUCIBLE_EDITABLE = Set.of(MachineMenu.INPUT_SLOT, MachineMenu.FUEL_SLOT, MachineMenu.OUTPUT_SLOT);

    private final VoidCorePlugin plugin;
    private final Keys keys;
    private final ItemService items;
    private final ResearchService research;
    private final ExperimentService experiments;
    private final DiscoveryService discoveries;
    private final MachineService machines;
    private final NetworkService networks;
    private final MachineMenu crucibleMenu;
    private final PrototypeBenchMenu prototypeMenu;
    private final SpectrumAnalyzerMenu analyzerMenu;
    private final EngineeringMachineMenu engineeringMenu;
    private final MachineDiagnosticsMenu diagnosticsMenu;
    private final ThermalExchangerMenu exchangerMenu;
    private final NetworkDiagnosticsMenu networkMenu;
    private final LogisticsNodeMenu logisticsMenu;
    private final ObserverMenu observerMenu;
    private final ControlMatrixMenu controlMatrixMenu;
    private final FieldStabilizerMenu fieldStabilizerMenu;
    private final AutomationConfigMenu automationConfigMenu;
    private final AutomationTerminalMenu automationTerminalMenu;
    private final CoreChamberMenu coreChamberMenu;
    private final ProjectTerminalMenu projectTerminalMenu;
    private final SpatialFieldService spatialFields;

    public MachineListener(VoidCorePlugin plugin, Keys keys, ItemService items, ResearchService research,
                           ExperimentService experiments, DiscoveryService discoveries,
                           MachineService machines, NetworkService networks, MachineMenu crucibleMenu,
                           PrototypeBenchMenu prototypeMenu, SpectrumAnalyzerMenu analyzerMenu,
                           EngineeringMachineMenu engineeringMenu, MachineDiagnosticsMenu diagnosticsMenu,
                           ThermalExchangerMenu exchangerMenu, NetworkDiagnosticsMenu networkMenu, LogisticsNodeMenu logisticsMenu, ObserverMenu observerMenu,
                           ControlMatrixMenu controlMatrixMenu, FieldStabilizerMenu fieldStabilizerMenu,
                           AutomationConfigMenu automationConfigMenu, AutomationTerminalMenu automationTerminalMenu, CoreChamberMenu coreChamberMenu,
                           ProjectTerminalMenu projectTerminalMenu, SpatialFieldService spatialFields) {
        this.plugin = plugin;
        this.keys = keys;
        this.items = items;
        this.research = research;
        this.experiments = experiments;
        this.discoveries = discoveries;
        this.machines = machines;
        this.networks = networks;
        this.crucibleMenu = crucibleMenu;
        this.prototypeMenu = prototypeMenu;
        this.analyzerMenu = analyzerMenu;
        this.engineeringMenu = engineeringMenu;
        this.diagnosticsMenu = diagnosticsMenu;
        this.exchangerMenu = exchangerMenu;
        this.networkMenu = networkMenu;
        this.logisticsMenu = logisticsMenu;
        this.observerMenu = observerMenu;
        this.controlMatrixMenu = controlMatrixMenu;
        this.fieldStabilizerMenu = fieldStabilizerMenu;
        this.automationConfigMenu = automationConfigMenu;
        this.automationTerminalMenu = automationTerminalMenu;
        this.coreChamberMenu = coreChamberMenu;
        this.projectTerminalMenu = projectTerminalMenu;
        this.spatialFields = spatialFields;
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent event) {
        CustomItem custom = items.identify(event.getItemInHand());
        MachineType type = MachineType.fromItem(custom);
        if (type == null) return;

        if (!research.isUnlocked(event.getPlayer(), type.research())) {
            event.setCancelled(true);
            event.getPlayer().sendActionBar(Text.bad(type.research().displayName() + " research is required to place this machine."));
            return;
        }

        machines.register(event.getBlockPlaced().getLocation(), type, event.getItemInHand());
        BlockState state = event.getBlockPlaced().getState();
        if (state instanceof TileState tile) {
            tile.getPersistentDataContainer().set(keys.machineType, PersistentDataType.STRING, type.id());
            tile.update(true, false);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (!event.getAction().isRightClick() || event.getClickedBlock() == null) return;
        MachineInstance machine = machines.get(event.getClickedBlock().getLocation());
        if (machine == null) return;
        event.setCancelled(true);

        ItemStack held = event.getItem();
        if (machine.hasFault() && machine.fault().repairItem() != null && items.is(held, machine.fault().repairItem())) {
            MachineFault previous = machine.fault();
            if (machines.repairFault(machine)) {
                if (event.getPlayer().getGameMode() != GameMode.CREATIVE) held.setAmount(held.getAmount() - 1);
                experiments.advance(event.getPlayer(), ResearchExperiment.FAULT_RECOVERY);
                if (previous.entropyChain()) experiments.advance(event.getPlayer(), ResearchExperiment.ENTROPY_CHAIN_RECOVERY);
                if (previous.fieldChain()) experiments.advance(event.getPlayer(), ResearchExperiment.INCIDENT_RECOVERY);
                event.getPlayer().sendActionBar(Text.good(previous.hardLock()
                    ? "Hard fault cleared; the machine can be recommissioned." : "Coherence drift arrested before escalation."));
            }
            return;
        }
        if (items.is(held, CustomItem.MAINTENANCE_KIT)) {
            serviceMachine(event.getPlayer(), machine, held);
            return;
        }

        if (!research.isUnlocked(event.getPlayer(), machine.type().research())) {
            event.getPlayer().sendActionBar(Text.bad("You do not understand this machine yet."));
            return;
        }
        if (event.getPlayer().isSneaking() && items.is(held, CustomItem.SIGNAL_CRYSTAL)) {
            automationConfigMenu.open(event.getPlayer(), machine);
            return;
        }

        if (machine.type() == MachineType.PHASE_OBSERVER && machine.computation() >= 250)
            experiments.advance(event.getPlayer(), ResearchExperiment.STABLE_OBSERVATION);
        if (machine.type() == MachineType.ENTROPY_CONDENSER && machines.structureStatus(machine).valid())
            experiments.advance(event.getPlayer(), ResearchExperiment.ASSEMBLE_CONDENSER_ARRAY);
        if (machine.type() == MachineType.VOID_CORE && machines.structureStatus(machine).valid())
            experiments.advance(event.getPlayer(), ResearchExperiment.ASSEMBLE_VOID_CORE);
        if (machine.lifetimeCycles() >= 25) experiments.advance(event.getPlayer(), ResearchExperiment.PRODUCTION_HISTORY);
        if (machine.fieldStability() >= 80.0) experiments.advance(event.getPlayer(), ResearchExperiment.FIELD_CALIBRATION);
        NetworkMetrics networkMetrics = machine.type().isNetworkBlock() ? networks.metricsAt(machine.location()) : null;
        if (machine.type() == MachineType.DIMENSIONAL_ANCHOR && networkMetrics != null && networkMetrics.crossDimensional())
            experiments.advance(event.getPlayer(), ResearchExperiment.DIMENSIONAL_LINK);
        if (machine.type() == MachineType.AUTOMATION_TERMINAL && networkMetrics != null) {
            String terminalAddress = machines.networkAddress(machine);
            long groupedEndpoints = networkMetrics.endpoints().stream()
                .filter(endpoint -> !endpoint.address().equals(terminalAddress))
                .filter(endpoint -> endpoint.automationGroup() == machine.automationGroup())
                .count();
            if (groupedEndpoints >= 3) experiments.advance(event.getPlayer(), ResearchExperiment.REMOTE_OPERATIONS);

            boolean gatedTargetOnChannel = networkMetrics.endpoints().stream()
                .filter(endpoint -> !endpoint.address().equals(terminalAddress))
                .anyMatch(endpoint -> endpoint.signalChannel() == machine.signalChannel()
                    && !endpoint.signalGate().equalsIgnoreCase("Ignore Signal")
                    && endpoint.automationGroup() == machine.automationGroup());
            if (machine.automationRule() != dev.voidcore.machine.AutomationRule.ALWAYS
                && machine.signalHigh() && gatedTargetOnChannel)
                experiments.advance(event.getPlayer(), ResearchExperiment.SIGNAL_AUTOMATION);
        }

        switch (machine.type()) {
            case FLUX_CRUCIBLE -> crucibleMenu.open(event.getPlayer(), machine);
            case PROTOTYPE_BENCH -> prototypeMenu.open(event.getPlayer(), machine);
            case SPECTRUM_ANALYZER -> analyzerMenu.open(event.getPlayer(), machine);
            case INDUCTION_HEATER, CATALYTIC_REACTOR, MATRIX_PURIFIER, CRYOGENIC_COLUMN, PRESSURE_VESSEL, ENTROPY_CONDENSER, VOID_CORE -> engineeringMenu.open(event.getPlayer(), machine);
            case THERMAL_EXCHANGER -> exchangerMenu.open(event.getPlayer(), machine);
            case FLUX_BUS, ADDRESS_NODE, DIMENSIONAL_ANCHOR -> networkMenu.open(event.getPlayer(), machine);
            case PHASE_ROUTER, PRIORITY_BUFFER, FREQUENCY_SPLITTER -> logisticsMenu.open(event.getPlayer(), machine);
            case PHASE_OBSERVER -> observerMenu.open(event.getPlayer(), machine);
            case FIELD_STABILIZER -> fieldStabilizerMenu.open(event.getPlayer(), machine);
            case CONTROL_MATRIX -> controlMatrixMenu.open(event.getPlayer(), machine);
            case AUTOMATION_TERMINAL -> automationTerminalMenu.open(event.getPlayer(), machine);
            case VOID_UPGRADE_CHAMBER -> coreChamberMenu.open(event.getPlayer(), machine);
            case PROJECT_TERMINAL -> projectTerminalMenu.open(event.getPlayer(), machine);
        }
    }

    private void serviceMachine(Player player, MachineInstance machine, ItemStack kit) {
        if (machine.wear() <= 0.05) {
            player.sendActionBar(Text.good("No service required: wear is effectively zero."));
            return;
        }
        int quality = items.quality(kit);
        double restored = machines.service(machine, quality);
        if (restored <= 0.0) return;
        if (player.getGameMode() != GameMode.CREATIVE) {
            kit.setAmount(kit.getAmount() - 1);
        }
        experiments.advance(player, ResearchExperiment.SERVICE_MACHINE);
        player.sendActionBar(Text.good(String.format(java.util.Locale.ROOT,
            "Serviced %s • wear reduced by %.1f%%", machine.type().displayName(), restored)));
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent event) {
        if (!machines.isMachine(event.getBlock().getLocation())) return;
        closeViewersAt(event.getBlock().getLocation());
        MachineInstance machine = machines.unregister(event.getBlock().getLocation());
        if (machine == null) return;
        event.setDropItems(false);
        dropStoredContents(machine);
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
            event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), machines.machineDrop(machine));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplosion(EntityExplodeEvent event) { destroyMachinesInExplosion(event.blockList()); }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplosion(BlockExplodeEvent event) { destroyMachinesInExplosion(event.blockList()); }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (event.getBlocks().stream().anyMatch(block -> machines.isMachine(block.getLocation()))) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (event.getBlocks().stream().anyMatch(block -> machines.isMachine(block.getLocation()))) event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof MachineMenuHolder holder)) return;

        if (holder.menuId().equals(MachineMenu.MENU_ID)) {
            handleCrucibleClick(event, top);
            return;
        }
        if (holder.menuId().startsWith(EngineeringMachineMenu.MENU_PREFIX)) {
            handleEngineeringClick(event, top, holder);
            return;
        }
        if (holder.menuId().equals(MachineDiagnosticsMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null) { nextTick(player::closeInventory); return; }
            int raw = event.getRawSlot();
            if (raw == MachineDiagnosticsMenu.BACK_SLOT) nextTick(() -> engineeringMenu.open(player, machine));
            else if (raw == MachineDiagnosticsMenu.GROUP_SLOT) {
                machines.cycleAutomationGroup(machine, event.isRightClick() ? -1 : 1);
                nextTick(() -> diagnosticsMenu.open(player, machine));
            } else if (raw == MachineDiagnosticsMenu.CHANNEL_SLOT) {
                machines.cycleSignalChannel(machine, event.isRightClick() ? -1 : 1);
                nextTick(() -> diagnosticsMenu.open(player, machine));
            } else if (raw == MachineDiagnosticsMenu.GATE_SLOT) {
                machines.cycleSignalGate(machine, event.isRightClick() ? -1 : 1);
                nextTick(() -> diagnosticsMenu.open(player, machine));
            } else if (raw == MachineDiagnosticsMenu.SINGULARITY_SLOT && machine.type() == MachineType.VOID_CORE) {
                machines.cycleSingularityMode(machine, event.isRightClick() ? -1 : 1);
                if (machine.singularityMode() != dev.voidcore.machine.SingularityMode.CONTAINED
                    && machines.coreChamberCount(machine, dev.voidcore.machine.CoreChamberMode.STABILIZATION)
                     + machines.coreChamberCount(machine, dev.voidcore.machine.CoreChamberMode.COMPRESSION)
                     + machines.coreChamberCount(machine, dev.voidcore.machine.CoreChamberMode.EXTRACTION) > 0)
                    experiments.advance(player, ResearchExperiment.CORE_UPGRADE);
                nextTick(() -> diagnosticsMenu.open(player, machine));
            } else if (raw == MachineDiagnosticsMenu.FIELD_VISUALIZE_SLOT) {
                int sources = spatialFields.visualize(player, machine);
                experiments.advance(player, ResearchExperiment.FIELD_VISUALIZATION);
                player.sendActionBar(Text.accent("Rendered spatial field trace • " + sources + " nearby field sources"));
            }
            return;
        }
        if (holder.menuId().equals(ThermalExchangerMenu.MENU_ID)) {
            event.setCancelled(true);
            if (event.getWhoClicked() instanceof Player player && event.getRawSlot() == ThermalExchangerMenu.CLOSE_SLOT) nextTick(player::closeInventory);
            return;
        }
        if (holder.menuId().equals(NetworkDiagnosticsMenu.MENU_ID)) {
            handleNetworkClick(event, holder);
            return;
        }
        if (holder.menuId().equals(LogisticsNodeMenu.MENU_ID)) {
            handleLogisticsClick(event, top, holder);
            return;
        }
        if (holder.menuId().equals(ObserverMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance observer = machines.get(holder.machineLocation());
            if (observer == null) { nextTick(player::closeInventory); return; }
            if (event.getRawSlot() == ObserverMenu.PROGRAM_SLOT) {
                machines.cycleObserverProgram(observer, event.isRightClick() ? -1 : 1);
                if (observer.observerProgram() != dev.voidcore.machine.ObserverProgram.BROAD_SPECTRUM)
                    experiments.advance(player, ResearchExperiment.PROGRAM_OBSERVER);
                nextTick(() -> observerMenu.open(player, observer));
            } else if (event.getRawSlot() == ObserverMenu.CLOSE_SLOT) nextTick(player::closeInventory);
            return;
        }
        if (holder.menuId().equals(ControlMatrixMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance matrix = machines.get(holder.machineLocation());
            if (matrix == null) { nextTick(player::closeInventory); return; }
            if (event.getRawSlot() == ControlMatrixMenu.POLICY_PREVIOUS_SLOT || event.getRawSlot() == ControlMatrixMenu.POLICY_NEXT_SLOT) {
                machines.cycleControlDirective(matrix, event.getRawSlot() == ControlMatrixMenu.POLICY_PREVIOUS_SLOT ? -1 : 1);
                nextTick(() -> controlMatrixMenu.open(player, matrix));
            } else if (event.getRawSlot() == ControlMatrixMenu.DIAGNOSTICS_SLOT) nextTick(() -> networkMenu.open(player, matrix));
            else if (event.getRawSlot() == ControlMatrixMenu.CLOSE_SLOT) nextTick(player::closeInventory);
            return;
        }
        if (holder.menuId().equals(AutomationConfigMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null) { nextTick(player::closeInventory); return; }
            int raw = event.getRawSlot();
            if (raw == AutomationConfigMenu.GROUP_SLOT) machines.cycleAutomationGroup(machine, event.isRightClick() ? -1 : 1);
            else if (raw == AutomationConfigMenu.CHANNEL_SLOT) machines.cycleSignalChannel(machine, event.isRightClick() ? -1 : 1);
            else if (raw == AutomationConfigMenu.GATE_SLOT) machines.cycleSignalGate(machine, event.isRightClick() ? -1 : 1);
            else if (raw == AutomationConfigMenu.CLOSE_SLOT) { nextTick(player::closeInventory); return; }
            else return;
            nextTick(() -> automationConfigMenu.open(player, machine));
            return;
        }
        if (holder.menuId().equals(AutomationTerminalMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance terminal = machines.get(holder.machineLocation());
            if (terminal == null || terminal.type() != MachineType.AUTOMATION_TERMINAL) { nextTick(player::closeInventory); return; }
            int raw = event.getRawSlot();
            if (raw == AutomationTerminalMenu.RULE_SLOT) machines.cycleAutomationRule(terminal, event.isRightClick() ? -1 : 1);
            else if (raw == AutomationTerminalMenu.GROUP_SLOT) machines.cycleAutomationGroup(terminal, event.isRightClick() ? -1 : 1);
            else if (raw == AutomationTerminalMenu.CHANNEL_SLOT) machines.cycleSignalChannel(terminal, event.isRightClick() ? -1 : 1);
            else if (raw == AutomationTerminalMenu.DIAGNOSTICS_SLOT) { nextTick(() -> networkMenu.open(player, terminal)); return; }
            else if (raw == AutomationTerminalMenu.CLOSE_SLOT) { nextTick(player::closeInventory); return; }
            else return;
            nextTick(() -> automationTerminalMenu.open(player, terminal));
            return;
        }
        if (holder.menuId().equals(CoreChamberMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance chamber = machines.get(holder.machineLocation());
            if (chamber == null || chamber.type() != MachineType.VOID_UPGRADE_CHAMBER) { nextTick(player::closeInventory); return; }
            if (event.getRawSlot() == CoreChamberMenu.MODE_SLOT) {
                machines.cycleCoreChamberMode(chamber, event.isRightClick() ? -1 : 1);
                nextTick(() -> coreChamberMenu.open(player, chamber));
            } else if (event.getRawSlot() == CoreChamberMenu.CLOSE_SLOT) nextTick(player::closeInventory);
            return;
        }
        if (holder.menuId().equals(ProjectTerminalMenu.MENU_ID)) {
            event.setCancelled(true);
            if (!(event.getWhoClicked() instanceof Player player)) return;
            MachineInstance terminal = machines.get(holder.machineLocation());
            if (terminal == null || terminal.type() != MachineType.PROJECT_TERMINAL) { nextTick(player::closeInventory); return; }
            if (event.getRawSlot() == ProjectTerminalMenu.COMMISSION_SLOT) {
                ProjectTerminalMenu.CommissionResult result = projectTerminalMenu.commission(player, terminal);
                switch (result) {
                    case COMMISSIONED -> player.sendActionBar(Text.good("Project Nullstar commissioned • Ascendant Core issued."));
                    case ALREADY_COMMISSIONED -> player.sendActionBar(Text.muted("You have already commissioned Project Nullstar."));
                    case RESEARCH_LOCKED -> player.sendActionBar(Text.bad("Dimensional Infrastructure research is required."));
                    case NOT_READY -> player.sendActionBar(Text.bad("Project Nullstar infrastructure requirements are not yet satisfied."));
                }
                nextTick(() -> projectTerminalMenu.open(player, terminal));
            } else if (event.getRawSlot() == ProjectTerminalMenu.NETWORK_SLOT) nextTick(() -> networkMenu.open(player, terminal));
            else if (event.getRawSlot() == ProjectTerminalMenu.CLOSE_SLOT) nextTick(player::closeInventory);
            return;
        }
        if (holder.menuId().equals(FieldStabilizerMenu.MENU_ID)) {
            event.setCancelled(true);
            if (event.getWhoClicked() instanceof Player player && event.getRawSlot() == FieldStabilizerMenu.CLOSE_SLOT) nextTick(player::closeInventory);
        }
    }

    private void handleCrucibleClick(InventoryClickEvent event, Inventory top) {
        int raw = event.getRawSlot();
        if (raw < 0) return;
        if (raw >= top.getSize()) {
            if (event.isShiftClick()) event.setCancelled(true);
            return;
        }
        if (!CRUCIBLE_EDITABLE.contains(raw)) {
            event.setCancelled(true);
            return;
        }

        ItemStack candidate = candidate(event);
        if (raw == MachineMenu.OUTPUT_SLOT) {
            boolean inserting = candidate != null && !candidate.getType().isAir();
            if (inserting) {
                event.setCancelled(true);
                return;
            }
            if (event.getWhoClicked() instanceof Player player && items.is(event.getCurrentItem(), CustomItem.CHARGED_RESONANCE)) {
                discoveries.discover(player, CustomItem.CHARGED_RESONANCE);
                experiments.advance(player, ResearchExperiment.STABILIZE_RESONANCE);
            }
            return;
        }
        if (candidate == null || candidate.getType().isAir()) return;
        if (raw == MachineMenu.INPUT_SLOT && !items.is(candidate, CustomItem.RESONANT_FRAGMENT)) event.setCancelled(true);
        else if (raw == MachineMenu.FUEL_SLOT && !isFuel(candidate)) event.setCancelled(true);
    }

    private void handleEngineeringClick(InventoryClickEvent event, Inventory top, MachineMenuHolder holder) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        MachineInstance machine = machines.get(holder.machineLocation());
        if (machine == null || !machine.type().isEngineeringProcessor()) {
            event.setCancelled(true);
            nextTick(player::closeInventory);
            return;
        }

        int raw = event.getRawSlot();
        if (raw < 0) return;
        if (raw >= top.getSize()) {
            if (event.isShiftClick()) event.setCancelled(true);
            return;
        }

        if (raw == EngineeringMachineMenu.TARGET_DOWN_SLOT || raw == EngineeringMachineMenu.TARGET_UP_SLOT) {
            event.setCancelled(true);
            engineeringMenu.sync(top, holder);
            machines.adjustTargetHeat(machine, raw == EngineeringMachineMenu.TARGET_DOWN_SLOT ? -25.0 : 25.0);
            nextTick(() -> engineeringMenu.open(player, machine));
            return;
        }
        if (raw == EngineeringMachineMenu.PRESSURE_DOWN_SLOT || raw == EngineeringMachineMenu.PRESSURE_UP_SLOT) {
            event.setCancelled(true);
            if (!machine.type().usesPressure()) return;
            engineeringMenu.sync(top, holder);
            machines.adjustTargetPressure(machine, raw == EngineeringMachineMenu.PRESSURE_DOWN_SLOT ? -0.5 : 0.5);
            nextTick(() -> engineeringMenu.open(player, machine));
            return;
        }
        if (raw == EngineeringMachineMenu.STATUS_SLOT) {
            event.setCancelled(true);
            engineeringMenu.sync(top, holder);
            if (machines.processCandidates(machine).size() > 1) {
                machines.cycleProcess(machine, event.isRightClick() ? -1 : 1);
                nextTick(() -> engineeringMenu.open(player, machine));
            }
            return;
        }
        if (raw == EngineeringMachineMenu.DIAGNOSTICS_SLOT) {
            event.setCancelled(true);
            engineeringMenu.sync(top, holder);
            nextTick(() -> diagnosticsMenu.open(player, machine));
            return;
        }
        if (raw == EngineeringMachineMenu.CLOSE_SLOT) {
            event.setCancelled(true);
            nextTick(player::closeInventory);
            return;
        }

        boolean editable = raw == EngineeringMachineMenu.INPUT_SLOT
            || raw == EngineeringMachineMenu.SECONDARY_INPUT_SLOT
            || raw == EngineeringMachineMenu.CATALYST_SLOT
            || raw == EngineeringMachineMenu.FUEL_SLOT
            || raw == EngineeringMachineMenu.OUTPUT_SLOT
            || raw == EngineeringMachineMenu.BYPRODUCT_SLOT
            || EngineeringMachineMenu.UPGRADE_SLOTS.contains(raw);
        if (!editable) {
            event.setCancelled(true);
            return;
        }

        engineeringMenu.sync(top, holder);

        if (raw == EngineeringMachineMenu.SECONDARY_INPUT_SLOT && !machines.supportsSecondaryInput(machine.type())) {
            event.setCancelled(true);
            return;
        }
        if (raw == EngineeringMachineMenu.CATALYST_SLOT && !machines.supportsCatalyst(machine.type())) {
            event.setCancelled(true);
            return;
        }

        ItemStack candidate = candidate(event);
        if (raw == EngineeringMachineMenu.OUTPUT_SLOT || raw == EngineeringMachineMenu.BYPRODUCT_SLOT) {
            if (candidate != null && !candidate.getType().isAir()) {
                event.setCancelled(true);
                return;
            }
            CustomItem recovered = items.identify(event.getCurrentItem());
            if (recovered != null) {
                discoveries.discover(player, recovered);
                if (raw == EngineeringMachineMenu.OUTPUT_SLOT) onEngineeringOutputRecovered(player, machine, recovered);
            }
            return;
        }
        if (candidate == null || candidate.getType().isAir()) return;

        if (raw == EngineeringMachineMenu.INPUT_SLOT) {
            if (!machines.isValidInput(machine.type(), candidate)) {
                event.setCancelled(true);
                player.sendActionBar(Text.bad("That material has no registered primary-feed process in this machine."));
            }
            return;
        }
        if (raw == EngineeringMachineMenu.SECONDARY_INPUT_SLOT) {
            if (!machines.isValidSecondaryInput(machine, candidate)) {
                event.setCancelled(true);
                player.sendActionBar(Text.bad("That material is not a secondary feed for the current primary process family."));
            }
            return;
        }
        if (raw == EngineeringMachineMenu.CATALYST_SLOT) {
            if (!machines.isValidCatalyst(machine.type(), candidate)) {
                event.setCancelled(true);
                player.sendActionBar(Text.bad("That item is not a registered catalyst for this machine."));
            }
            return;
        }
        if (raw == EngineeringMachineMenu.FUEL_SLOT) {
            if (!isFuel(candidate)) {
                event.setCancelled(true);
                player.sendActionBar(Text.bad("Engineering machines accept vanilla redstone or redstone blocks as local flux fuel."));
            }
            return;
        }
        if (EngineeringMachineMenu.UPGRADE_SLOTS.contains(raw)) {
            UpgradeType type = UpgradeType.fromItem(items.identify(candidate));
            if (type == null || (candidate.getAmount() != 1 && !event.isRightClick())) {
                event.setCancelled(true);
                player.sendActionBar(Text.bad("Insert exactly one VoidCore upgrade module per socket."));
                return;
            }
            if (duplicateUpgrade(top, raw, type)) {
                event.setCancelled(true);
                player.sendActionBar(Text.bad("Duplicate upgrade modules do not stack in the same machine."));
            }
        }
    }

    private void handleNetworkClick(InventoryClickEvent event, MachineMenuHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        MachineInstance block = machines.get(holder.machineLocation());
        if (block == null || !block.type().isNetworkBlock()) {
            nextTick(player::closeInventory);
            return;
        }
        if (event.getRawSlot() == NetworkDiagnosticsMenu.CLOSE_SLOT) {
            nextTick(player::closeInventory);
            return;
        }
        if (event.getRawSlot() == NetworkDiagnosticsMenu.TRACE_SLOT) {
            networks.trace(player, block.location());
            return;
        }
        if (event.getRawSlot() == NetworkDiagnosticsMenu.FREQ_DOWN_SLOT || event.getRawSlot() == NetworkDiagnosticsMenu.FREQ_UP_SLOT) {
            int step = event.isShiftClick() ? 10 : 1;
            networks.setFrequencyComponent(block.location(), event.getRawSlot() == NetworkDiagnosticsMenu.FREQ_DOWN_SLOT ? -step : step);
            nextTick(() -> networkMenu.open(player, block));
        }
    }

    private void handleLogisticsClick(InventoryClickEvent event, Inventory top, MachineMenuHolder holder) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        MachineInstance node = machines.get(holder.machineLocation());
        if (node == null || !node.type().isConfigurableLogisticsNode()) { event.setCancelled(true); nextTick(player::closeInventory); return; }
        int raw = event.getRawSlot();
        if (raw < 0) return;
        if (raw >= top.getSize()) { if (event.isShiftClick()) event.setCancelled(true); return; }

        if (raw == LogisticsNodeMenu.BUFFER_SLOT && node.type() == MachineType.PRIORITY_BUFFER) {
            logisticsMenu.sync(top, holder);
            return;
        }
        event.setCancelled(true);
        if (raw == LogisticsNodeMenu.CLOSE_SLOT) { nextTick(player::closeInventory); return; }
        if (raw == LogisticsNodeMenu.DIAGNOSTICS_SLOT) {
            logisticsMenu.sync(top, holder);
            nextTick(() -> networkMenu.open(player, node));
            return;
        }
        if (raw == LogisticsNodeMenu.FILTER_SLOT) {
            if (event.isRightClick()) machines.setRoutingFilter(node, null);
            else {
                CustomItem filter = items.identify(event.getCursor());
                if (filter == null) player.sendActionBar(Text.bad("Hold a VoidCore material/component on the cursor, or right-click to clear."));
                else machines.setRoutingFilter(node, filter);
            }
            nextTick(() -> logisticsMenu.open(player, node));
            return;
        }
        if (raw == LogisticsNodeMenu.PRIORITY_DOWN_SLOT || raw == LogisticsNodeMenu.PRIORITY_UP_SLOT) {
            machines.adjustRoutingPriority(node, raw == LogisticsNodeMenu.PRIORITY_DOWN_SLOT ? -1 : 1);
            nextTick(() -> logisticsMenu.open(player, node));
            return;
        }
        if (raw == LogisticsNodeMenu.FREQ_DOWN_SLOT || raw == LogisticsNodeMenu.FREQ_UP_SLOT) {
            int step = event.isShiftClick() ? 10 : 1;
            networks.setFrequencyComponent(node.location(), raw == LogisticsNodeMenu.FREQ_DOWN_SLOT ? -step : step);
            nextTick(() -> logisticsMenu.open(player, node));
            return;
        }
        if (node.type() == MachineType.FREQUENCY_SPLITTER
            && (raw == LogisticsNodeMenu.SECONDARY_DOWN_SLOT || raw == LogisticsNodeMenu.SECONDARY_UP_SLOT)) {
            int step = event.isShiftClick() ? 10 : 1;
            machines.adjustSecondaryFrequency(node, raw == LogisticsNodeMenu.SECONDARY_DOWN_SLOT ? -step : step);
            nextTick(() -> logisticsMenu.open(player, node));
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof MachineMenuHolder holder)) return;

        if (holder.menuId().startsWith(EngineeringMachineMenu.MENU_PREFIX)) {
            if (event.getRawSlots().stream().anyMatch(slot -> slot < top.getSize())) event.setCancelled(true);
            return;
        }
        if (holder.menuId().equals(LogisticsNodeMenu.MENU_ID) || holder.menuId().equals(ObserverMenu.MENU_ID)
            || holder.menuId().equals(ControlMatrixMenu.MENU_ID) || holder.menuId().equals(FieldStabilizerMenu.MENU_ID)
            || holder.menuId().equals(AutomationConfigMenu.MENU_ID) || holder.menuId().equals(AutomationTerminalMenu.MENU_ID) || holder.menuId().equals(CoreChamberMenu.MENU_ID)
            || holder.menuId().equals(ProjectTerminalMenu.MENU_ID)) {
            if (event.getRawSlots().stream().anyMatch(slot -> slot < top.getSize())) event.setCancelled(true);
            return;
        }
        if (!holder.menuId().equals(MachineMenu.MENU_ID)) return;

        for (int raw : event.getRawSlots()) {
            if (raw >= top.getSize()) continue;
            if (!CRUCIBLE_EDITABLE.contains(raw) || raw == MachineMenu.OUTPUT_SLOT) {
                event.setCancelled(true);
                return;
            }
            ItemStack item = event.getOldCursor();
            if (raw == MachineMenu.INPUT_SLOT && !items.is(item, CustomItem.RESONANT_FRAGMENT)) {
                event.setCancelled(true);
                return;
            }
            if (raw == MachineMenu.FUEL_SLOT && !isFuel(item)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof MachineMenuHolder holder)) return;
        if (holder.menuId().equals(MachineMenu.MENU_ID)) crucibleMenu.sync(top, holder);
        else if (holder.menuId().startsWith(EngineeringMachineMenu.MENU_PREFIX)) engineeringMenu.sync(top, holder);
        else if (holder.menuId().equals(LogisticsNodeMenu.MENU_ID)) logisticsMenu.sync(top, holder);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHopper(InventoryMoveItemEvent event) {
        if (belongsToMachine(event.getSource()) || belongsToMachine(event.getDestination())) event.setCancelled(true);
    }

    private ItemStack candidate(InventoryClickEvent event) {
        ItemStack candidate = event.getCursor();
        if (event.getHotbarButton() >= 0 && event.getWhoClicked() instanceof Player player) {
            candidate = player.getInventory().getItem(event.getHotbarButton());
        }
        return candidate;
    }

    private boolean duplicateUpgrade(Inventory top, int targetSlot, UpgradeType candidate) {
        for (int slot : EngineeringMachineMenu.UPGRADE_SLOTS) {
            if (slot == targetSlot) continue;
            if (UpgradeType.fromItem(items.identify(top.getItem(slot))) == candidate) return true;
        }
        return false;
    }

    private boolean isFuel(ItemStack item) {
        return item != null && (item.getType() == Material.REDSTONE || item.getType() == Material.REDSTONE_BLOCK)
            && items.identify(item) == null;
    }

    private void onEngineeringOutputRecovered(Player player, MachineInstance machine, CustomItem output) {
        discoveries.discover(player, output);
        ProcessRecipe completed = machines.completedProcess(machine);
        if (completed != null && completed.output() == output) {
            if (completed.completionExperiment() != null) experiments.advance(player, completed.completionExperiment());
            machines.acknowledgeCompletedProcess(machine);
        }
    }

    private boolean belongsToMachine(Inventory inventory) {
        if (!(inventory.getHolder() instanceof BlockState state)) return false;
        return machines.isMachine(state.getLocation());
    }

    private void destroyMachinesInExplosion(java.util.List<Block> blocks) {
        java.util.Iterator<Block> iterator = blocks.iterator();
        while (iterator.hasNext()) {
            Block block = iterator.next();
            if (!machines.isMachine(block.getLocation())) continue;
            iterator.remove();
            org.bukkit.Location location = block.getLocation();
            closeViewersAt(location);
            MachineInstance machine = machines.unregister(location);
            if (machine != null) dropStoredContents(machine);
            block.setType(Material.AIR, false);
        }
    }

    private void closeViewersAt(org.bukkit.Location location) {
        crucibleMenu.closeViewersAt(location);
        engineeringMenu.closeViewersAt(location);
        diagnosticsMenu.closeViewersAt(location);
        exchangerMenu.closeViewersAt(location);
        networkMenu.closeViewersAt(location);
        logisticsMenu.closeViewersAt(location);
        observerMenu.closeViewersAt(location);
        controlMatrixMenu.closeViewersAt(location);
        fieldStabilizerMenu.closeViewersAt(location);
        automationConfigMenu.closeViewersAt(location);
        automationTerminalMenu.closeViewersAt(location);
        coreChamberMenu.closeViewersAt(location);
        projectTerminalMenu.closeViewersAt(location);
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void dropStoredContents(MachineInstance machine) {
        drop(machine, machine.input());
        drop(machine, machine.secondaryInput());
        drop(machine, machine.catalyst());
        drop(machine, machine.fuel());
        drop(machine, machine.output());
        drop(machine, machine.byproduct());
        for (int i = 0; i < machine.type().upgradeSlots(); i++) drop(machine, machine.upgrade(i));
    }

    private void drop(MachineInstance machine, ItemStack stack) {
        if (stack == null || stack.getType().isAir() || machine.location().getWorld() == null) return;
        machine.location().getWorld().dropItemNaturally(machine.location(), stack);
    }

    private void nextTick(Runnable action) {
        plugin.getServer().getScheduler().runTask(plugin, action);
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
