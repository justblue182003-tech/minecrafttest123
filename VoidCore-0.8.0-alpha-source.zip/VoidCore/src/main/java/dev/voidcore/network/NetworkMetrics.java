package dev.voidcore.network;

import dev.voidcore.machine.MachineType;

import java.util.List;

public record NetworkMetrics(
    String id,
    int frequency,
    List<Integer> frequencies,
    int busCount,
    int addressNodes,
    int routers,
    int buffers,
    int splitters,
    int controlMatrices,
    int automationTerminals,
    int dimensionalAnchors,
    int projectTerminals,
    int endpointCount,
    String activeControlDirective,
    int controlledEndpoints,
    int highSignalChannels,
    int gatedEndpoints,
    boolean crossDimensional,
    long lifetimeCycles,
    long lifetimeItemsProduced,
    long lifetimeFluxConsumed,
    double lifetimeEntropyProcessed,
    long lifetimeIncidents,
    int fluxSent,
    int fluxDelivered,
    int fluxLost,
    int itemMoves,
    int priorityMoves,
    int bridgedTransfers,
    int dimensionalTransfers,
    double entropyMoved,
    double entropyLost,
    int computationMoved,
    int starvedEndpoints,
    int entropyStressedEndpoints,
    int computationStarvedEndpoints,
    int blockedOutputs,
    int longestTransferHops,
    int pathCacheHits,
    int pathCacheMisses,
    boolean topologyReused,
    int topologyCacheAge,
    NetworkHistory.Summary history,
    List<BlockKey> lastRoute,
    List<EndpointStatus> endpoints
) {
    public double lossPercent() { return fluxSent <= 0 ? 0.0 : (fluxLost * 100.0 / fluxSent); }
    public boolean mixedFrequency() { return frequencies.size() > 1; }

    public record EndpointStatus(
        String address,
        MachineType type,
        int flux,
        int capacity,
        double entropy,
        double entropyCapacity,
        int computation,
        int computationCapacity,
        double wear,
        String fault,
        boolean phaseInterface,
        int routingPriority,
        String routingFilter,
        int automationGroup,
        int signalChannel,
        String signalGate,
        boolean signalHigh
    ) { }
}
