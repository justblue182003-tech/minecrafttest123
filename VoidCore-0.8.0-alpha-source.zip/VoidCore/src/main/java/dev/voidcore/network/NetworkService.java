package dev.voidcore.network;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.UpgradeType;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.machine.ControlDirective;
import dev.voidcore.machine.AutomationRule;
import dev.voidcore.process.ProcessRecipe;
import dev.voidcore.simulation.EngineeringMath;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;

public final class NetworkService {
    private static final int[][] OFFSETS = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};

    private final VoidCorePlugin plugin;
    private final MachineService machines;
    private final Map<BlockKey, NetworkMetrics> metricsByBlock = new HashMap<>();
    private final Map<String, TopologyCacheEntry> topologyCache = new HashMap<>();
    private final Map<String, NetworkHistory> historyByNetwork = new HashMap<>();
    private long graphPass;

    public NetworkService(VoidCorePlugin plugin, MachineService machines) {
        this.plugin = plugin;
        this.machines = machines;
    }

    public void tick() {
        graphPass++;
        metricsByBlock.clear();
        machines.resetActiveDirectives();
        machines.resetSignals();
        Map<BlockKey, MachineInstance> networkBlocks = loadedNetworkBlocks();
        Set<BlockKey> visited = new HashSet<>();
        Set<String> seenNetworks = new HashSet<>();
        for (BlockKey start : networkBlocks.keySet()) {
            if (visited.contains(start)) continue;
            Set<BlockKey> component = component(start, networkBlocks, visited);
            if (component.isEmpty()) continue;
            NetworkMetrics metrics = runNetwork(component, networkBlocks);
            seenNetworks.add(metrics.id());
            for (BlockKey key : component) metricsByBlock.put(key, metrics);
        }
        topologyCache.entrySet().removeIf(entry -> !seenNetworks.contains(entry.getKey()) && graphPass - entry.getValue().lastSeenPass > 30);
        historyByNetwork.keySet().removeIf(id -> !seenNetworks.contains(id) && !topologyCache.containsKey(id));
    }

    public NetworkMetrics metricsAt(Location location) {
        if (location == null || location.getWorld() == null) return null;
        return metricsByBlock.get(BlockKey.of(location));
    }

    public void setFrequencyComponent(Location start, int delta) {
        MachineInstance origin = machines.get(start);
        if (origin == null || !origin.type().isNetworkBlock()) return;
        int old = origin.networkFrequency();
        int target = Math.max(1, Math.min(999, old + delta));
        Set<BlockKey> visited = new HashSet<>();
        Queue<MachineInstance> queue = new ArrayDeque<>();
        queue.add(origin);
        while (!queue.isEmpty()) {
            MachineInstance current = queue.remove();
            BlockKey key = BlockKey.of(current.location());
            if (!visited.add(key) || current.networkFrequency() != old) continue;
            current.networkFrequency(target);
            machines.markDirty();
            for (MachineInstance adjacent : machines.adjacentMachines(current.location())) {
                if (!adjacent.type().isNetworkBlock()) continue;
                if (adjacent.networkFrequency() == old && !visited.contains(BlockKey.of(adjacent.location()))) queue.add(adjacent);
            }
        }
    }

    public void trace(Player player, Location accessPoint) {
        NetworkMetrics metrics = metricsAt(accessPoint);
        if (metrics == null || metrics.lastRoute().isEmpty()) return;
        for (BlockKey key : metrics.lastRoute()) {
            World world = Bukkit.getWorld(key.world());
            if (world == null || !world.equals(player.getWorld())) continue;
            player.spawnParticle(Particle.END_ROD, key.x() + 0.5, key.y() + 0.5, key.z() + 0.5,
                3, 0.08, 0.08, 0.08, 0.0);
        }
    }

    private Map<BlockKey, MachineInstance> loadedNetworkBlocks() {
        Map<BlockKey, MachineInstance> result = new HashMap<>();
        for (MachineInstance machine : machines.all()) {
            if (!machine.type().isNetworkBlock()) continue;
            if (machine.location().getWorld() == null || !machine.location().isChunkLoaded()) continue;
            if (machine.location().getBlock().getType() != machine.type().item().material()) continue;
            result.put(BlockKey.of(machine.location()), machine);
        }
        return result;
    }

    private Set<BlockKey> component(BlockKey start, Map<BlockKey, MachineInstance> blocks, Set<BlockKey> globalVisited) {
        Set<BlockKey> result = new LinkedHashSet<>();
        Queue<BlockKey> queue = new ArrayDeque<>();
        queue.add(start);
        while (!queue.isEmpty()) {
            BlockKey key = queue.remove();
            if (result.contains(key)) continue;
            MachineInstance current = blocks.get(key);
            if (current == null) continue;
            result.add(key);
            globalVisited.add(key);
            for (int[] d : OFFSETS) {
                BlockKey next = key.offset(d[0], d[1], d[2]);
                MachineInstance adjacent = blocks.get(next);
                if (adjacent != null && !result.contains(next) && canLink(current, adjacent)) queue.add(next);
            }
            if (current.type() == MachineType.DIMENSIONAL_ANCHOR) {
                for (Map.Entry<BlockKey, MachineInstance> entry : blocks.entrySet()) {
                    if (result.contains(entry.getKey()) || entry.getValue() == current) continue;
                    if (dimensionalLinkActive(current, entry.getValue())) queue.add(entry.getKey());
                }
            }
        }
        return result;
    }

    private boolean canLink(MachineInstance a, MachineInstance b) {
        for (int af : frequencies(a)) for (int bf : frequencies(b)) if (af == bf) return true;
        return false;
    }

    private boolean dimensionalLinkActive(MachineInstance a, MachineInstance b) {
        if (a == null || b == null || a.type() != MachineType.DIMENSIONAL_ANCHOR || b.type() != MachineType.DIMENSIONAL_ANCHOR) return false;
        if (a.location().getWorld() == null || b.location().getWorld() == null) return false;
        if (a.location().getWorld().getUID().equals(b.location().getWorld().getUID())) return false;
        if (a.networkFrequency() != b.networkFrequency()) return false;
        int sustain = Math.max(1, plugin.getConfig().getInt("network.dimensional-anchor-computation-per-second", 12));
        return !a.maintenanceLocked() && !b.maintenanceLocked() && a.computation() >= sustain * 2 && b.computation() >= sustain * 2;
    }

    private Set<Integer> frequencies(MachineInstance machine) {
        Set<Integer> result = new LinkedHashSet<>();
        result.add(machine.networkFrequency());
        if (machine.type() == MachineType.FREQUENCY_SPLITTER) result.add(machine.secondaryNetworkFrequency());
        return result;
    }

    private NetworkMetrics runNetwork(Set<BlockKey> component, Map<BlockKey, MachineInstance> blocks) {
        Set<Integer> frequencySet = new TreeSet<>();
        Set<MachineInstance> endpointSet = new LinkedHashSet<>();
        Map<MachineInstance, BlockKey> attachment = new HashMap<>();
        int busCount = 0, addressNodes = 0, routers = 0, buffers = 0, splitters = 0, controlMatrices = 0;
        int automationTerminals = 0, dimensionalAnchors = 0, projectTerminals = 0;
        List<MachineInstance> controllers = new ArrayList<>();
        List<MachineInstance> terminals = new ArrayList<>();
        List<MachineInstance> anchors = new ArrayList<>();

        for (BlockKey key : component) {
            MachineInstance block = blocks.get(key);
            frequencySet.addAll(frequencies(block));
            switch (block.type()) {
                case FLUX_BUS -> busCount++;
                case ADDRESS_NODE -> addressNodes++;
                case PHASE_ROUTER -> routers++;
                case PRIORITY_BUFFER -> {
                    buffers++;
                    endpointSet.add(block);
                    attachment.put(block, key);
                }
                case FREQUENCY_SPLITTER -> splitters++;
                case CONTROL_MATRIX -> {
                    controlMatrices++;
                    controllers.add(block);
                    endpointSet.add(block);
                    attachment.put(block, key);
                }
                case AUTOMATION_TERMINAL -> {
                    automationTerminals++;
                    terminals.add(block);
                    endpointSet.add(block);
                    attachment.put(block, key);
                }
                case DIMENSIONAL_ANCHOR -> {
                    dimensionalAnchors++;
                    anchors.add(block);
                    endpointSet.add(block);
                    attachment.put(block, key);
                }
                case PROJECT_TERMINAL -> {
                    projectTerminals++;
                    endpointSet.add(block);
                    attachment.put(block, key);
                }
                default -> { }
            }
            for (MachineInstance adjacent : machines.adjacentMachines(block.location())) {
                if (!adjacent.type().canConnectToFluxBus()) continue;
                endpointSet.add(adjacent);
                BlockKey existing = attachment.get(adjacent);
                if (existing == null || compareBlockKeys(key, existing) < 0) attachment.put(adjacent, key);
            }
        }

        List<MachineInstance> endpoints = new ArrayList<>(endpointSet);
        endpoints.sort(Comparator.comparing(machines::networkAddress));
        String id = networkId(component, frequencySet);
        int signature = topologySignature(component, blocks);
        TopologyCacheEntry topology = topologyCache.get(id);
        boolean topologyReused = topology != null && topology.signature == signature;
        if (!topologyReused) {
            topology = new TopologyCacheEntry(signature, new HashMap<>(), 0, graphPass);
            topologyCache.put(id, topology);
        } else {
            topology.age++;
            topology.lastSeenPass = graphPass;
        }

        PathCache paths = new PathCache(component, blocks, topology.paths);
        TransferStats stats = new TransferStats();
        balanceFlux(attachment, endpoints, busCount, paths, stats);
        balanceEntropy(attachment, endpoints, busCount, paths, stats);
        balanceComputation(attachment, endpoints, busCount, paths, stats);
        ControlState control = applyControlPolicy(controllers, endpoints);
        SignalState signals = applyAutomationSignals(terminals, endpoints);
        routeItems(blocks, attachment, endpoints, busCount, paths, stats);
        consumeDimensionalAnchorSustain(anchors);

        List<NetworkMetrics.EndpointStatus> statuses = endpoints.stream().map(machine -> {
            RoutePolicy policy = policyFor(machine, component, blocks);
            return new NetworkMetrics.EndpointStatus(
                machines.networkAddress(machine), machine.type(), machine.flux(), machines.maxFlux(machine.type()),
                machine.entropy(), machines.entropyCapacity(machine.type()), machine.computation(), machines.computationCapacity(machine.type()),
                machine.wear(), machine.fault().displayName(),
                machines.hasUpgrade(machine, UpgradeType.PHASE_INTERFACE) || machine.type().isRoutingBuffer(),
                policy.priority, policy.filterId == null ? "Any" : readableFilter(policy.filterId),
                machine.automationGroup(), machine.signalChannel(), machine.signalGate().displayName(), machine.signalHigh());
        }).toList();

        int starved = (int) endpoints.stream().filter(machine -> machines.maxFlux(machine.type()) > 0
            && machine.flux() < machines.maxFlux(machine.type()) * 0.15).count();
        int entropyStressed = (int) endpoints.stream().filter(machine -> machines.entropyCapacity(machine.type()) > 0.0
            && machine.entropy() >= machines.entropyCapacity(machine.type()) * 0.70).count();
        int computationStarved = (int) endpoints.stream().filter(this::computationStarved).count();

        int historySamples = Math.max(10, plugin.getConfig().getInt("network.history-samples", 60));
        NetworkHistory history = historyByNetwork.computeIfAbsent(id, ignored -> new NetworkHistory(historySamples));
        history.add(new NetworkHistory.Sample(stats.fluxDelivered, stats.fluxLost, stats.itemMoves, stats.entropyMoved,
            stats.computationMoved, starved, stats.blockedOutputs, entropyStressed, computationStarved));

        List<Integer> frequencies = List.copyOf(frequencySet);
        int primaryFrequency = frequencies.size() == 1 ? frequencies.getFirst() : 0;
        long lifetimeCycles = endpoints.stream().mapToLong(MachineInstance::lifetimeCycles).sum();
        long lifetimeItems = endpoints.stream().mapToLong(MachineInstance::lifetimeItemsProduced).sum();
        long lifetimeFlux = endpoints.stream().mapToLong(MachineInstance::lifetimeFluxConsumed).sum();
        double lifetimeEntropy = endpoints.stream().mapToDouble(MachineInstance::lifetimeEntropyProcessed).sum();
        long lifetimeIncidents = endpoints.stream().mapToLong(MachineInstance::incidentCount).sum();
        boolean crossDimensional = paths.component.stream().map(BlockKey::world).distinct().count() > 1;
        return new NetworkMetrics(id, primaryFrequency, frequencies, busCount, addressNodes,
            routers, buffers, splitters, controlMatrices, automationTerminals, dimensionalAnchors, projectTerminals,
            endpoints.size(), control.directive.displayName(), control.controlledEndpoints,
            signals.highChannels(), signals.gatedEndpoints(), crossDimensional,
            lifetimeCycles, lifetimeItems, lifetimeFlux, lifetimeEntropy, lifetimeIncidents,
            stats.fluxSent, stats.fluxDelivered, stats.fluxLost,
            stats.itemMoves, stats.priorityMoves, stats.bridgedTransfers, stats.dimensionalTransfers, stats.entropyMoved, stats.entropyLost,
            stats.computationMoved, starved, entropyStressed, computationStarved, stats.blockedOutputs, stats.longestHops,
            paths.hits, paths.misses, topologyReused, topology.age, history.summary(), List.copyOf(stats.lastRoute), statuses);
    }

    private boolean computationStarved(MachineInstance machine) {
        if (machine.type() == MachineType.CONTROL_MATRIX) {
            int cost = Math.max(1, plugin.getConfig().getInt("network.control-computation-per-second", 8));
            return machine.controlDirective() != ControlDirective.BALANCED && machine.computation() < cost;
        }
        if (machine.type() == MachineType.AUTOMATION_TERMINAL) {
            int cost = Math.max(1, plugin.getConfig().getInt("network.automation-computation-per-second", 5));
            return machine.automationRule() != AutomationRule.ALWAYS && machine.computation() < cost;
        }
        if (machine.type() == MachineType.DIMENSIONAL_ANCHOR) {
            int cost = Math.max(1, plugin.getConfig().getInt("network.dimensional-anchor-computation-per-second", 12));
            return machine.computation() < cost * 2;
        }
        ProcessRecipe recipe = machines.currentRecipe(machine);
        return recipe != null && recipe.computationCost() > 0 && machine.computation() < recipe.computationCost();
    }

    private void balanceFlux(Map<MachineInstance, BlockKey> attachment, List<MachineInstance> endpoints,
                             int busCount, PathCache paths, TransferStats stats) {
        List<MachineInstance> donors = endpoints.stream()
            .filter(machine -> machines.maxFlux(machine.type()) > 0)
            .filter(machine -> machine.flux() > machines.maxFlux(machine.type()) * 0.55)
            .sorted(Comparator.comparingInt(MachineInstance::flux).reversed()).toList();
        List<MachineInstance> receivers = endpoints.stream()
            .filter(machine -> machines.maxFlux(machine.type()) > 0)
            .filter(machine -> machine.flux() < machines.maxFlux(machine.type()) * 0.45)
            .sorted(Comparator.comparingInt(MachineInstance::flux)).toList();

        int budget = Math.max(0, busCount * Math.max(1, plugin.getConfig().getInt("network.flux-throughput-per-bus", 160)));
        for (MachineInstance receiver : receivers) {
            if (budget <= 0) break;
            int desired = Math.max(0, (int) Math.round(machines.maxFlux(receiver.type()) * 0.65) - receiver.flux());
            for (MachineInstance donor : donors) {
                if (donor == receiver || desired <= 0 || budget <= 0) break;
                int reserve = (int) Math.round(machines.maxFlux(donor.type()) * 0.30);
                int available = Math.max(0, donor.flux() - reserve);
                if (available <= 0) continue;
                List<BlockKey> path = paths.path(attachment.get(donor), attachment.get(receiver));
                if (path.isEmpty()) continue;
                int hops = Math.max(0, path.size() - 1);
                double loss = EngineeringMath.networkLossRate(plugin.getConfig().getDouble("network.base-flux-loss", 0.02),
                    plugin.getConfig().getDouble("network.flux-loss-per-hop", 0.008), hops);
                if (paths.crossesDimension(path)) loss = Math.min(0.45, loss + plugin.getConfig().getDouble("network.dimensional-extra-flux-loss", 0.08));
                int sent = Math.min(Math.min(available, budget), EngineeringMath.requiredSentFlux(desired, loss));
                int delivered = EngineeringMath.deliveredFlux(sent, loss);
                if (delivered <= 0) continue;
                donor.flux(donor.flux() - sent);
                int accepted = machines.addFlux(receiver, delivered);
                if (accepted <= 0) { donor.flux(donor.flux() + sent); continue; }
                stats.fluxSent += sent;
                stats.fluxDelivered += accepted;
                stats.fluxLost += Math.max(0, sent - accepted);
                stats.longestHops = Math.max(stats.longestHops, hops);
                stats.lastRoute = path;
                if (paths.crossesSplitter(path)) stats.bridgedTransfers++;
                if (paths.crossesDimension(path)) stats.dimensionalTransfers++;
                budget -= sent;
                desired -= accepted;
                machines.markDirty();
            }
        }
    }

    private void balanceEntropy(Map<MachineInstance, BlockKey> attachment, List<MachineInstance> endpoints,
                                int busCount, PathCache paths, TransferStats stats) {
        double budget = Math.max(0.0, busCount * plugin.getConfig().getDouble("network.entropy-throughput-per-bus", 12.0));
        if (budget <= 0.0) return;
        List<MachineInstance> receivers = endpoints.stream()
            .filter(machine -> entropyTarget(machine) > 0.0)
            .filter(machine -> machine.entropy() + 0.001 < entropyTarget(machine))
            .sorted(Comparator.comparingDouble(MachineInstance::entropy)).toList();
        List<MachineInstance> donors = endpoints.stream()
            .filter(machine -> machine.type() != MachineType.ENTROPY_CONDENSER)
            .filter(machine -> machines.entropyCapacity(machine.type()) > 0.0)
            .filter(machine -> machine.entropy() > machines.entropyCapacity(machine.type()) * 0.25)
            .sorted(Comparator.comparingDouble(MachineInstance::entropy).reversed()).toList();

        for (MachineInstance receiver : receivers) {
            if (budget <= 0.0001) break;
            double desired = Math.max(0.0, entropyTarget(receiver) - receiver.entropy());
            for (MachineInstance donor : donors) {
                if (donor == receiver) continue;
                if (desired <= 0.0001 || budget <= 0.0001) break;
                double reserve = machines.entropyCapacity(donor.type()) * 0.20;
                double available = Math.max(0.0, donor.entropy() - reserve);
                if (available <= 0.0001) continue;
                List<BlockKey> path = paths.path(attachment.get(donor), attachment.get(receiver));
                if (path.isEmpty()) continue;
                int hops = Math.max(0, path.size() - 1);
                double loss = Math.min(0.35, plugin.getConfig().getDouble("network.base-entropy-loss", 0.015)
                    + plugin.getConfig().getDouble("network.entropy-loss-per-hop", 0.004) * hops
                    + (paths.crossesDimension(path) ? plugin.getConfig().getDouble("network.dimensional-extra-entropy-loss", 0.04) : 0.0));
                double sent = Math.min(Math.min(available, budget), desired / Math.max(0.01, 1.0 - loss));
                if (sent <= 0.0001) continue;
                double taken = machines.takeEntropy(donor, sent);
                double delivered = taken * (1.0 - loss);
                double accepted = machines.addEntropy(receiver, delivered);
                if (accepted <= 0.0001) {
                    machines.addEntropy(donor, taken);
                    continue;
                }
                stats.entropyMoved += accepted;
                stats.entropyLost += Math.max(0.0, taken - accepted);
                stats.longestHops = Math.max(stats.longestHops, hops);
                stats.lastRoute = path;
                if (paths.crossesSplitter(path)) stats.bridgedTransfers++;
                if (paths.crossesDimension(path)) stats.dimensionalTransfers++;
                budget -= taken;
                desired -= accepted;
            }
        }
    }


    private double entropyTarget(MachineInstance machine) {
        double capacity = machines.entropyCapacity(machine.type());
        if (capacity <= 0.0) return 0.0;
        if (machine.type() == MachineType.ENTROPY_CONDENSER) return capacity * 0.80;
        ProcessRecipe recipe = machines.currentRecipe(machine);
        if (recipe == null || recipe.entropyCost() <= 0.0) return 0.0;
        // Active entropy-consuming processes request a working buffer, not a bulk 80% fill.
        return Math.min(capacity * 0.80, Math.max(capacity * 0.20, recipe.entropyCost() * 2.0));
    }

    private void balanceComputation(Map<MachineInstance, BlockKey> attachment, List<MachineInstance> endpoints,
                                    int busCount, PathCache paths, TransferStats stats) {
        int budget = Math.max(0, busCount * Math.max(1, plugin.getConfig().getInt("network.computation-throughput-per-bus", 60)));
        if (budget <= 0) return;
        List<MachineInstance> receivers = endpoints.stream()
            .filter(machine -> machine.type() != MachineType.PHASE_OBSERVER)
            .filter(machine -> machines.computationCapacity(machine.type()) > 0)
            .filter(machine -> machine.computation() < machines.computationCapacity(machine.type()) * 0.90)
            .sorted(Comparator.comparingInt(MachineInstance::computation)).toList();
        List<MachineInstance> donors = endpoints.stream()
            .filter(machine -> machine.type() == MachineType.PHASE_OBSERVER)
            .filter(machine -> machine.computation() > machines.computationCapacity(machine.type()) * 0.20)
            .sorted(Comparator.comparingInt(MachineInstance::computation).reversed()).toList();

        for (MachineInstance receiver : receivers) {
            if (budget <= 0) break;
            int desired = Math.max(0, (int) Math.round(machines.computationCapacity(receiver.type()) * 0.80) - receiver.computation());
            for (MachineInstance donor : donors) {
                if (desired <= 0 || budget <= 0) break;
                int reserve = (int) Math.round(machines.computationCapacity(donor.type()) * 0.15);
                int available = Math.max(0, donor.computation() - reserve);
                if (available <= 0) continue;
                List<BlockKey> path = paths.path(attachment.get(donor), attachment.get(receiver));
                if (path.isEmpty()) continue;
                int moved = Math.min(Math.min(available, budget), desired);
                int taken = machines.takeComputation(donor, moved);
                int accepted = machines.addComputation(receiver, taken);
                if (accepted <= 0) {
                    machines.addComputation(donor, taken);
                    continue;
                }
                if (accepted < taken) machines.addComputation(donor, taken - accepted);
                stats.computationMoved += accepted;
                stats.longestHops = Math.max(stats.longestHops, Math.max(0, path.size() - 1));
                stats.lastRoute = path;
                if (paths.crossesSplitter(path)) stats.bridgedTransfers++;
                if (paths.crossesDimension(path)) stats.dimensionalTransfers++;
                budget -= accepted;
                desired -= accepted;
            }
        }
    }

    private ControlState applyControlPolicy(List<MachineInstance> controllers, List<MachineInstance> endpoints) {
        if (controllers.isEmpty()) return new ControlState(ControlDirective.BALANCED, 0);
        controllers.sort(Comparator.comparingInt(MachineInstance::quality).reversed().thenComparing(machines::networkAddress));
        MachineInstance controller = controllers.getFirst();
        ControlDirective directive = controller.controlDirective();
        if (directive != ControlDirective.BALANCED) {
            int cost = Math.max(1, plugin.getConfig().getInt("network.control-computation-per-second", 8));
            if (controller.computation() < cost) directive = ControlDirective.BALANCED;
            else machines.takeComputation(controller, cost);
        }
        int controlled = 0;
        for (MachineInstance endpoint : endpoints) {
            if (endpoint == controller || endpoint.type() == MachineType.CONTROL_MATRIX) continue;
            machines.applyActiveDirective(endpoint, directive);
            controlled++;
        }
        return new ControlState(directive, controlled);
    }

    private void routeItems(Map<BlockKey, MachineInstance> blocks, Map<MachineInstance, BlockKey> attachment,
                            List<MachineInstance> endpoints, int busCount, PathCache paths, TransferStats stats) {
        int budget = Math.max(0, busCount) * Math.max(1, plugin.getConfig().getInt("network.item-bandwidth-per-bus", 2));
        if (budget <= 0) return;
        List<MachineInstance> routable = endpoints.stream().filter(machines::supportsAutomaticRouting).toList();

        for (MachineInstance producer : routable) {
            if (budget <= 0) break;
            ItemStack output = producer.output();
            if (output == null || output.getType().isAir()) continue;

            List<RouteCandidate> candidates = new ArrayList<>();
            for (MachineInstance consumer : routable) {
                if (consumer == producer) continue;
                if (producer.type().isRoutingBuffer() && consumer.type().isRoutingBuffer()) continue;
                List<BlockKey> path = paths.path(attachment.get(producer), attachment.get(consumer));
                if (path.isEmpty()) continue;
                RoutePolicy policy = policyFor(consumer, paths.component, blocks);
                if (!machines.routingFilterMatches(policy.filterId, output)) continue;
                int hops = Math.max(0, path.size() - 1);
                candidates.add(new RouteCandidate(consumer, path, policy, EngineeringMath.routingScore(policy.priority, hops)));
            }
            candidates.sort(Comparator.comparingInt(RouteCandidate::score).reversed()
                .thenComparing(c -> machines.networkAddress(c.consumer)));

            boolean routed = false;
            for (RouteCandidate candidate : candidates) {
                int amount = Math.min(Math.min(output.getAmount(), budget), 4);
                ItemStack moved = machines.takeRoutableOutput(producer, amount);
                if (moved == null) break;
                if (machines.acceptRoutedItem(candidate.consumer, moved)) {
                    machines.finalizeRoutedOutput(producer);
                    stats.itemMoves += moved.getAmount();
                    stats.longestHops = Math.max(stats.longestHops, Math.max(0, candidate.path.size() - 1));
                    stats.lastRoute = candidate.path;
                    if (candidate.policy.priority != 5 || candidate.policy.filterId != null) stats.priorityMoves += moved.getAmount();
                    if (paths.crossesSplitter(candidate.path)) stats.bridgedTransfers += moved.getAmount();
                    if (paths.crossesDimension(candidate.path)) stats.dimensionalTransfers += moved.getAmount();
                    budget -= moved.getAmount() * (paths.crossesDimension(candidate.path) ? 2 : 1);
                    routed = true;
                    break;
                }
                machines.returnRoutedOutput(producer, moved);
            }
            if (!routed) stats.blockedOutputs++;
        }
    }

    private RoutePolicy policyFor(MachineInstance endpoint, Set<BlockKey> component, Map<BlockKey, MachineInstance> blocks) {
        RoutePolicy selected = new RoutePolicy(endpoint.routingPriority(), endpoint.routingFilterId());
        if (endpoint.type().isRoutingBuffer()) return selected;
        for (MachineInstance adjacent : machines.adjacentMachines(endpoint.location())) {
            BlockKey key = BlockKey.of(adjacent.location());
            if (!component.contains(key) || adjacent.type() != MachineType.PHASE_ROUTER) continue;
            RoutePolicy candidate = new RoutePolicy(adjacent.routingPriority(), adjacent.routingFilterId());
            if (candidate.priority > selected.priority || (candidate.priority == selected.priority && candidate.filterId != null)) selected = candidate;
        }
        return selected;
    }

    private int topologySignature(Set<BlockKey> component, Map<BlockKey, MachineInstance> blocks) {
        List<BlockKey> ordered = new ArrayList<>(component);
        ordered.sort(this::compareBlockKeys);
        int hash = 1;
        for (BlockKey key : ordered) {
            MachineInstance machine = blocks.get(key);
            hash = 31 * hash + Objects.hash(key.world(), key.x(), key.y(), key.z(), machine.type(), machine.networkFrequency(),
                machine.type() == MachineType.FREQUENCY_SPLITTER ? machine.secondaryNetworkFrequency() : 0);
        }
        return hash;
    }

    private int compareBlockKeys(BlockKey a, BlockKey b) {
        int world = a.world().toString().compareTo(b.world().toString());
        if (world != 0) return world;
        int x = Integer.compare(a.x(), b.x());
        if (x != 0) return x;
        int y = Integer.compare(a.y(), b.y());
        if (y != 0) return y;
        return Integer.compare(a.z(), b.z());
    }

    private String readableFilter(String id) {
        CustomItem item = CustomItem.fromId(id);
        return item == null ? id : item.displayName();
    }

    private String networkId(Set<BlockKey> component, Set<Integer> frequencies) {
        BlockKey canonical = component.stream().min(Comparator
            .comparing((BlockKey key) -> key.world().toString()).thenComparingInt(BlockKey::x)
            .thenComparingInt(BlockKey::y).thenComparingInt(BlockKey::z)).orElseThrow();
        int hash = Objects.hash(canonical.world(), canonical.x(), canonical.y(), canonical.z(), frequencies);
        return "NET-" + String.format(Locale.ROOT, "%08X", hash);
    }

    private void consumeDimensionalAnchorSustain(List<MachineInstance> anchors) {
        int cost = Math.max(1, plugin.getConfig().getInt("network.dimensional-anchor-computation-per-second", 12));
        for (MachineInstance anchor : anchors) {
            boolean hasRemote = anchors.stream().anyMatch(other -> other != anchor && dimensionalLinkActive(anchor, other));
            if (hasRemote) machines.takeComputation(anchor, cost);
        }
    }

    private SignalState applyAutomationSignals(List<MachineInstance> terminals, List<MachineInstance> endpoints) {
        Set<SignalAddress> high = new HashSet<>();
        terminals.sort(Comparator.comparingInt(MachineInstance::quality).reversed().thenComparing(machines::networkAddress));
        for (MachineInstance terminal : terminals) {
            List<MachineInstance> group = endpoints.stream()
                .filter(machine -> machine != terminal && machine.automationGroup() == terminal.automationGroup())
                .toList();
            boolean powered;
            if (terminal.automationRule() == AutomationRule.ALWAYS) powered = true;
            else {
                int cost = Math.max(1, plugin.getConfig().getInt("network.automation-computation-per-second", 5));
                if (terminal.computation() < cost) powered = false;
                else {
                    machines.takeComputation(terminal, cost);
                    powered = evaluateAutomationRule(terminal.automationRule(), group);
                }
            }
            if (powered) high.add(new SignalAddress(terminal.automationGroup(), terminal.signalChannel()));
        }
        int gated = 0;
        for (MachineInstance endpoint : endpoints) {
            boolean signal = high.contains(new SignalAddress(endpoint.automationGroup(), endpoint.signalChannel()));
            machines.applySignal(endpoint, signal);
            if (endpoint.signalGate() != dev.voidcore.machine.SignalGate.IGNORE) gated++;
        }
        int highChannels = (int) high.stream().map(SignalAddress::channel).distinct().count();
        return new SignalState(highChannels, gated);
    }

    private boolean evaluateAutomationRule(AutomationRule rule, List<MachineInstance> group) {
        if (rule == AutomationRule.ALWAYS) return true;
        return switch (rule) {
            case ALWAYS -> true;
            case ENTROPY_HIGH -> group.stream().anyMatch(machine -> machines.entropyCapacity(machine.type()) > 0.0
                && machine.entropy() >= machines.entropyCapacity(machine.type()) * 0.70);
            case FLUX_LOW -> group.stream().anyMatch(machine -> machines.maxFlux(machine.type()) > 0
                && machine.flux() < machines.maxFlux(machine.type()) * 0.20);
            case OUTPUT_BLOCKED -> group.stream().anyMatch(machine -> {
                var state = machines.processState(machine);
                return state == dev.voidcore.process.ProcessEngine.TickState.OUTPUT_BLOCKED
                    || state == dev.voidcore.process.ProcessEngine.TickState.BYPRODUCT_BLOCKED;
            });
            case FIELD_UNSTABLE -> group.stream().anyMatch(machine -> machine.fieldStability() < 75.0);
            case WEAR_HIGH -> group.stream().anyMatch(machine -> machine.wear() >= 80.0);
            case FAULT_ACTIVE -> group.stream().anyMatch(MachineInstance::hasFault);
            case COMPUTATION_LOW -> group.stream().anyMatch(machine -> machines.computationCapacity(machine.type()) > 0
                && machine.computation() < machines.computationCapacity(machine.type()) * 0.20);
        };
    }

    private record ControlState(ControlDirective directive, int controlledEndpoints) { }
    private record SignalAddress(int group, int channel) { }
    private record SignalState(int highChannels, int gatedEndpoints) { }
    private record RoutePolicy(int priority, String filterId) { }
    private record RouteCandidate(MachineInstance consumer, List<BlockKey> path, RoutePolicy policy, int score) { }

    private static final class TransferStats {
        int fluxSent, fluxDelivered, fluxLost, itemMoves, priorityMoves, bridgedTransfers, dimensionalTransfers, computationMoved, blockedOutputs, longestHops;
        double entropyMoved, entropyLost;
        List<BlockKey> lastRoute = List.of();
    }

    private static final class TopologyCacheEntry {
        final int signature;
        final Map<String, List<BlockKey>> paths;
        int age;
        long lastSeenPass;

        TopologyCacheEntry(int signature, Map<String, List<BlockKey>> paths, int age, long lastSeenPass) {
            this.signature = signature;
            this.paths = paths;
            this.age = age;
            this.lastSeenPass = lastSeenPass;
        }
    }

    private final class PathCache {
        private final Set<BlockKey> component;
        private final Map<BlockKey, MachineInstance> blocks;
        private final Map<String, List<BlockKey>> cache;
        int hits, misses;

        PathCache(Set<BlockKey> component, Map<BlockKey, MachineInstance> blocks, Map<String, List<BlockKey>> cache) {
            this.component = component;
            this.blocks = blocks;
            this.cache = cache;
        }

        List<BlockKey> path(BlockKey start, BlockKey target) {
            if (start == null || target == null) return List.of();
            String key = start + ">" + target;
            List<BlockKey> cached = cache.get(key);
            if (cached != null) { hits++; return cached; }
            misses++;
            List<BlockKey> path = bfs(start, target);
            cache.put(key, path);
            return path;
        }

        boolean crossesSplitter(List<BlockKey> path) {
            return path.stream().map(blocks::get).anyMatch(machine -> machine != null && machine.type() == MachineType.FREQUENCY_SPLITTER);
        }

        boolean crossesDimension(List<BlockKey> path) {
            if (path == null || path.size() < 2) return false;
            for (int i = 1; i < path.size(); i++) if (!path.get(i - 1).world().equals(path.get(i).world())) return true;
            return false;
        }

        private List<BlockKey> bfs(BlockKey start, BlockKey target) {
            if (!component.contains(start) || !component.contains(target)) return List.of();
            if (start.equals(target)) return List.of(start);
            Queue<BlockKey> queue = new ArrayDeque<>();
            Map<BlockKey, BlockKey> previous = new HashMap<>();
            queue.add(start);
            previous.put(start, null);
            while (!queue.isEmpty()) {
                BlockKey current = queue.remove();
                MachineInstance currentMachine = blocks.get(current);
                for (int[] d : OFFSETS) {
                    BlockKey next = current.offset(d[0], d[1], d[2]);
                    if (!component.contains(next) || previous.containsKey(next)) continue;
                    MachineInstance nextMachine = blocks.get(next);
                    if (currentMachine == null || nextMachine == null || !canLink(currentMachine, nextMachine)) continue;
                    previous.put(next, current);
                    if (next.equals(target)) return rebuild(previous, target);
                    queue.add(next);
                }
                if (currentMachine != null && currentMachine.type() == MachineType.DIMENSIONAL_ANCHOR) {
                    for (BlockKey next : component) {
                        if (previous.containsKey(next) || next.equals(current)) continue;
                        MachineInstance nextMachine = blocks.get(next);
                        if (!dimensionalLinkActive(currentMachine, nextMachine)) continue;
                        previous.put(next, current);
                        if (next.equals(target)) return rebuild(previous, target);
                        queue.add(next);
                    }
                }
            }
            return List.of();
        }

        private List<BlockKey> rebuild(Map<BlockKey, BlockKey> previous, BlockKey target) {
            List<BlockKey> reversed = new ArrayList<>();
            for (BlockKey current = target; current != null; current = previous.get(current)) reversed.add(current);
            Collections.reverse(reversed);
            return List.copyOf(reversed);
        }
    }
}
