package dev.voidcore.network;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

/**
 * Small in-memory rolling telemetry window for a physical network graph.
 * It intentionally stores aggregates rather than block/item state so it can be
 * rebuilt safely after a restart without becoming authoritative gameplay data.
 */
public final class NetworkHistory {
    private final int capacity;
    private final Deque<Sample> samples = new ArrayDeque<>();

    public NetworkHistory(int capacity) {
        this.capacity = Math.max(5, capacity);
    }

    public void add(Sample sample) {
        if (sample == null) return;
        samples.addLast(sample);
        while (samples.size() > capacity) samples.removeFirst();
    }

    public Summary summary() {
        if (samples.isEmpty()) return new Summary(0, 0, 0, 0.0, 0, 0.0, 0.0, 0.0, "No telemetry yet");
        double fluxDelivered = 0.0;
        double fluxLost = 0.0;
        double items = 0.0;
        double entropy = 0.0;
        double computation = 0.0;
        double starved = 0.0;
        double blocked = 0.0;
        double entropyStress = 0.0;
        double computationStress = 0.0;
        for (Sample sample : samples) {
            fluxDelivered += sample.fluxDelivered();
            fluxLost += sample.fluxLost();
            items += sample.itemMoves();
            entropy += sample.entropyMoved();
            computation += sample.computationMoved();
            starved += sample.starvedEndpoints();
            blocked += sample.blockedOutputs();
            entropyStress += sample.entropyStressedEndpoints();
            computationStress += sample.computationStarvedEndpoints();
        }
        int count = samples.size();
        double lossPercent = fluxDelivered + fluxLost <= 0.0 ? 0.0 : fluxLost * 100.0 / (fluxDelivered + fluxLost);
        String bottleneck = dominant(starved / count, blocked / count, entropyStress / count, computationStress / count, lossPercent);
        return new Summary(
            count,
            (int) Math.round(fluxDelivered / count),
            (int) Math.round(items / count),
            entropy / count,
            (int) Math.round(computation / count),
            lossPercent,
            starved / count,
            blocked / count,
            bottleneck
        );
    }

    private String dominant(double starved, double blocked, double entropyStress, double computationStress, double lossPercent) {
        if (entropyStress >= 1.0) return "Entropy saturation";
        if (computationStress >= 1.0) return "Computation starvation";
        if (starved >= 1.0) return "Flux starvation";
        if (blocked >= 1.0) return "Blocked item outputs";
        if (lossPercent >= 12.0) return "Route loss (" + String.format(Locale.ROOT, "%.1f%%", lossPercent) + ")";
        return "No dominant bottleneck";
    }

    public record Sample(
        int fluxDelivered,
        int fluxLost,
        int itemMoves,
        double entropyMoved,
        int computationMoved,
        int starvedEndpoints,
        int blockedOutputs,
        int entropyStressedEndpoints,
        int computationStarvedEndpoints
    ) { }

    public record Summary(
        int samples,
        int averageFluxDelivered,
        int averageItemMoves,
        double averageEntropyMoved,
        int averageComputationMoved,
        double averageFluxLossPercent,
        double averageStarvedEndpoints,
        double averageBlockedOutputs,
        String bottleneck
    ) { }
}
