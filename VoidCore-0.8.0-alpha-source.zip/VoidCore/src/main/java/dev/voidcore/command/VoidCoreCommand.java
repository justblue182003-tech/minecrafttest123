package dev.voidcore.command;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.research.ResearchService;
import dev.voidcore.ui.CodexMenu;
import dev.voidcore.ui.ExperimentMenu;
import dev.voidcore.ui.MachineIndexMenu;
import dev.voidcore.ui.MaterialIndexMenu;
import dev.voidcore.ui.RecipeBrowserMenu;
import dev.voidcore.ui.ResearchMenu;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class VoidCoreCommand implements CommandExecutor, TabCompleter {
    private final VoidCorePlugin plugin;
    private final CodexMenu codex;
    private final ResearchMenu researchMenu;
    private final RecipeBrowserMenu recipeBrowser;
    private final MaterialIndexMenu materialIndex;
    private final ExperimentMenu experimentMenu;
    private final MachineIndexMenu machineIndex;
    private final ResearchService research;
    private final ItemService items;

    public VoidCoreCommand(VoidCorePlugin plugin, CodexMenu codex, ResearchMenu researchMenu,
                           RecipeBrowserMenu recipeBrowser, MaterialIndexMenu materialIndex,
                           ExperimentMenu experimentMenu, MachineIndexMenu machineIndex,
                           ResearchService research, ItemService items) {
        this.plugin = plugin;
        this.codex = codex;
        this.researchMenu = researchMenu;
        this.recipeBrowser = recipeBrowser;
        this.materialIndex = materialIndex;
        this.experimentMenu = experimentMenu;
        this.machineIndex = machineIndex;
        this.research = research;
        this.items = items;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Players: use /" + label + ". Admin: /" + label + " help");
                return true;
            }
            codex.open(player);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "research" -> { return openPlayerMenu(sender, researchMenu::open); }
            case "recipes" -> { return openPlayerMenu(sender, recipeBrowser::open); }
            case "materials" -> { return openPlayerMenu(sender, materialIndex::open); }
            case "experiments" -> { return openPlayerMenu(sender, experimentMenu::open); }
            case "machines" -> { return openPlayerMenu(sender, machineIndex::open); }
            default -> { }
        }

        if (!sender.hasPermission("voidcore.admin")) {
            sender.sendMessage(Text.bad("You do not have permission for that command."));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "help" -> sendHelp(sender, label);
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(Text.good("VoidCore configuration reloaded."));
            }
            case "give" -> handleGive(sender, args);
            case "insight" -> handleInsight(sender, args);
            default -> sendHelp(sender, label);
        }
        return true;
    }

    private boolean openPlayerMenu(CommandSender sender, java.util.function.Consumer<Player> opener) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This subcommand is player-only.");
            return true;
        }
        opener.accept(player);
        return true;
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /voidcore give <player> <item> [amount]");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.bad("Player not found."));
            return;
        }
        CustomItem item = CustomItem.fromId(args[2]);
        if (item == null) {
            sender.sendMessage(Text.bad("Unknown item. Use: " + itemNames()));
            return;
        }
        int amount = 1;
        if (args.length >= 4) {
            try { amount = Math.max(1, Math.min(64, Integer.parseInt(args[3]))); }
            catch (NumberFormatException ignored) { }
        }
        target.getInventory().addItem(items.create(item, amount)).values()
            .forEach(leftover -> target.getWorld().dropItemNaturally(target.getLocation(), leftover));
        sender.sendMessage(Text.good("Gave " + amount + "x " + item.displayName() + " to " + target.getName() + "."));
    }

    private void handleInsight(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /voidcore insight <player> <amount>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.bad("Player not found."));
            return;
        }
        int amount;
        try { amount = Integer.parseInt(args[2]); }
        catch (NumberFormatException ex) {
            sender.sendMessage(Text.bad("Amount must be an integer."));
            return;
        }
        research.addInsight(target, amount);
        sender.sendMessage(Text.good("Adjusted " + target.getName() + " by " + amount + " Insight. New total: " + research.insight(target)));
    }

    private void sendHelp(CommandSender sender, String label) {
        sender.sendMessage(Component.text("VoidCore commands", NamedTextColor.LIGHT_PURPLE));
        sender.sendMessage("/" + label + " - open the Codex");
        sender.sendMessage("/" + label + " research|recipes|materials|experiments|machines");
        sender.sendMessage("/" + label + " give <player> <item> [amount]");
        sender.sendMessage("/" + label + " insight <player> <amount>");
        sender.sendMessage("/" + label + " reload");
    }

    private String itemNames() {
        return Arrays.stream(CustomItem.values()).map(CustomItem::id).reduce((a, b) -> a + ", " + b).orElse("");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> base = new ArrayList<>(List.of("research", "recipes", "materials", "experiments", "machines"));
            if (sender.hasPermission("voidcore.admin")) base.addAll(List.of("help", "reload", "give", "insight"));
            return filter(base, args[0]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("insight"))) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return filter(Arrays.stream(CustomItem.values()).map(CustomItem::id).toList(), args[2]);
        }
        return List.of();
    }

    private List<String> filter(List<String> values, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
    }
}
