package dev.voidcore.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

public final class Text {
    private Text() {}

    public static Component title(String text) {
        return Component.text(text, NamedTextColor.DARK_PURPLE)
            .decorate(TextDecoration.BOLD)
            .decoration(TextDecoration.ITALIC, false);
    }

    public static Component name(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    public static Component lore(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }

    public static Component good(String text) {
        return Component.text(text, NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false);
    }

    public static Component bad(String text) {
        return Component.text(text, NamedTextColor.RED).decoration(TextDecoration.ITALIC, false);
    }

    public static Component muted(String text) {
        return Component.text(text, NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false);
    }

    public static Component accent(String text) {
        return Component.text(text, NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false);
    }
}
