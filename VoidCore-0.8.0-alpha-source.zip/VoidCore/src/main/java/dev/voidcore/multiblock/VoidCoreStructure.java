package dev.voidcore.multiblock;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** A symmetric 35-block containment lattice around a Void Core controller. */
public final class VoidCoreStructure {
    private VoidCoreStructure() { }

    public record Status(boolean valid, int matched, int required, String firstProblem) {
        public double completeness() { return required <= 0 ? 1.0 : matched / (double) required; }
    }

    private record Requirement(int x, int y, int z, Material material, String name) { }
    private static final List<Requirement> REQUIREMENTS = buildRequirements();

    public static Status validate(Location controller) {
        if (controller == null || controller.getWorld() == null)
            return new Status(false, 0, REQUIREMENTS.size(), "Controller world is unavailable.");
        World world = controller.getWorld();
        int matched = 0;
        String problem = null;
        for (Requirement r : REQUIREMENTS) {
            Material actual = world.getBlockAt(controller.getBlockX() + r.x, controller.getBlockY() + r.y,
                controller.getBlockZ() + r.z).getType();
            if (actual == r.material) matched++;
            else if (problem == null) problem = r.name + " requires " + pretty(r.material) + ".";
        }
        return new Status(matched == REQUIREMENTS.size(), matched, REQUIREMENTS.size(),
            problem == null ? "Void-Core containment geometry is complete." : problem);
    }

    private static List<Requirement> buildRequirements() {
        List<Requirement> result = new ArrayList<>();
        // 5x5 perimeter around the controller: 16 containment blocks.
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                if (Math.max(Math.abs(x), Math.abs(z)) != 2) continue;
                result.add(new Requirement(x, 0, z, Material.REINFORCED_DEEPSLATE,
                    "Containment ring " + x + "," + z));
            }
        }
        int[][] cardinal = {{2,0},{-2,0},{0,2},{0,-2}};
        int[][] diagonal = {{1,1},{1,-1},{-1,1},{-1,-1}};
        for (int[] p : cardinal) {
            result.add(new Requirement(p[0], 1, p[1], Material.COPPER_BLOCK, "Upper field pylon " + p[0] + "," + p[1]));
            result.add(new Requirement(p[0], -1, p[1], Material.COPPER_BLOCK, "Lower field pylon " + p[0] + "," + p[1]));
        }
        for (int[] p : diagonal) {
            result.add(new Requirement(p[0], 1, p[1], Material.TINTED_GLASS, "Upper phase lens " + p[0] + "," + p[1]));
            result.add(new Requirement(p[0], -1, p[1], Material.TINTED_GLASS, "Lower phase lens " + p[0] + "," + p[1]));
        }
        result.add(new Requirement(0, 1, 0, Material.AMETHYST_CLUSTER, "Upper coherence focus"));
        result.add(new Requirement(0, -1, 0, Material.SCULK_CATALYST, "Lower entropy sink"));
        return List.copyOf(result);
    }

    private static String pretty(Material material) {
        String[] parts = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (!builder.isEmpty()) builder.append(' ');
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }
}
