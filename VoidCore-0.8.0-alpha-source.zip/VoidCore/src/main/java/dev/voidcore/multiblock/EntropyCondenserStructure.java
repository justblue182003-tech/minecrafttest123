package dev.voidcore.multiblock;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

/** Physical 17-block frame around an Entropy Condenser controller. */
public final class EntropyCondenserStructure {
    private EntropyCondenserStructure() { }

    public record Status(boolean valid, int matched, int required, String firstProblem) {
        public double completeness() { return required <= 0 ? 1.0 : matched / (double) required; }
    }

    private record Requirement(int x, int y, int z, Material material, String name) { }

    private static final List<Requirement> REQUIREMENTS = buildRequirements();

    public static Status validate(Location controller) {
        if (controller == null || controller.getWorld() == null) return new Status(false, 0, REQUIREMENTS.size(), "Controller world is unavailable.");
        World world = controller.getWorld();
        int matched = 0;
        String problem = null;
        for (Requirement requirement : REQUIREMENTS) {
            Material actual = world.getBlockAt(controller.getBlockX() + requirement.x,
                controller.getBlockY() + requirement.y, controller.getBlockZ() + requirement.z).getType();
            if (actual == requirement.material) matched++;
            else if (problem == null) problem = requirement.name + " requires " + pretty(requirement.material) + ".";
        }
        return new Status(matched == REQUIREMENTS.size(), matched, REQUIREMENTS.size(),
            problem == null ? "Array geometry is complete." : problem);
    }

    private static List<Requirement> buildRequirements() {
        List<Requirement> result = new ArrayList<>();
        int[][] corners = {{-1,-1},{-1,1},{1,-1},{1,1}};
        int[][] cardinals = {{-1,0},{1,0},{0,-1},{0,1}};
        for (int[] p : corners) result.add(new Requirement(p[0], 0, p[1], Material.POLISHED_BLACKSTONE_BRICKS, "Lower corner " + p[0] + "," + p[1]));
        for (int[] p : cardinals) result.add(new Requirement(p[0], 0, p[1], Material.COPPER_GRATE, "Lower field port " + p[0] + "," + p[1]));
        for (int[] p : corners) result.add(new Requirement(p[0], 1, p[1], Material.AMETHYST_BLOCK, "Upper resonator " + p[0] + "," + p[1]));
        for (int[] p : cardinals) result.add(new Requirement(p[0], 1, p[1], Material.TINTED_GLASS, "Upper containment pane " + p[0] + "," + p[1]));
        result.add(new Requirement(0, 1, 0, Material.LIGHTNING_ROD, "Entropy discharge mast"));
        return List.copyOf(result);
    }

    private static String pretty(Material material) {
        String[] parts = material.name().toLowerCase(java.util.Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (!builder.isEmpty()) builder.append(' ');
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }
}
