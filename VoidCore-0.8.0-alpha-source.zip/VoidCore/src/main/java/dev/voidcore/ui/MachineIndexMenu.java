package dev.voidcore.ui;

import dev.voidcore.item.ItemService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.recipe.RecipeRegistry;
import dev.voidcore.recipe.VoidRecipe;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class MachineIndexMenu {
    public static final int BACK_SLOT = 49;
    private static final int[] SLOTS = {9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 37, 38, 39, 40, 41, 42, 43, 44};
    private final ItemService items;
    private final ResearchService research;
    private final RecipeRegistry recipes;

    public MachineIndexMenu(ItemService items, ResearchService research, RecipeRegistry recipes) {
        this.items = items;
        this.research = research;
        this.recipes = recipes;
    }

    public void open(Player player) {
        MenuHolder holder = new MenuHolder("machines");
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Industrial Systems"));
        holder.attach(inv);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.CRAFTER, "Industrial Systems", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Machines are tools in a process chain, not isolated gimmicks."),
                Text.muted("Tier-II processors expose heat, quality, catalyst health, and upgrade diagnostics."))));

        MachineType[] types = MachineType.values();
        for (int i = 0; i < types.length && i < SLOTS.length; i++) inv.setItem(SLOTS[i], machineItem(player, types[i]));
        inv.setItem(BACK_SLOT, GuiItems.item(Material.ARROW, "Back", NamedTextColor.GRAY, List.of()));
        player.openInventory(inv);
    }

    public MachineType typeAt(int slot) {
        MachineType[] types = MachineType.values();
        for (int i = 0; i < SLOTS.length && i < types.length; i++) if (SLOTS[i] == slot) return types[i];
        return null;
    }

    public VoidRecipe recipeFor(MachineType type) { return recipes.producing(type.item()); }

    private ItemStack machineItem(Player player, MachineType type) {
        ItemStack stack = items.create(type.item());
        ItemMeta meta = stack.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        boolean unlocked = research.isUnlocked(player, type.research());
        lore.add(Component.empty());
        lore.add(Text.lore("Research: " + type.research().displayName()));
        lore.add(unlocked ? Text.good("✓ Understood") : Text.bad("✗ Locked"));
        if (type.isEngineeringProcessor()) {
            lore.add(Text.lore("Upgrade sockets: " + type.upgradeSlots()));
            lore.add(Text.lore("Thermal mass: " + type.thermalMass()));
            lore.add(Text.lore("Safe range: " + (int) type.minimumSafeHeat() + "–" + (int) type.maximumSafeHeat() + "°C"));
            if (type.usesPressure()) lore.add(Text.lore(String.format(java.util.Locale.ROOT, "Pressure: %.1f–%.1f bar", type.minimumSafePressure(), type.maximumSafePressure())));
            if (type.isMultiblockController()) lore.add(Text.accent(type == MachineType.VOID_CORE ? "Requires 35-block physical Void Core lattice" : "Requires 17-block physical condenser array"));
        } else if (type.isObserver()) {
            lore.add(Text.lore("Environmental computation source"));
            lore.add(Text.muted("Yield reacts to sky, time, dimension, and sculk fields."));
        } else if (type.isThermalInfrastructure()) {
            lore.add(Text.lore("Heat-recovery infrastructure"));
        } else if (type.isNetworkBlock()) {
            lore.add(Text.lore("Phase Logistics network block"));
        }
        if (recipes.producing(type.item()) != null) lore.add(Text.accent("Click for fabrication recipe"));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(unlocked);
        stack.setItemMeta(meta);
        return stack;
    }
}
