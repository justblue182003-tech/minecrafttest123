package dev.voidcore.ui;

import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class ExperimentMenu {
    public static final String MENU_PREFIX = "experiments:";
    public static final int PREVIOUS_SLOT = 45;
    public static final int BACK_SLOT = 49;
    public static final int NEXT_SLOT = 53;
    private static final int[] CONTENT_SLOTS = {
        9,10,11,12,13,14,15,16,17,
        18,19,20,21,22,23,24,25,26,
        27,28,29,30,31,32,33,34,35,
        36,37,38,39,40,41,42,43,44
    };
    private final ExperimentService experiments;

    public ExperimentMenu(ExperimentService experiments) { this.experiments = experiments; }

    public void open(Player player) { open(player, 0); }

    public void open(Player player, int requestedPage) {
        ResearchExperiment[] values = ResearchExperiment.values();
        int pages = Math.max(1, (int) Math.ceil(values.length / (double) CONTENT_SLOTS.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        MenuHolder holder = new MenuHolder(MENU_PREFIX + page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Experiments"));
        holder.attach(inv);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.LECTERN, "Research Experiments • " + (page + 1) + "/" + pages, NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Experiments prove that you understand a system."),
                Text.muted("Completed experiments award Insight and unlock research gates."))));

        int start = page * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            int index = start + i;
            if (index >= values.length) break;
            inv.setItem(CONTENT_SLOTS[i], experimentItem(player, values[index]));
        }
        inv.setItem(PREVIOUS_SLOT, page > 0 ? GuiItems.item(Material.SPECTRAL_ARROW, "Previous Page", NamedTextColor.GRAY, List.of()) : GuiItems.filler(Material.GRAY_STAINED_GLASS_PANE));
        inv.setItem(BACK_SLOT, GuiItems.item(Material.ARROW, "Back", NamedTextColor.GRAY, GuiItems.lore(Text.muted("Return to the Codex."))));
        inv.setItem(NEXT_SLOT, page + 1 < pages ? GuiItems.item(Material.SPECTRAL_ARROW, "Next Page", NamedTextColor.AQUA, List.of()) : GuiItems.filler(Material.GRAY_STAINED_GLASS_PANE));
        player.openInventory(inv);
    }

    public int page(MenuHolder holder) {
        if (holder == null || !holder.menuId().startsWith(MENU_PREFIX)) return 0;
        try { return Integer.parseInt(holder.menuId().substring(MENU_PREFIX.length())); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private ItemStack experimentItem(Player player, ResearchExperiment experiment) {
        int progress = experiments.progress(player, experiment);
        boolean complete = experiments.isComplete(player, experiment);
        List<Component> lore = new ArrayList<>();
        lore.add(Text.lore(experiment.description()));
        lore.add(Component.empty());
        lore.add(Text.lore("Progress: " + progress + " / " + experiment.target()));
        lore.add(Text.lore("Reward: +" + experiment.insightReward() + " Insight"));
        lore.add(Component.empty());
        lore.add(complete ? Text.good("✓ Complete") : Text.accent(progressBar(progress, experiment.target())));
        ItemStack stack = GuiItems.item(experiment.icon(), experiment.displayName(), complete ? NamedTextColor.GREEN : NamedTextColor.LIGHT_PURPLE, lore);
        ItemMeta meta = stack.getItemMeta();
        meta.setEnchantmentGlintOverride(complete);
        stack.setItemMeta(meta);
        return stack;
    }

    private String progressBar(int progress, int target) {
        int filled = target <= 0 ? 10 : (int) Math.floor((progress * 10.0) / target);
        filled = Math.max(0, Math.min(10, filled));
        return "[" + "■".repeat(filled) + "□".repeat(10 - filled) + "]";
    }
}
