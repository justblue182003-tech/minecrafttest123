package dev.voidcore.ui;

import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.network.NetworkMetrics;
import dev.voidcore.network.NetworkService;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class NetworkDiagnosticsMenu {
    public static final String MENU_ID = "network:diagnostics";
    public static final int FREQ_DOWN_SLOT = 47;
    public static final int FREQUENCY_SLOT = 48;
    public static final int FREQ_UP_SLOT = 49;
    public static final int TRACE_SLOT = 51;
    public static final int CLOSE_SLOT = 53;

    private final MachineService machines;
    private final NetworkService networks;
    private final ExperimentService experiments;

    public NetworkDiagnosticsMenu(MachineService machines, NetworkService networks, ExperimentService experiments) {
        this.machines = machines;
        this.networks = networks;
        this.experiments = experiments;
    }

    public void open(Player player, MachineInstance block) {
        if (block == null || !block.type().isNetworkBlock()) return;
        MachineMenuHolder holder = new MachineMenuHolder(block.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Phase Logistics"));
        holder.attach(inv);
        render(inv, block);
        player.openInventory(inv);
        NetworkMetrics metrics = networks.metricsAt(block.location());
        if (metrics != null) {
            if (metrics.fluxSent() > 0) experiments.advance(player, ResearchExperiment.NETWORK_FLUX_BALANCE);
            if (metrics.priorityMoves() > 0) experiments.advance(player, ResearchExperiment.PRIORITY_ROUTE);
            if (metrics.bridgedTransfers() > 0 && metrics.mixedFrequency()) experiments.advance(player, ResearchExperiment.FREQUENCY_BRIDGE);
            if (!metrics.activeControlDirective().equals("Balanced") && metrics.controlledEndpoints() >= 2) experiments.advance(player, ResearchExperiment.BROADCAST_CONTROL);
            if (metrics.crossDimensional() && metrics.dimensionalAnchors() >= 2) experiments.advance(player, ResearchExperiment.DIMENSIONAL_LINK);
        }
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance block = machines.get(holder.machineLocation());
            if (block == null || !block.type().isNetworkBlock()) player.closeInventory();
            else render(top, block);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance block) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        NetworkMetrics metrics = networks.metricsAt(block.location());
        inv.setItem(4, GuiItems.item(Material.ENDER_EYE, "Phase Logistics", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Node address: " + machines.networkAddress(block)),
                Text.muted("Physical adjacency defines paths; frequencies define domains; splitters explicitly bridge domains."))));

        if (metrics == null) {
            inv.setItem(22, GuiItems.item(Material.GRAY_DYE, "Network Not Resolved", NamedTextColor.GRAY,
                GuiItems.lore(Text.muted("The graph is rebuilt once per second from loaded network blocks."))));
        } else {
            String domains = metrics.frequencies().stream().map(String::valueOf).collect(Collectors.joining(", "));
            inv.setItem(10, GuiItems.item(Material.LIGHTNING_ROD, metrics.id(), NamedTextColor.AQUA,
                GuiItems.lore(Text.lore("Frequency domains: " + domains),
                    Text.lore("Flux buses: " + metrics.busCount()),
                    Text.lore("Routers / buffers / splitters: " + metrics.routers() + " / " + metrics.buffers() + " / " + metrics.splitters()),
                    Text.lore("Control / automation terminals: " + metrics.controlMatrices() + " / " + metrics.automationTerminals()),
                    Text.lore("Dimensional anchors / project terminals: " + metrics.dimensionalAnchors() + " / " + metrics.projectTerminals()),
                    Text.lore("Machine endpoints: " + metrics.endpointCount()),
                    metrics.crossDimensional() ? Text.accent("Cross-dimensional graph resolved") : Text.muted("Single-dimensional graph"))));
            inv.setItem(12, GuiItems.item(Material.REDSTONE, "Flux Routing", NamedTextColor.RED,
                GuiItems.lore(Text.lore("Sent: " + metrics.fluxSent() + " Flux/s"),
                    Text.lore("Delivered: " + metrics.fluxDelivered() + " Flux/s"),
                    Text.lore("Lost: " + metrics.fluxLost() + " Flux/s"),
                    Text.lore(String.format(Locale.ROOT, "Observed loss: %.1f%%", metrics.lossPercent())),
                    Text.lore("Longest active route: " + metrics.longestTransferHops() + " hops"))));
            inv.setItem(14, GuiItems.item(Material.HOPPER, "Item Policy", NamedTextColor.GOLD,
                GuiItems.lore(Text.lore("Items moved: " + metrics.itemMoves() + "/s"),
                    Text.lore("Priority-controlled: " + metrics.priorityMoves()),
                    Text.lore("Blocked producer outputs: " + metrics.blockedOutputs()),
                    Text.lore("Cross-frequency transfers: " + metrics.bridgedTransfers()),
                    Text.lore("Cross-dimensional transfers: " + metrics.dimensionalTransfers()))));
            inv.setItem(16, GuiItems.item(Material.COMPARATOR, "Topology + Path Cache", NamedTextColor.YELLOW,
                GuiItems.lore(Text.lore("Path hits: " + metrics.pathCacheHits()),
                    Text.lore("Path misses: " + metrics.pathCacheMisses()),
                    Text.lore("Topology cache age: " + metrics.topologyCacheAge() + " graph passes"),
                    metrics.topologyReused() ? Text.good("Unchanged topology reused across ticks") : Text.accent("Topology changed; route cache rebuilt"))));
            boolean stressed = metrics.starvedEndpoints() > 0 || metrics.entropyStressedEndpoints() > 0 || metrics.computationStarvedEndpoints() > 0;
            inv.setItem(18, GuiItems.item(stressed ? Material.RED_DYE : Material.LIME_DYE,
                stressed ? "Infrastructure Pressure" : "Supply Healthy",
                stressed ? NamedTextColor.RED : NamedTextColor.GREEN,
                GuiItems.lore(Text.lore("Flux-starved endpoints: " + metrics.starvedEndpoints()),
                    Text.lore("Entropy-stressed endpoints: " + metrics.entropyStressedEndpoints()),
                    Text.lore("Computation-starved endpoints: " + metrics.computationStarvedEndpoints()))));
            inv.setItem(20, GuiItems.item(Material.SCULK, "Entropy Transport", NamedTextColor.DARK_AQUA,
                GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Captured: %.1f entropy/s", metrics.entropyMoved())),
                    Text.lore(String.format(Locale.ROOT, "Dissipated in transit: %.2f/s", metrics.entropyLost())),
                    Text.muted("Processors donate excess entropy to attached Entropy Condensers."))));
            inv.setItem(22, GuiItems.item(Material.DAYLIGHT_DETECTOR, "Compute + Control", NamedTextColor.AQUA,
                GuiItems.lore(Text.lore("Routed computation: " + metrics.computationMoved() + "/s"),
                    Text.lore("Active policy: " + metrics.activeControlDirective()),
                    Text.lore("Controlled endpoints: " + metrics.controlledEndpoints()),
                    Text.lore("High signal channels: " + metrics.highSignalChannels()),
                    Text.lore("Signal-gated endpoints: " + metrics.gatedEndpoints()),
                    Text.muted("Observers feed computation to inference, control, automation, and dimensional infrastructure."))));
            inv.setItem(24, GuiItems.item(Material.CLOCK, "Rolling Telemetry", NamedTextColor.GOLD,
                GuiItems.lore(Text.lore("Samples: " + metrics.history().samples()),
                    Text.lore("Avg Flux delivered: " + metrics.history().averageFluxDelivered() + "/s"),
                    Text.lore(String.format(Locale.ROOT, "Avg Entropy captured: %.1f/s", metrics.history().averageEntropyMoved())),
                    Text.lore("Avg Computation routed: " + metrics.history().averageComputationMoved() + "/s"),
                    Text.lore("Bottleneck: " + metrics.history().bottleneck()))));
            inv.setItem(26, GuiItems.item(Material.WRITABLE_BOOK, "Persistent Production Ledger", NamedTextColor.LIGHT_PURPLE,
                GuiItems.lore(Text.lore("Lifetime cycles: " + metrics.lifetimeCycles()),
                    Text.lore("Items produced: " + metrics.lifetimeItemsProduced()),
                    Text.lore("Flux consumed: " + metrics.lifetimeFluxConsumed()),
                    Text.lore(String.format(Locale.ROOT, "Entropy processed: %.1f", metrics.lifetimeEntropyProcessed())),
                    Text.lore("Recoverable incidents: " + metrics.lifetimeIncidents()),
                    Text.muted("Aggregated from persistent machine counters on the currently resolved graph."))));

            int[] slots = {28,29,30,31,32,33,34,37,38,39,40,41,42,43};
            for (int i = 0; i < slots.length; i++) {
                if (i >= metrics.endpoints().size()) { inv.setItem(slots[i], GuiItems.filler(Material.GRAY_STAINED_GLASS_PANE)); continue; }
                NetworkMetrics.EndpointStatus endpoint = metrics.endpoints().get(i);
                inv.setItem(slots[i], GuiItems.item(endpoint.type().item().material(), endpoint.address(), NamedTextColor.AQUA,
                    GuiItems.lore(Text.lore(endpoint.type().displayName()),
                        Text.lore(endpoint.flux() + " / " + endpoint.capacity() + " Flux"),
                        endpoint.entropyCapacity() > 0.0 ? Text.lore(String.format(Locale.ROOT, "Entropy: %.1f / %.1f", endpoint.entropy(), endpoint.entropyCapacity())) : Text.muted("No entropy buffer"),
                        endpoint.computationCapacity() > 0 ? Text.lore("Computation: " + endpoint.computation() + " / " + endpoint.computationCapacity()) : Text.muted("No computation buffer"),
                        Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", endpoint.wear())),
                        Text.lore("Fault: " + endpoint.fault()),
                        Text.lore("Route priority: " + endpoint.routingPriority()),
                        Text.lore("Filter: " + endpoint.routingFilter()),
                        Text.lore("Automation: G" + endpoint.automationGroup() + " • CH" + endpoint.signalChannel() + " • " + endpoint.signalGate()),
                        Text.lore("Signal: " + (endpoint.signalHigh() ? "HIGH" : "LOW")),
                        endpoint.phaseInterface() ? Text.good("Automatic routing enabled") : Text.muted("No item-routing interface"))));
            }
        }

        inv.setItem(FREQ_DOWN_SLOT, GuiItems.item(Material.PURPLE_DYE, "Frequency −1", NamedTextColor.LIGHT_PURPLE, List.of()));
        inv.setItem(FREQUENCY_SLOT, GuiItems.item(Material.COMPASS, "Primary Frequency " + block.networkFrequency(), NamedTextColor.GOLD,
            GuiItems.lore(Text.muted("Shift-click changes by 10. Splitters configure their secondary domain in the node panel."))));
        inv.setItem(FREQ_UP_SLOT, GuiItems.item(Material.MAGENTA_DYE, "Frequency +1", NamedTextColor.LIGHT_PURPLE, List.of()));
        inv.setItem(TRACE_SLOT, GuiItems.item(Material.END_ROD, "Trace Last Active Route", NamedTextColor.AQUA,
            GuiItems.lore(Text.muted("Draws a player-only particle trace over the last successful cached transfer path."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
