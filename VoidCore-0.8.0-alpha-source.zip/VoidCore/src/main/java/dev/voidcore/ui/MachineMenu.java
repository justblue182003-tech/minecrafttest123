package dev.voidcore.ui;

import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Set;

public final class MachineMenu {
    public static final String MENU_ID = "machine:flux_crucible";
    public static final int INPUT_SLOT = 20;
    public static final int STATUS_SLOT = 22;
    public static final int OUTPUT_SLOT = 24;
    public static final int ENERGY_SLOT = 31;
    public static final int FUEL_SLOT = 38;
    private static final Set<Integer> CONTENT_SLOTS = Set.of(INPUT_SLOT, OUTPUT_SLOT, FUEL_SLOT);

    private final MachineService machines;

    public MachineMenu(MachineService machines) {
        this.machines = machines;
    }

    public void open(Player player, MachineInstance machine) {
        if (machine.type() != MachineType.FLUX_CRUCIBLE) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • " + machine.type().displayName()));
        holder.attach(inv);
        render(inv, machine);
        player.openInventory(inv);
    }

    public void syncOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof MachineMenuHolder holder
                && holder.menuId().equals(MENU_ID)) {
                sync(player.getOpenInventory().getTopInventory(), holder);
            }
        }
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().equals(MENU_ID)) {
                MachineInstance machine = machines.get(holder.machineLocation());
                if (machine != null && machine.type() == MachineType.FLUX_CRUCIBLE) render(top, machine);
                else player.closeInventory();
            }
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder)) continue;
            if (!holder.menuId().equals(MENU_ID)) continue;
            org.bukkit.Location open = holder.machineLocation();
            if (!sameBlock(open, location)) continue;
            sync(top, holder);
            player.closeInventory();
        }
    }

    public void sync(Inventory inv, MachineMenuHolder holder) {
        if (!holder.menuId().equals(MENU_ID)) return;
        MachineInstance machine = machines.get(holder.machineLocation());
        if (machine == null || machine.type() != MachineType.FLUX_CRUCIBLE) return;
        machine.input(normalize(inv.getItem(INPUT_SLOT)));
        machine.fuel(normalize(inv.getItem(FUEL_SLOT)));
        machine.output(normalize(inv.getItem(OUTPUT_SLOT)));
        machines.markDirty();
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) {
            if (!CONTENT_SLOTS.contains(i)) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        }

        inv.setItem(13, GuiItems.item(Material.BARREL, machine.type().displayName(), NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Tier I resonance processor"),
                Text.lore(String.format(java.util.Locale.ROOT, "Wear: %.1f%%", machine.wear())),
                machine.maintenanceLocked() ? Text.bad("SERVICE LOCKOUT — use a Precision Maintenance Kit")
                    : Text.muted("Safe operation requires Flux Handling."))));

        inv.setItem(INPUT_SLOT, machine.input());
        inv.setItem(FUEL_SLOT, machine.fuel());
        inv.setItem(OUTPUT_SLOT, machine.output());

        int seconds = machines.operationSeconds();
        double done = Math.min(seconds, machine.progress());
        int percent = seconds <= 0 ? 0 : (int) Math.floor((done * 100.0) / seconds);
        Material statusMaterial = machine.maintenanceLocked() ? Material.ANVIL : machine.progress() > 0 ? Material.CLOCK : Material.GRAY_DYE;
        String reactionTitle = machine.maintenanceLocked() ? "Service Required" : "Reaction: " + percent + "%";
        inv.setItem(STATUS_SLOT, GuiItems.item(statusMaterial, reactionTitle, machine.maintenanceLocked() ? NamedTextColor.RED : NamedTextColor.GOLD,
            GuiItems.lore(
                Text.lore("Input: Resonant Fragment"),
                Text.lore("Output: Charged Resonance"),
                Text.muted("Processing pauses safely when power is insufficient.")
            )));

        inv.setItem(ENERGY_SLOT, GuiItems.item(Material.REDSTONE_TORCH,
            "Flux: " + machine.flux() + " / " + machines.maxFlux(), NamedTextColor.RED,
            GuiItems.lore(Text.lore("Redstone: +" + machines.redstoneFlux() + " flux"),
                Text.lore("Redstone Block: +" + machines.redstoneBlockFlux() + " flux"))));

        if (inv.getItem(INPUT_SLOT) == null) inv.setItem(INPUT_SLOT, null);
        if (inv.getItem(FUEL_SLOT) == null) inv.setItem(FUEL_SLOT, null);
        if (inv.getItem(OUTPUT_SLOT) == null) inv.setItem(OUTPUT_SLOT, null);
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        if (a.getWorld() == null || b.getWorld() == null || !a.getWorld().equals(b.getWorld())) return false;
        return a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }

    private ItemStack normalize(ItemStack item) {
        if (item == null || item.getType().isAir()) return null;
        return item.clone();
    }
}
