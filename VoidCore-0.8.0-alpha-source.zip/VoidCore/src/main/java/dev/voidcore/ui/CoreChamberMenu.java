package dev.voidcore.ui;

import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.Locale;

public final class CoreChamberMenu {
    public static final String MENU_ID = "machine:void_upgrade_chamber";
    public static final int MODE_SLOT = 13;
    public static final int CLOSE_SLOT = 53;
    private final MachineService machines;

    public CoreChamberMenu(MachineService machines) { this.machines = machines; }

    public void open(Player player, MachineInstance chamber) {
        if (chamber == null || chamber.type() != MachineType.VOID_UPGRADE_CHAMBER) return;
        MachineMenuHolder holder = new MachineMenuHolder(chamber.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Upgrade Chamber"));
        holder.attach(inv); render(inv, chamber); player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance chamber = machines.get(holder.machineLocation());
            if (chamber == null || chamber.type() != MachineType.VOID_UPGRADE_CHAMBER) player.closeInventory();
            else render(top, chamber);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().equals(MENU_ID)
                && sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance chamber) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        var mode = chamber.coreChamberMode();
        MachineInstance core = machines.nearestVoidCore(chamber.location(), 6.0);
        inv.setItem(4, GuiItems.item(Material.RESPAWN_ANCHOR, "Void Core Upgrade Chamber", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Quality: " + chamber.quality() + "/100"), Text.muted("Auxiliary chambers must remain within six blocks of a Void Core controller."))));
        inv.setItem(MODE_SLOT, GuiItems.item(mode.icon(), mode.displayName(), NamedTextColor.GOLD,
            GuiItems.lore(Text.lore(mode.description()), Text.accent("Click: next mode • Right-click: previous"))));
        inv.setItem(20, GuiItems.item(Material.REDSTONE, "Flux Buffer", NamedTextColor.RED,
            GuiItems.lore(Text.lore(chamber.flux() + " / " + machines.maxFlux(chamber.type()) + " Flux"),
                Text.muted("A configured chamber consumes Flux continuously while supporting a nearby core."))));
        inv.setItem(22, GuiItems.item(core == null ? Material.RED_STAINED_GLASS : Material.LIME_STAINED_GLASS,
            core == null ? "No Void Core Linked" : "Void Core Linked", core == null ? NamedTextColor.RED : NamedTextColor.GREEN,
            core == null ? GuiItems.lore(Text.bad("Place this chamber within six blocks of the controller."))
                : GuiItems.lore(Text.good("Controller: " + machines.networkAddress(core)), Text.lore(String.format(Locale.ROOT, "Field: %.1f%%", core.fieldStability())),
                    Text.lore("Singularity: " + core.singularityMode().displayName()))));
        inv.setItem(24, GuiItems.item(chamber.signalGate().icon(), "Automation Gate", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore(chamber.signalGate().displayName()), Text.lore("G" + chamber.automationGroup() + " • CH" + chamber.signalChannel()),
                chamber.automationAllowsRun() ? Text.good("Permission: RUN") : Text.bad("Permission: HOLD"),
                Text.muted("Configure group/channel/gate through diagnostics on engineering processors; chamber state persists with relocation."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
