package dev.voidcore.ui;

import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.process.ProcessEnvironment;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.Locale;

public final class ObserverMenu {
    public static final String MENU_ID = "machine:phase_observer";
    public static final int PROGRAM_SLOT = 13;
    public static final int CLOSE_SLOT = 53;

    private final MachineService machines;

    public ObserverMenu(MachineService machines) { this.machines = machines; }

    public void open(Player player, MachineInstance machine) {
        if (machine == null || machine.type() != MachineType.PHASE_OBSERVER) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Phase Observer"));
        holder.attach(inv);
        render(inv, machine);
        player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null || machine.type() != MachineType.PHASE_OBSERVER) player.closeInventory();
            else render(top, machine);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.OBSERVER, "Phase Observer", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Address: " + machines.networkAddress(machine)),
                Text.muted("Environmental signals become computation; computation can be routed to industrial inference endpoints."))));

        inv.setItem(PROGRAM_SLOT, GuiItems.item(machine.observerProgram().icon(), machine.observerProgram().displayName(), NamedTextColor.GOLD,
            GuiItems.lore(Text.lore(machine.observerProgram().description()),
                Text.accent("Click: next program • Right-click: previous"),
                Text.muted("Specialized programs trade broad coverage for stronger targeted signals."))));

        int yield = machines.observerYield(machine);
        inv.setItem(20, GuiItems.item(Material.DAYLIGHT_DETECTOR, "Observation Signal", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Signal: " + machines.observerStatus(machine)),
                Text.lore("Current yield: +" + yield + " compute/s"),
                ProcessEnvironment.NIGHT_SKY.matches(machine.location()) ? Text.good("Clear-night correlation active") : Text.muted("Clear-night correlation inactive"),
                ProcessEnvironment.SCULK_FIELD.matches(machine.location()) ? Text.good("Local sculk correlation active") : Text.muted("No dense sculk field detected"))));

        int computeCap = machines.computationCapacity(machine.type());
        inv.setItem(22, GuiItems.item(Material.COMPARATOR, "Computation Buffer", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore(machine.computation() + " / " + computeCap + " compute"),
                Text.muted("Connected Phase Logistics networks can deliver this budget to computation-aware machines."))));

        double entropyCap = machines.entropyCapacity(machine.type());
        inv.setItem(24, GuiItems.item(Material.SCULK, "Observer Entropy", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore(String.format(Locale.ROOT, "%.1f / %.1f entropy", machine.entropy(), entropyCap)),
                Text.muted("Observation is not free: inference itself creates a small entropy load."))));

        inv.setItem(29, GuiItems.item(Material.REDSTONE, "Flux Buffer", NamedTextColor.RED,
            GuiItems.lore(Text.lore(machine.flux() + " / " + machines.maxFlux(machine.type()) + " Flux"),
                Text.muted("Observation consumes Flux continuously while the computation buffer has room."))));
        inv.setItem(31, GuiItems.item(machine.hasFault() ? machine.fault().icon() : Material.LIME_DYE,
            machine.hasFault() ? machine.fault().displayName() : "Nominal", machine.hasFault() ? NamedTextColor.RED : NamedTextColor.GREEN,
            GuiItems.lore(machine.hasFault() ? Text.bad(machine.fault().description()) : Text.good("Observation timing is coherent."),
                Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", machine.wear())))));
        inv.setItem(33, GuiItems.item(Material.ENDER_EYE, "Network Export", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Attach directly to a Flux Bus graph."),
                Text.muted("The attached physical graph determines the frequency domain and exports both computation and excess entropy."))));

        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
