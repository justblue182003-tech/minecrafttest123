package dev.voidcore.ui;

import dev.voidcore.machine.ControlDirective;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.network.NetworkMetrics;
import dev.voidcore.network.NetworkService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

public final class ControlMatrixMenu {
    public static final String MENU_ID = "network:control_matrix";
    public static final int POLICY_PREVIOUS_SLOT = 20;
    public static final int POLICY_SLOT = 22;
    public static final int POLICY_NEXT_SLOT = 24;
    public static final int DIAGNOSTICS_SLOT = 49;
    public static final int CLOSE_SLOT = 53;

    private final MachineService machines;
    private final NetworkService networks;

    public ControlMatrixMenu(MachineService machines, NetworkService networks) {
        this.machines = machines;
        this.networks = networks;
    }

    public void open(Player player, MachineInstance matrix) {
        if (matrix == null || matrix.type() != MachineType.CONTROL_MATRIX) return;
        MachineMenuHolder holder = new MachineMenuHolder(matrix.location(), MENU_ID);
        Inventory inventory = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Control Matrix"));
        holder.attach(inventory);
        render(inventory, matrix);
        player.openInventory(inventory);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance matrix = machines.get(holder.machineLocation());
            if (matrix == null || matrix.type() != MachineType.CONTROL_MATRIX) player.closeInventory();
            else render(top, matrix);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance matrix) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        ControlDirective directive = matrix.controlDirective();
        NetworkMetrics metrics = networks.metricsAt(matrix.location());
        inv.setItem(4, GuiItems.item(Material.REDSTONE_LAMP, "Control Matrix", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Address: " + machines.networkAddress(matrix)),
                Text.muted("One deterministic matrix policy is applied to machine endpoints on this physical graph."))));

        inv.setItem(POLICY_PREVIOUS_SLOT, GuiItems.item(Material.RED_DYE, "Previous Policy", NamedTextColor.RED, List.of()));
        inv.setItem(POLICY_SLOT, GuiItems.item(directive.icon(), directive.displayName(), NamedTextColor.GOLD,
            GuiItems.lore(Text.lore(directive.description()),
                Text.lore("Requested policy: " + directive.displayName()),
                Text.muted("Non-balanced policies consume computation continuously."))));
        inv.setItem(POLICY_NEXT_SLOT, GuiItems.item(Material.LIME_DYE, "Next Policy", NamedTextColor.GREEN, List.of()));

        inv.setItem(29, GuiItems.item(Material.DAYLIGHT_DETECTOR, "Computation Buffer", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore(matrix.computation() + " / " + machines.computationCapacity(matrix.type()) + " compute"),
                Text.muted("Phase Observers supply this buffer over the same network."))));
        inv.setItem(31, GuiItems.item(metrics == null ? Material.GRAY_DYE : Material.COMPARATOR, "Broadcast State",
            metrics == null ? NamedTextColor.GRAY : NamedTextColor.AQUA,
            metrics == null ? GuiItems.lore(Text.muted("Network graph not resolved yet."))
                : GuiItems.lore(Text.lore("Active: " + metrics.activeControlDirective()),
                    Text.lore("Controlled endpoints: " + metrics.controlledEndpoints()),
                    Text.lore("Control matrices on graph: " + metrics.controlMatrices()),
                    metrics.activeControlDirective().equals("Balanced") && directive != ControlDirective.BALANCED
                        ? Text.bad("Requested policy is falling back to Balanced; check computation supply.")
                        : Text.good("Broadcast policy is active."))));
        inv.setItem(33, GuiItems.item(Material.COMPASS, "Network Frequency " + matrix.networkFrequency(), NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.muted("Frequency changes are performed from Network Diagnostics."))));

        inv.setItem(DIAGNOSTICS_SLOT, GuiItems.item(Material.SPYGLASS, "Network Diagnostics", NamedTextColor.AQUA,
            GuiItems.lore(Text.accent("Inspect routes, telemetry, bottlenecks, and control coverage."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
