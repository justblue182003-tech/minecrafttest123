package dev.voidcore.ui;

import dev.voidcore.VoidCorePlugin;
import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.network.NetworkMetrics;
import dev.voidcore.network.NetworkService;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchNode;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

/** Server-scale commissioning dashboard for Project Nullstar. */
public final class ProjectTerminalMenu {
    public static final String MENU_ID = "machine:project_terminal";
    public static final int COMMISSION_SLOT = 31;
    public static final int NETWORK_SLOT = 33;
    public static final int CLOSE_SLOT = 53;

    private final VoidCorePlugin plugin;
    private final MachineService machines;
    private final NetworkService networks;
    private final ResearchService research;
    private final ExperimentService experiments;
    private final ItemService items;
    private final DiscoveryService discoveries;

    public ProjectTerminalMenu(VoidCorePlugin plugin, MachineService machines, NetworkService networks,
                               ResearchService research, ExperimentService experiments, ItemService items, DiscoveryService discoveries) {
        this.plugin = plugin;
        this.machines = machines;
        this.networks = networks;
        this.research = research;
        this.experiments = experiments;
        this.items = items;
        this.discoveries = discoveries;
    }

    public void open(Player player, MachineInstance terminal) {
        if (terminal == null || terminal.type() != MachineType.PROJECT_TERMINAL) return;
        MachineMenuHolder holder = new MachineMenuHolder(terminal.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Project Nullstar"));
        holder.attach(inv); render(inv, player, terminal); player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance terminal = machines.get(holder.machineLocation());
            if (terminal == null || terminal.type() != MachineType.PROJECT_TERMINAL) player.closeInventory();
            else render(top, player, terminal);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().equals(MENU_ID)
                && sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    public CommissionResult commission(Player player, MachineInstance terminal) {
        if (terminal == null || terminal.type() != MachineType.PROJECT_TERMINAL) return CommissionResult.NOT_READY;
        if (!research.isUnlocked(player, ResearchNode.DIMENSIONAL_INFRASTRUCTURE)) return CommissionResult.RESEARCH_LOCKED;
        if (!requirements(terminal).ready()) return CommissionResult.NOT_READY;
        if (experiments.isComplete(player, ResearchExperiment.PROJECT_NULLSTAR)) return CommissionResult.ALREADY_COMMISSIONED;
        experiments.advance(player, ResearchExperiment.PROJECT_NULLSTAR);
        discoveries.discover(player, CustomItem.ASCENDANT_CORE);
        ItemStack reward = items.createWithQuality(CustomItem.ASCENDANT_CORE, 1, 100);
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(reward);
        overflow.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
        return CommissionResult.COMMISSIONED;
    }

    public enum CommissionResult { COMMISSIONED, ALREADY_COMMISSIONED, RESEARCH_LOCKED, NOT_READY }

    private void render(Inventory inv, Player player, MachineInstance terminal) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        Requirements req = requirements(terminal);
        inv.setItem(4, GuiItems.item(Material.ENCHANTING_TABLE, "Project Nullstar", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("A server-scale engineering objective spanning production, containment, and dimensional infrastructure."),
                Text.muted("The objective is non-consumptive: it verifies infrastructure instead of deleting months of factory output."))));

        inv.setItem(10, requirement(Material.CLOCK, "Industrial History", req.cyclesReady,
            "Server production cycles: " + req.cycles + " / " + req.requiredCycles));
        inv.setItem(12, requirement(CustomItem.COMPRESSED_VOID_SEED.material(), "Singularity Refinement", req.seedsReady,
            "Compressed Void Seeds produced: " + req.seeds + " / " + req.requiredSeeds));
        inv.setItem(14, requirement(CustomItem.DIMENSIONAL_KERNEL.material(), "Dimensional Kernel", req.kernelReady,
            "Dimensional Kernels produced: " + req.kernels + " / " + req.requiredKernels));
        inv.setItem(16, requirement(Material.LODESTONE, "Dimensional Infrastructure", req.anchorsReady,
            "Loaded anchor worlds: " + req.anchorWorlds + " / " + req.requiredAnchorWorlds));
        inv.setItem(20, requirement(Material.CRYING_OBSIDIAN, "Stable Void Core", req.coreReady,
            req.coreReady ? "A complete Void Core is stable at ≥85% field." : "Requires one complete, non-faulted Void Core at ≥85% field."));
        inv.setItem(24, requirement(Material.ENDER_EYE, "Cross-Dimensional Phase Graph", req.networkReady,
            req.networkReady ? "This Project Terminal resolves a dimensional Phase topology." : "Connect this terminal to a graph spanning at least two dimensions."));

        boolean already = experiments.isComplete(player, ResearchExperiment.PROJECT_NULLSTAR);
        boolean researchReady = research.isUnlocked(player, ResearchNode.DIMENSIONAL_INFRASTRUCTURE);
        Material commissionIcon = already ? Material.BEACON : req.ready() && researchReady ? Material.NETHER_STAR : Material.GRAY_DYE;
        NamedTextColor commissionColor = already ? NamedTextColor.GREEN : req.ready() && researchReady ? NamedTextColor.GOLD : NamedTextColor.GRAY;
        inv.setItem(COMMISSION_SLOT, GuiItems.item(commissionIcon, already ? "Nullstar Commissioned" : "Commission Project Nullstar", commissionColor,
            GuiItems.lore(already ? Text.good("✓ This player has completed the commissioning objective.")
                    : req.ready() && researchReady ? Text.accent("Click to commission and receive the Ascendant Core.")
                    : Text.bad("All infrastructure milestones and Dimensional Infrastructure research are required."),
                Text.muted("Completion awards the Project Nullstar experiment and gates Ascendant Engineering."))));

        NetworkMetrics metrics = networks.metricsAt(terminal.location());
        inv.setItem(NETWORK_SLOT, GuiItems.item(Material.COMPARATOR, "Operations Snapshot", NamedTextColor.AQUA,
            metrics == null ? GuiItems.lore(Text.bad("No Phase network resolved."))
                : GuiItems.lore(Text.lore("Network: " + metrics.id()), Text.lore("Endpoints: " + metrics.endpointCount()),
                    Text.lore("Dimensions linked: " + (metrics.crossDimensional() ? "YES" : "NO")),
                    Text.lore("Lifetime network items: " + metrics.lifetimeItemsProduced()), Text.lore("Incidents recorded: " + metrics.lifetimeIncidents()))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private org.bukkit.inventory.ItemStack requirement(Material icon, String name, boolean ready, String detail) {
        return GuiItems.item(icon, name, ready ? NamedTextColor.GREEN : NamedTextColor.RED,
            GuiItems.lore(Text.lore(detail), ready ? Text.good("✓ Requirement satisfied") : Text.bad("✗ Requirement incomplete")));
    }

    private Requirements requirements(MachineInstance terminal) {
        Map<String, Long> ledger = machines.serverProductionLedger();
        long cycles = machines.serverLifetimeCycles();
        long seeds = ledger.getOrDefault(CustomItem.COMPRESSED_VOID_SEED.id(), 0L);
        long kernels = ledger.getOrDefault(CustomItem.DIMENSIONAL_KERNEL.id(), 0L);
        int anchorWorlds = machines.dimensionalAnchorWorldCount();
        long requiredCycles = Math.max(1, plugin.getConfig().getLong("endgame.project-nullstar.required-cycles", 500L));
        long requiredSeeds = Math.max(1, plugin.getConfig().getLong("endgame.project-nullstar.required-compressed-seeds", 3L));
        long requiredKernels = Math.max(1, plugin.getConfig().getLong("endgame.project-nullstar.required-dimensional-kernels", 1L));
        int requiredAnchorWorlds = Math.max(2, plugin.getConfig().getInt("endgame.project-nullstar.required-anchor-worlds", 2));
        boolean coreReady = machines.all().stream().anyMatch(machine -> machine.type() == MachineType.VOID_CORE
            && machines.structureStatus(machine).valid() && machine.fieldStability() >= 85.0 && !machine.faulted());
        NetworkMetrics metrics = networks.metricsAt(terminal.location());
        boolean networkReady = metrics != null && metrics.crossDimensional() && metrics.dimensionalAnchors() >= 2;
        return new Requirements(cycles, seeds, kernels, anchorWorlds, requiredCycles, requiredSeeds, requiredKernels, requiredAnchorWorlds,
            cycles >= requiredCycles, seeds >= requiredSeeds, kernels >= requiredKernels, anchorWorlds >= requiredAnchorWorlds, coreReady, networkReady);
    }

    private record Requirements(long cycles, long seeds, long kernels, int anchorWorlds,
                                long requiredCycles, long requiredSeeds, long requiredKernels, int requiredAnchorWorlds,
                                boolean cyclesReady, boolean seedsReady, boolean kernelReady, boolean anchorsReady,
                                boolean coreReady, boolean networkReady) {
        boolean ready() { return cyclesReady && seedsReady && kernelReady && anchorsReady && coreReady && networkReady; }
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
