package dev.voidcore.ui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public class MenuHolder implements InventoryHolder {
    private Inventory inventory;
    private final String menuId;

    public MenuHolder(String menuId) {
        this.menuId = menuId;
    }

    public String menuId() { return menuId; }

    public void attach(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        if (inventory == null) throw new IllegalStateException("Menu inventory not attached yet");
        return inventory;
    }
}
