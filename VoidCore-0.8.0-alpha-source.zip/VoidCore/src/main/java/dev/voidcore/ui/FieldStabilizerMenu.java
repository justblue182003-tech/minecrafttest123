package dev.voidcore.ui;

import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.Locale;

public final class FieldStabilizerMenu {
    public static final String MENU_ID = "machine:field_stabilizer";
    public static final int CLOSE_SLOT = 53;
    private final MachineService machines;

    public FieldStabilizerMenu(MachineService machines) { this.machines = machines; }

    public void open(Player player, MachineInstance machine) {
        if (machine == null || machine.type() != MachineType.FIELD_STABILIZER) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inventory = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Field Stabilizer"));
        holder.attach(inventory);
        render(inventory, machine);
        player.openInventory(inventory);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null || machine.type() != MachineType.FIELD_STABILIZER) player.closeInventory();
            else render(top, machine);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.LODESTONE, "Field Stabilizer", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Quality: " + machine.quality() + "/100"),
                Text.muted("Projects coherence into nearby machinery while powered."))));
        inv.setItem(20, GuiItems.item(Material.REDSTONE, "Flux Buffer", NamedTextColor.RED,
            GuiItems.lore(Text.lore(machine.flux() + " / " + machines.maxFlux(machine.type()) + " Flux"),
                machine.flux() > 0 ? Text.good("Field emitter energized") : Text.bad("No Flux: spatial contribution offline"))));
        inv.setItem(22, GuiItems.item(Material.AMETHYST_BLOCK, "Local Field", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Measured stability: %.1f%%", machine.fieldStability())),
                Text.muted("This measurement includes nearby stabilizers, entropy-heavy equipment, observers, and active control policy."))));
        inv.setItem(24, GuiItems.item(Material.SCULK, "Entropy / Wear", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Entropy: %.1f / %.1f", machine.entropy(), machines.entropyCapacity(machine.type()))),
                Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", machine.wear())))));
        inv.setItem(31, GuiItems.item(Material.ENDER_EYE, "Field Radius", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Effective radius: 12 blocks"),
                Text.muted("Overlapping stabilizers add together with distance falloff."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
