package dev.voidcore.ui;

import dev.voidcore.item.ItemService;
import dev.voidcore.recipe.RecipeIngredient;
import dev.voidcore.recipe.RecipeRegistry;
import dev.voidcore.recipe.RecipeStation;
import dev.voidcore.recipe.VoidRecipe;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class RecipeBrowserMenu {
    public static final int BACK_SLOT = 49;
    public static final int PREVIOUS_SLOT = 45;
    public static final int NEXT_SLOT = 53;
    private static final int[] CONTENT_SLOTS = {
        10,11,12,13,14,15,16,
        19,20,21,22,23,24,25,
        28,29,30,31,32,33,34,
        37,38,39,40,41,42,43
    };

    private final RecipeRegistry recipes;
    private final ItemService items;
    private final ResearchService research;

    public RecipeBrowserMenu(RecipeRegistry recipes, ItemService items, ResearchService research) {
        this.recipes = recipes;
        this.items = items;
        this.research = research;
    }

    public void open(Player player) {
        open(player, 0);
    }

    public void open(Player player, int requestedPage) {
        int pages = Math.max(1, (int) Math.ceil(recipes.all().size() / (double) CONTENT_SLOTS.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        MenuHolder holder = new MenuHolder("recipes:" + page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Recipe Browser"));
        holder.attach(inv);
        fill(inv);

        inv.setItem(4, GuiItems.item(Material.KNOWLEDGE_BOOK, "Recipe Browser", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Every VoidCore process uses this canonical registry."),
                Text.muted("Locked recipes remain visible so progression is understandable."))));

        int start = page * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            int index = start + i;
            if (index >= recipes.all().size()) break;
            inv.setItem(CONTENT_SLOTS[i], recipeItem(player, recipes.all().get(index)));
        }

        if (page > 0) inv.setItem(PREVIOUS_SLOT, GuiItems.item(Material.ARROW, "Previous Page", NamedTextColor.GRAY, List.of()));
        if (page + 1 < pages) inv.setItem(NEXT_SLOT, GuiItems.item(Material.ARROW, "Next Page", NamedTextColor.GRAY, List.of()));
        inv.setItem(BACK_SLOT, GuiItems.item(Material.BARRIER, "Back", NamedTextColor.GRAY, GuiItems.lore(Text.muted("Return to the Codex."))));
        player.openInventory(inv);
    }

    public void openDetail(Player player, VoidRecipe recipe, int returnPage) {
        MenuHolder holder = new MenuHolder("recipe-detail:" + recipe.id() + ":" + Math.max(0, returnPage));
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • " + recipe.output().displayName()));
        holder.attach(inv);
        fill(inv);

        ItemStack output = items.create(recipe.output(), recipe.outputAmount());
        ItemMeta outputMeta = output.getItemMeta();
        List<Component> outputLore = outputMeta.lore() == null ? new ArrayList<>() : new ArrayList<>(outputMeta.lore());
        outputLore.add(Component.empty());
        outputLore.add(Text.lore("Output: " + recipe.outputAmount() + "x"));
        outputLore.add(Text.lore("Station: " + recipe.station().displayName()));
        if (recipe.research() != null) {
            outputLore.add(Text.lore("Research: " + recipe.research().displayName()));
            if (!research.isUnlocked(player, recipe.research())) outputLore.add(Text.bad("✗ Research locked"));
        }
        outputMeta.lore(outputLore);
        output.setItemMeta(outputMeta);
        inv.setItem(13, output);

        inv.setItem(22, GuiItems.item(stationIcon(recipe.station()), recipe.station().displayName(), NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore(recipe.description()))));

        int[] ingredientSlots = {29,30,31,32,33,38,39,40,41,42};
        for (int i = 0; i < recipe.ingredients().size() && i < ingredientSlots.length; i++) {
            inv.setItem(ingredientSlots[i], ingredientItem(recipe.ingredients().get(i)));
        }
        inv.setItem(BACK_SLOT, GuiItems.item(Material.ARROW, "Back to Recipes", NamedTextColor.GRAY, List.of()));
        player.openInventory(inv);
    }

    public VoidRecipe recipeAt(MenuHolder holder, int slot) {
        if (!holder.menuId().startsWith("recipes:")) return null;
        int page = page(holder);
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            if (CONTENT_SLOTS[i] != slot) continue;
            int index = page * CONTENT_SLOTS.length + i;
            return index >= 0 && index < recipes.all().size() ? recipes.all().get(index) : null;
        }
        return null;
    }

    public VoidRecipe detailRecipe(MenuHolder holder) {
        if (!holder.menuId().startsWith("recipe-detail:")) return null;
        String[] parts = holder.menuId().split(":", 3);
        return parts.length >= 2 ? recipes.byId(parts[1]) : null;
    }

    public int detailReturnPage(MenuHolder holder) {
        if (!holder.menuId().startsWith("recipe-detail:")) return 0;
        String[] parts = holder.menuId().split(":", 3);
        if (parts.length < 3) return 0;
        try { return Math.max(0, Integer.parseInt(parts[2])); }
        catch (NumberFormatException ignored) { return 0; }
    }

    public int page(MenuHolder holder) {
        if (!holder.menuId().startsWith("recipes:")) return 0;
        try { return Math.max(0, Integer.parseInt(holder.menuId().substring("recipes:".length()))); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private ItemStack recipeItem(Player player, VoidRecipe recipe) {
        ItemStack stack = items.create(recipe.output(), recipe.outputAmount());
        ItemMeta meta = stack.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Component.empty());
        lore.add(Text.lore("Station: " + recipe.station().displayName()));
        if (recipe.research() != null) {
            boolean unlocked = research.isUnlocked(player, recipe.research());
            lore.add(unlocked ? Text.good("✓ " + recipe.research().displayName()) : Text.bad("✗ " + recipe.research().displayName()));
        }
        lore.add(Text.accent("Click for recipe details"));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack ingredientItem(RecipeIngredient ingredient) {
        if (ingredient.customItem() != null) {
            ItemStack stack = items.create(ingredient.customItem(), ingredient.amount());
            ItemMeta meta = stack.getItemMeta();
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.add(Component.empty());
            lore.add(Text.lore("Required: " + ingredient.amount()));
            meta.lore(lore);
            stack.setItemMeta(meta);
            return stack;
        }
        return GuiItems.item(ingredient.material(), ingredient.amount() + "x " + ingredient.displayName(), NamedTextColor.AQUA,
            GuiItems.lore(Text.muted("Vanilla material")));
    }

    private Material stationIcon(RecipeStation station) {
        return switch (station) {
            case VANILLA_CRAFTING -> Material.CRAFTING_TABLE;
            case PROTOTYPE_BENCH -> Material.SMITHING_TABLE;
            case FLUX_CRUCIBLE -> Material.BLAST_FURNACE;
            case SPECTRUM_ANALYZER -> Material.SPYGLASS;
            case INDUCTION_HEATER -> Material.BLAST_FURNACE;
            case CATALYTIC_REACTOR -> Material.BREWING_STAND;
            case MATRIX_PURIFIER -> Material.CAULDRON;
            case CRYOGENIC_COLUMN -> Material.PACKED_ICE;
            case PRESSURE_VESSEL -> Material.HEAVY_WEIGHTED_PRESSURE_PLATE;
            case ENTROPY_CONDENSER -> Material.BEACON;
            case VOID_CORE -> Material.CRYING_OBSIDIAN;
            case PROJECT_NULLSTAR -> Material.ENCHANTING_TABLE;
        };
    }

    private void fill(Inventory inv) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
    }
}
