package dev.voidcore.ui;

import dev.voidcore.item.ItemService;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineType;
import dev.voidcore.recipe.RecipeCraftingService;
import dev.voidcore.recipe.RecipeRegistry;
import dev.voidcore.recipe.RecipeStation;
import dev.voidcore.recipe.VoidRecipe;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class PrototypeBenchMenu {
    public static final int PREVIOUS_SLOT = 45;
    public static final int CLOSE_SLOT = 49;
    public static final int NEXT_SLOT = 53;
    private static final String PREFIX = "machine:prototype_bench:";
    private static final int[] CONTENT_SLOTS = {
        10,11,12,13,14,15,16,
        19,20,21,22,23,24,25,
        28,29,30,31,32,33,34,
        37,38,39,40,41,42,43
    };

    private final RecipeRegistry recipes;
    private final RecipeCraftingService crafting;
    private final ItemService items;
    private final ResearchService research;

    public PrototypeBenchMenu(RecipeRegistry recipes, RecipeCraftingService crafting, ItemService items, ResearchService research) {
        this.recipes = recipes;
        this.crafting = crafting;
        this.items = items;
        this.research = research;
    }

    public void open(Player player, MachineInstance machine) {
        open(player, machine, 0);
    }

    public void open(Player player, MachineInstance machine, int requestedPage) {
        if (machine.type() != MachineType.PROTOTYPE_BENCH) return;
        List<VoidRecipe> bench = recipes.forStation(RecipeStation.PROTOTYPE_BENCH);
        int pages = Math.max(1, (int) Math.ceil(bench.size() / (double) CONTENT_SLOTS.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));

        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), PREFIX + page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Prototype Bench"));
        holder.attach(inv);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));

        inv.setItem(4, GuiItems.item(Material.SMITHING_TABLE, "Prototype Bench", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Controlled fabrication from your inventory."),
                Text.muted("Quality-bearing hardware inherits input quality."),
                Text.muted("Click: craft one • Shift-click: batch up to 16"))));

        int start = page * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            int index = start + i;
            if (index >= bench.size()) break;
            inv.setItem(CONTENT_SLOTS[i], recipeItem(player, bench.get(index)));
        }

        if (page > 0) inv.setItem(PREVIOUS_SLOT, GuiItems.item(Material.ARROW, "Previous Page", NamedTextColor.GRAY, List.of()));
        if (page + 1 < pages) inv.setItem(NEXT_SLOT, GuiItems.item(Material.ARROW, "Next Page", NamedTextColor.GRAY, List.of()));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
        player.openInventory(inv);
    }

    public VoidRecipe recipeAt(MachineMenuHolder holder, int slot) {
        if (!holder.menuId().startsWith(PREFIX)) return null;
        List<VoidRecipe> bench = recipes.forStation(RecipeStation.PROTOTYPE_BENCH);
        int page = page(holder);
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            if (CONTENT_SLOTS[i] != slot) continue;
            int index = page * CONTENT_SLOTS.length + i;
            return index >= 0 && index < bench.size() ? bench.get(index) : null;
        }
        return null;
    }

    public int page(MachineMenuHolder holder) {
        if (!holder.menuId().startsWith(PREFIX)) return 0;
        try { return Math.max(0, Integer.parseInt(holder.menuId().substring(PREFIX.length()))); }
        catch (NumberFormatException ignored) { return 0; }
    }

    public boolean isPrototypeMenu(MenuHolder holder) {
        return holder.menuId().startsWith(PREFIX);
    }

    private ItemStack recipeItem(Player player, VoidRecipe recipe) {
        ItemStack stack = items.create(recipe.output(), recipe.outputAmount());
        ItemMeta meta = stack.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Component.empty());
        boolean unlocked = recipe.research() == null || research.isUnlocked(player, recipe.research());
        boolean craftable = crafting.canCraft(player, recipe);
        lore.add(unlocked ? Text.good("✓ Research available") : Text.bad("✗ Requires " + recipe.research().displayName()));
        for (var ingredient : recipe.ingredients()) {
            int have = crafting.count(player, ingredient);
            lore.add((have >= ingredient.amount() ? Text.lore("✓ ") : Text.bad("✗ "))
                .append(Component.text(ingredient.displayName() + " " + have + "/" + ingredient.amount(), NamedTextColor.GRAY)));
        }
        if (recipe.output().category() == dev.voidcore.item.CustomItem.Category.COMPONENT
            || recipe.output().category() == dev.voidcore.item.CustomItem.Category.UPGRADE
            || recipe.output().category() == dev.voidcore.item.CustomItem.Category.MACHINE) {
            lore.add(Text.muted("Output receives a persistent engineering-quality score."));
        }
        lore.add(Component.empty());
        lore.add(craftable ? Text.accent("Click to assemble") : Text.muted("Missing requirements"));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(craftable);
        stack.setItemMeta(meta);
        return stack;
    }
}
