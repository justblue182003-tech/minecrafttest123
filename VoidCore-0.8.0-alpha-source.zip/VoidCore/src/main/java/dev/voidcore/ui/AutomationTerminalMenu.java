package dev.voidcore.ui;

import dev.voidcore.machine.AutomationRule;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.network.NetworkMetrics;
import dev.voidcore.network.NetworkService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

/** Remote automation dashboard and signal transmitter. */
public final class AutomationTerminalMenu {
    public static final String MENU_ID = "machine:automation_terminal";
    public static final int RULE_SLOT = 13;
    public static final int GROUP_SLOT = 20;
    public static final int CHANNEL_SLOT = 22;
    public static final int SIGNAL_SLOT = 24;
    public static final int DIAGNOSTICS_SLOT = 31;
    public static final int PRODUCTION_SLOT = 33;
    public static final int CLOSE_SLOT = 53;

    private final MachineService machines;
    private final NetworkService networks;

    public AutomationTerminalMenu(MachineService machines, NetworkService networks) {
        this.machines = machines;
        this.networks = networks;
    }

    public void open(Player player, MachineInstance terminal) {
        if (terminal == null || terminal.type() != MachineType.AUTOMATION_TERMINAL) return;
        MachineMenuHolder holder = new MachineMenuHolder(terminal.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Automation Terminal"));
        holder.attach(inv);
        render(inv, terminal);
        player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance terminal = machines.get(holder.machineLocation());
            if (terminal == null || terminal.type() != MachineType.AUTOMATION_TERMINAL) player.closeInventory();
            else render(top, terminal);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().equals(MENU_ID)
                && sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance terminal) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        NetworkMetrics metrics = networks.metricsAt(terminal.location());
        AutomationRule rule = terminal.automationRule();
        inv.setItem(4, GuiItems.item(Material.LECTERN, "Automation Terminal", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Address: " + machines.networkAddress(terminal)),
                Text.muted("Evaluates a factory condition and broadcasts one boolean signal over its physical Phase network."))));
        inv.setItem(RULE_SLOT, GuiItems.item(rule.icon(), rule.displayName(), NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore(rule.description()), Text.accent("Click: next rule • Right-click: previous"))));
        inv.setItem(GROUP_SLOT, GuiItems.item(Material.NAME_TAG, "Factory Group G" + terminal.automationGroup(), NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Only machines assigned to G" + terminal.automationGroup() + " are evaluated by this rule."),
                Text.accent("Click: next group • Right-click: previous"))));
        inv.setItem(CHANNEL_SLOT, GuiItems.item(Material.REDSTONE_TORCH, "Signal Channel CH" + terminal.signalChannel(), NamedTextColor.RED,
            GuiItems.lore(Text.lore("The resolved rule drives CH" + terminal.signalChannel() + " across this network."),
                Text.accent("Click: next channel • Right-click: previous"))));
        boolean high = terminal.signalHigh();
        inv.setItem(SIGNAL_SLOT, GuiItems.item(high ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
            high ? "Signal HIGH" : "Signal LOW", high ? NamedTextColor.GREEN : NamedTextColor.RED,
            GuiItems.lore(Text.lore("Rule: " + rule.displayName()),
                Text.lore("Compute: " + terminal.computation() + " / " + machines.computationCapacity(terminal.type())),
                rule == AutomationRule.ALWAYS ? Text.muted("Always High does not require computation.") : Text.muted("Conditional evaluation consumes routed computation when active."))));

        if (metrics == null) {
            inv.setItem(DIAGNOSTICS_SLOT, GuiItems.item(Material.BARRIER, "No Resolved Network", NamedTextColor.RED,
                GuiItems.lore(Text.bad("Attach this terminal directly to a Phase network."))));
        } else {
            inv.setItem(DIAGNOSTICS_SLOT, GuiItems.item(Material.COMPARATOR, "Remote Network Dashboard", NamedTextColor.AQUA,
                GuiItems.lore(Text.lore("Network: " + metrics.id()), Text.lore("Endpoints: " + metrics.endpointCount()),
                    Text.lore("High channels: " + metrics.highSignalChannels()), Text.lore("Gated endpoints: " + metrics.gatedEndpoints()),
                    metrics.crossDimensional() ? Text.accent("Cross-dimensional topology active") : Text.muted("Single-dimensional topology"),
                    Text.accent("Click for full diagnostics"))));
        }
        var ledger = machines.serverProductionLedger();
        long total = ledger.values().stream().mapToLong(Long::longValue).sum();
        inv.setItem(PRODUCTION_SLOT, GuiItems.item(Material.CLOCK, "Factory Production Ledger", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Tracked produced items: " + total), Text.lore("Distinct outputs: " + ledger.size()),
                Text.lore("Server cycles: " + machines.serverLifetimeCycles()), Text.muted("Individual machine diagnostics show exact per-item ledgers."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
