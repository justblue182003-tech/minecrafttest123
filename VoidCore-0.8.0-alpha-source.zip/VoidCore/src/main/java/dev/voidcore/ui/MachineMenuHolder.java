package dev.voidcore.ui;

import org.bukkit.Location;

public final class MachineMenuHolder extends MenuHolder {
    private final Location machineLocation;

    public MachineMenuHolder(Location machineLocation) {
        this(machineLocation, "machine:flux_crucible");
    }

    public MachineMenuHolder(Location machineLocation, String menuId) {
        super(menuId);
        this.machineLocation = machineLocation.clone();
    }

    public Location machineLocation() {
        return machineLocation.clone();
    }
}
