package dev.voidcore.ui;

import dev.voidcore.item.CustomItem;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class LogisticsNodeMenu {
    public static final String MENU_ID = "network:node";
    public static final int FILTER_SLOT = 20;
    public static final int BUFFER_SLOT = 22;
    public static final int PRIORITY_DOWN_SLOT = 23;
    public static final int PRIORITY_SLOT = 24;
    public static final int PRIORITY_UP_SLOT = 25;
    public static final int FREQ_DOWN_SLOT = 37;
    public static final int FREQ_SLOT = 38;
    public static final int FREQ_UP_SLOT = 39;
    public static final int SECONDARY_DOWN_SLOT = 41;
    public static final int SECONDARY_SLOT = 42;
    public static final int SECONDARY_UP_SLOT = 43;
    public static final int DIAGNOSTICS_SLOT = 49;
    public static final int CLOSE_SLOT = 53;

    private final MachineService machines;

    public LogisticsNodeMenu(MachineService machines) { this.machines = machines; }

    public void open(Player player, MachineInstance node) {
        if (node == null || !node.type().isConfigurableLogisticsNode()) return;
        MachineMenuHolder holder = new MachineMenuHolder(node.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • " + node.type().displayName()));
        holder.attach(inv);
        render(inv, node);
        player.openInventory(inv);
    }

    public void sync(Inventory inv, MachineMenuHolder holder) {
        MachineInstance node = machines.get(holder.machineLocation());
        if (node == null || node.type() != MachineType.PRIORITY_BUFFER) return;
        node.output(normalize(inv.getItem(BUFFER_SLOT)));
        machines.markDirty();
    }

    public void syncOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().equals(MENU_ID)) sync(top, holder);
        }
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance node = machines.get(holder.machineLocation());
            if (node == null || !node.type().isConfigurableLogisticsNode()) player.closeInventory();
            else render(top, node);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) { sync(top, holder); player.closeInventory(); }
        }
    }

    private void render(Inventory inv, MachineInstance node) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(node.type().item().material(), node.type().displayName(), NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Address: " + machines.networkAddress(node)),
                Text.muted("Routing policy is physical: attached endpoints inherit policy from adjacent Phase Routers."))));

        CustomItem filter = machines.routingFilter(node);
        inv.setItem(FILTER_SLOT, GuiItems.item(filter == null ? Material.HOPPER : filter.material(), "Material Filter", NamedTextColor.AQUA,
            GuiItems.lore(filter == null ? Text.good("Any VoidCore material") : Text.lore("Only: " + filter.displayName()),
                Text.muted("Left-click while holding a VoidCore item to copy its signature."), Text.muted("Right-click to clear."))));

        if (node.type() == MachineType.PRIORITY_BUFFER) {
            inv.setItem(13, GuiItems.item(Material.CHEST, "Staging Buffer", NamedTextColor.GOLD,
                GuiItems.lore(Text.lore("Routed items can be staged here and re-emitted on later network passes."))));
            inv.setItem(BUFFER_SLOT, node.output());
        } else {
            inv.setItem(BUFFER_SLOT, GuiItems.item(Material.GRAY_STAINED_GLASS_PANE, "No Storage", NamedTextColor.DARK_GRAY,
                GuiItems.lore(Text.muted("This logistics node does not store routed items."))));
        }

        inv.setItem(PRIORITY_DOWN_SLOT, GuiItems.item(Material.RED_DYE, "Priority −1", NamedTextColor.RED, List.of()));
        inv.setItem(PRIORITY_SLOT, GuiItems.item(Material.COMPARATOR, "Priority " + node.routingPriority(), NamedTextColor.GOLD,
            GuiItems.lore(Text.muted("9 is preferred; ties choose the shorter cached route."))));
        inv.setItem(PRIORITY_UP_SLOT, GuiItems.item(Material.LIME_DYE, "Priority +1", NamedTextColor.GREEN, List.of()));

        inv.setItem(FREQ_DOWN_SLOT, GuiItems.item(Material.PURPLE_DYE, "Primary Frequency −1", NamedTextColor.LIGHT_PURPLE, List.of()));
        inv.setItem(FREQ_SLOT, GuiItems.item(Material.COMPASS, "Primary " + node.networkFrequency(), NamedTextColor.GOLD, List.of()));
        inv.setItem(FREQ_UP_SLOT, GuiItems.item(Material.MAGENTA_DYE, "Primary Frequency +1", NamedTextColor.LIGHT_PURPLE, List.of()));

        if (node.type() == MachineType.FREQUENCY_SPLITTER) {
            inv.setItem(SECONDARY_DOWN_SLOT, GuiItems.item(Material.CYAN_DYE, "Secondary Frequency −1", NamedTextColor.AQUA, List.of()));
            inv.setItem(SECONDARY_SLOT, GuiItems.item(Material.RECOVERY_COMPASS, "Secondary " + node.secondaryNetworkFrequency(), NamedTextColor.AQUA,
                GuiItems.lore(Text.muted("The splitter is simultaneously a member of both domains."))));
            inv.setItem(SECONDARY_UP_SLOT, GuiItems.item(Material.LIGHT_BLUE_DYE, "Secondary Frequency +1", NamedTextColor.AQUA, List.of()));
        }

        inv.setItem(DIAGNOSTICS_SLOT, GuiItems.item(Material.SPYGLASS, "Network Diagnostics", NamedTextColor.AQUA,
            GuiItems.lore(Text.accent("Open the live graph, transfer counters, cache health, and route trace."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private ItemStack normalize(ItemStack stack) { return stack == null || stack.getType().isAir() ? null : stack.clone(); }
    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
