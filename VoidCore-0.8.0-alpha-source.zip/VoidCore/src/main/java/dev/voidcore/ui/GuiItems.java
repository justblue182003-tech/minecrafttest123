package dev.voidcore.ui;

import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class GuiItems {
    private GuiItems() {}

    public static ItemStack item(Material material, String name, NamedTextColor color, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.name(name, color));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack filler(Material material) {
        return item(material, " ", NamedTextColor.DARK_GRAY, List.of());
    }

    public static List<Component> lore(Component... lines) {
        List<Component> result = new ArrayList<>();
        java.util.Collections.addAll(result, lines);
        return result;
    }
}
