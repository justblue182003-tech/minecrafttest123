package dev.voidcore.ui;

import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

/** Universal signal assignment panel, opened with a Signal Crystal while sneaking. */
public final class AutomationConfigMenu {
    public static final String MENU_ID = "machine:automation_config";
    public static final int GROUP_SLOT = 20;
    public static final int CHANNEL_SLOT = 22;
    public static final int GATE_SLOT = 24;
    public static final int CLOSE_SLOT = 53;
    private final MachineService machines;

    public AutomationConfigMenu(MachineService machines) { this.machines = machines; }

    public void open(Player player, MachineInstance machine) {
        if (machine == null) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Signal Configuration"));
        holder.attach(inv); render(inv, machine); player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null) player.closeInventory(); else render(top, machine);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().equals(MENU_ID)
                && sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.COMPARATOR, machine.type().displayName() + " • Signal Configuration", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Address: " + machines.networkAddress(machine)),
                Text.muted("Sneak-right-click a VoidCore machine with a Signal Crystal to reopen this panel."))));
        inv.setItem(GROUP_SLOT, GuiItems.item(Material.NAME_TAG, "Factory Group G" + machine.automationGroup(), NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Automation Terminals evaluate endpoints sharing this group."), Text.accent("Click: next • Right-click: previous"))));
        inv.setItem(CHANNEL_SLOT, GuiItems.item(Material.REDSTONE_TORCH, "Signal Channel CH" + machine.signalChannel(), NamedTextColor.RED,
            GuiItems.lore(Text.lore("Current resolved state: " + (machine.signalHigh() ? "HIGH" : "LOW")), Text.accent("Click: next • Right-click: previous"))));
        inv.setItem(GATE_SLOT, GuiItems.item(machine.signalGate().icon(), machine.signalGate().displayName(), NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore(machine.signalGate().description()),
                machine.automationAllowsRun() ? Text.good("Current permission: RUN") : Text.bad("Current permission: HOLD"),
                Text.accent("Click: next gate • Right-click: previous"),
                Text.muted("Processing machines, observers, stabilizers, and upgrade chambers obey the gate; passive topology nodes expose it for monitoring."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
