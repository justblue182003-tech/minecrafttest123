package dev.voidcore.ui;

import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

public final class CodexMenu {
    public static final int RESEARCH_SLOT = 19;
    public static final int RECIPES_SLOT = 21;
    public static final int MATERIALS_SLOT = 23;
    public static final int MACHINES_SLOT = 25;
    public static final int EXPERIMENTS_SLOT = 31;
    public static final int PROFILE_SLOT = 40;

    private final ResearchService research;
    private final ExperimentService experiments;
    private final ItemService items;

    public CodexMenu(ResearchService research, ExperimentService experiments, ItemService items) {
        this.research = research;
        this.experiments = experiments;
        this.items = items;
    }

    public void open(Player player) {
        MenuHolder holder = new MenuHolder("codex");
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Codex"));
        holder.attach(inv);

        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));

        inv.setItem(4, items.create(CustomItem.VOID_CODEX));
        inv.setItem(RESEARCH_SLOT, GuiItems.item(Material.ENCHANTING_TABLE, "Research Matrix", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Unlock theories using Insight, prerequisites, and experiments."), Text.good("Click to inspect research."))));
        inv.setItem(RECIPES_SLOT, GuiItems.item(Material.KNOWLEDGE_BOOK, "Recipe Browser", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Canonical recipes for every current VoidCore process."), Text.good("Click to browse."))));
        inv.setItem(MATERIALS_SLOT, GuiItems.item(Material.AMETHYST_SHARD, "Material Index", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Catalogue fabricated and scanned resonance materials."), Text.good("Click to inspect discoveries."))));
        inv.setItem(MACHINES_SLOT, GuiItems.item(Material.CRAFTER, "Industrial Systems", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Machines, their research gates, and fabrication recipes."), Text.good("Click to inspect machines."))));
        inv.setItem(EXPERIMENTS_SLOT, GuiItems.item(Material.LECTERN, "Experiments", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore("Behavioral objectives that prove system mastery."), Text.good("Click to inspect objectives."))));

        long completed = java.util.Arrays.stream(ResearchExperiment.values()).filter(exp -> experiments.isComplete(player, exp)).count();
        inv.setItem(PROFILE_SLOT, GuiItems.item(Material.PLAYER_HEAD, "Research Profile", NamedTextColor.GREEN,
            List.of(
                Text.lore("Insight: " + research.insight(player)),
                Text.lore("Unlocked research: " + research.unlocked(player).size()),
                Text.lore("Completed experiments: " + completed + "/" + ResearchExperiment.values().length),
                Component.empty(),
                Text.muted("Progress is stored per player.")
            )));

        player.openInventory(inv);
    }
}
