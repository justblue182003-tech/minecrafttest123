package dev.voidcore.ui;

import dev.voidcore.item.ItemService;
import dev.voidcore.item.QualityGrade;
import dev.voidcore.item.UpgradeType;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.process.ProcessEngine;
import dev.voidcore.process.ProcessRecipe;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class EngineeringMachineMenu {
    public static final String MENU_PREFIX = "machine:engineering:";
    public static final int INPUT_SLOT = 19;
    public static final int SECONDARY_INPUT_SLOT = 20;
    public static final int CATALYST_SLOT = 21;
    public static final int STATUS_SLOT = 22;
    public static final int BYPRODUCT_SLOT = 24;
    public static final int OUTPUT_SLOT = 25;
    public static final int ENTROPY_SLOT = 27;
    public static final int COMPUTATION_SLOT = 28;
    public static final int HEAT_SLOT = 29;
    public static final int STRUCTURE_SLOT = 30;
    public static final int ENERGY_SLOT = 31;
    public static final int FUEL_SLOT = 33;
    public static final int DIAGNOSTICS_SLOT = 35;
    public static final int UPGRADE_1_SLOT = 46;
    public static final int UPGRADE_2_SLOT = 47;
    public static final int UPGRADE_3_SLOT = 48;
    public static final int PRESSURE_DOWN_SLOT = 41;
    public static final int PRESSURE_SLOT = 42;
    public static final int PRESSURE_UP_SLOT = 43;
    public static final int TARGET_DOWN_SLOT = 50;
    public static final int TARGET_SLOT = 51;
    public static final int TARGET_UP_SLOT = 52;
    public static final int CLOSE_SLOT = 53;
    public static final Set<Integer> UPGRADE_SLOTS = Set.of(UPGRADE_1_SLOT, UPGRADE_2_SLOT, UPGRADE_3_SLOT);
    private static final Set<Integer> CONTENT_SLOTS = Set.of(INPUT_SLOT, SECONDARY_INPUT_SLOT, CATALYST_SLOT,
        BYPRODUCT_SLOT, OUTPUT_SLOT, FUEL_SLOT, UPGRADE_1_SLOT, UPGRADE_2_SLOT, UPGRADE_3_SLOT);

    private final MachineService machines;
    private final ItemService items;

    public EngineeringMachineMenu(MachineService machines, ItemService items) {
        this.machines = machines;
        this.items = items;
    }

    public void open(Player player, MachineInstance machine) {
        if (!machine.type().isEngineeringProcessor()) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_PREFIX + machine.type().id());
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • " + machine.type().displayName()));
        holder.attach(inv);
        render(inv, machine);
        player.openInventory(inv);
    }

    public boolean isMenu(MenuHolder holder) {
        return holder instanceof MachineMenuHolder && holder.menuId().startsWith(MENU_PREFIX);
    }

    public void syncOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof MachineMenuHolder holder && holder.menuId().startsWith(MENU_PREFIX)) sync(top, holder);
        }
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().startsWith(MENU_PREFIX)) continue;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null || !machine.type().isEngineeringProcessor()) player.closeInventory();
            else render(top, machine);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().startsWith(MENU_PREFIX)) continue;
            if (!sameBlock(holder.machineLocation(), location)) continue;
            sync(top, holder);
            player.closeInventory();
        }
    }

    public void sync(Inventory inv, MachineMenuHolder holder) {
        if (!holder.menuId().startsWith(MENU_PREFIX)) return;
        MachineInstance machine = machines.get(holder.machineLocation());
        if (machine == null || !machine.type().isEngineeringProcessor()) return;
        machine.input(normalize(inv.getItem(INPUT_SLOT)));
        machine.secondaryInput(machines.supportsSecondaryInput(machine.type()) ? normalize(inv.getItem(SECONDARY_INPUT_SLOT)) : null);
        machine.catalyst(machines.supportsCatalyst(machine.type()) ? normalize(inv.getItem(CATALYST_SLOT)) : null);
        machine.fuel(normalize(inv.getItem(FUEL_SLOT)));
        machine.output(normalize(inv.getItem(OUTPUT_SLOT)));
        machine.byproduct(normalize(inv.getItem(BYPRODUCT_SLOT)));
        int[] slots = {UPGRADE_1_SLOT, UPGRADE_2_SLOT, UPGRADE_3_SLOT};
        for (int i = 0; i < machine.type().upgradeSlots() && i < slots.length; i++) machine.upgrade(i, normalize(inv.getItem(slots[i])));
        machines.markDirty();
    }

    public int upgradeIndex(int slot) {
        return switch (slot) {
            case UPGRADE_1_SLOT -> 0;
            case UPGRADE_2_SLOT -> 1;
            case UPGRADE_3_SLOT -> 2;
            default -> -1;
        };
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) {
            if (!CONTENT_SLOTS.contains(i)) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        }

        List<Component> titleLore = new ArrayList<>();
        titleLore.add(Text.lore("Engineering quality: " + machine.quality() + "/100 • " + QualityGrade.fromScore(machine.quality()).displayName()));
        titleLore.add(machine.hasFault()
            ? (machine.faulted() ? Text.bad("HARD FAULT: " + machine.fault().displayName()) : Text.accent("SOFT FAULT: " + machine.fault().displayName()))
            : machine.wear() >= 99.95
                ? Text.bad(String.format(Locale.ROOT, "Wear: %.1f%% • SERVICE LOCKOUT", machine.wear()))
                : Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", machine.wear())));
        titleLore.add(Text.muted("Use a Precision Maintenance Kit on the placed machine to restore service life."));
        inv.setItem(4, GuiItems.item(Material.CRAFTER, machine.type().displayName(), NamedTextColor.LIGHT_PURPLE, titleLore));

        inv.setItem(10, GuiItems.item(Material.HOPPER, "Primary Feed", NamedTextColor.AQUA,
            GuiItems.lore(Text.muted("The material that selects the process family."))));
        inv.setItem(11, GuiItems.item(Material.DROPPER, "Secondary Feed", NamedTextColor.AQUA,
            GuiItems.lore(Text.muted("Some advanced processes require a second independent feed."))));
        inv.setItem(12, GuiItems.item(Material.BREWING_STAND, "Catalyst", NamedTextColor.GOLD,
            GuiItems.lore(Text.muted("Reusable where required; contamination persists between cycles."))));
        inv.setItem(15, GuiItems.item(Material.COMPOSTER, "Byproduct", NamedTextColor.YELLOW,
            GuiItems.lore(Text.muted("Waste streams must be removed or the next cycle will block."))));
        inv.setItem(16, GuiItems.item(Material.CHEST, "Main Output", NamedTextColor.GREEN,
            GuiItems.lore(Text.muted("Completed quality-bearing output appears below."))));

        inv.setItem(INPUT_SLOT, machine.input());
        if (machines.supportsSecondaryInput(machine.type())) inv.setItem(SECONDARY_INPUT_SLOT, machine.secondaryInput());
        else inv.setItem(SECONDARY_INPUT_SLOT, disabled("No secondary feed port"));
        if (machines.supportsCatalyst(machine.type())) inv.setItem(CATALYST_SLOT, machine.catalyst());
        else inv.setItem(CATALYST_SLOT, disabled("No catalyst socket"));
        inv.setItem(BYPRODUCT_SLOT, machine.byproduct());
        inv.setItem(OUTPUT_SLOT, machine.output());
        inv.setItem(FUEL_SLOT, machine.fuel());

        for (int i = 0; i < 3; i++) {
            int slot = UPGRADE_1_SLOT + i;
            if (i < machine.type().upgradeSlots()) {
                inv.setItem(slot, machine.upgrade(i));
                inv.setItem(37 + i, GuiItems.item(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "Upgrade Socket " + (i + 1), NamedTextColor.GRAY,
                    GuiItems.lore(Text.muted("Insert one VoidCore upgrade module below."))));
            } else inv.setItem(slot, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        }

        ProcessRecipe recipe = machines.currentRecipe(machine);
        ProcessEngine.TickState state = machines.processState(machine);
        String processName = recipe == null ? "No process selected" : recipe.output().displayName();
        double duration = recipe == null ? 1.0 : recipe.durationSeconds();
        int percent = (int) Math.min(100.0, machine.progress() * 100.0 / duration);
        List<Component> statusLore = new ArrayList<>();
        statusLore.add(Text.lore("Process: " + processName));
        statusLore.add(Text.lore("Progress: " + percent + "%"));
        if (recipe != null) {
            statusLore.add(Text.lore("Projected quality: " + machines.projectedOutputQuality(machine) + "/100"));
            if (recipe.requiresSecondaryInput()) statusLore.add(Text.lore("Secondary: " + recipe.secondaryInputAmount() + "× " + recipe.secondaryInput().displayName()));
            if (recipe.hasByproduct()) statusLore.add(Text.accent("Byproduct: " + recipe.byproductAmount() + "× " + recipe.byproduct().displayName()));
            if (recipe.usesPressure()) statusLore.add(Text.lore(String.format(Locale.ROOT, "Pressure window: %.1f–%.1f bar", recipe.minimumPressure(), recipe.maximumPressure())));
            if (recipe.entropyGenerated() > 0.01) statusLore.add(Text.accent(String.format(Locale.ROOT, "Entropy generated: +%.1f", recipe.entropyGenerated())));
            if (recipe.entropyCost() > 0.01) statusLore.add(Text.lore(String.format(Locale.ROOT, "Entropy required: %.1f", recipe.entropyCost())));
            if (recipe.computationCost() > 0) statusLore.add(Text.lore("Computation required: " + recipe.computationCost()));
            if (recipe.environment().constrained()) statusLore.add(recipe.environment().matches(machine.location())
                ? Text.good("Environment: " + recipe.environment().displayName())
                : Text.bad("Environment required: " + recipe.environment().displayName()));
            if (recipe.requiresMultiblock()) statusLore.add(machine.structureValid() ? Text.good("Multiblock complete") : Text.bad("Multiblock incomplete"));
            if (recipe.usesSpatialField()) statusLore.add(machine.fieldStability() + 0.001 >= recipe.minimumFieldStability()
                ? Text.good(String.format(Locale.ROOT, "Field: %.1f%% / %.0f%%", machine.fieldStability(), recipe.minimumFieldStability()))
                : Text.bad(String.format(Locale.ROOT, "Field required: %.0f%% • current %.1f%%", recipe.minimumFieldStability(), machine.fieldStability())));
        }
        int candidates = machines.processCandidates(machine).size();
        if (candidates > 1) statusLore.add(Text.accent("Click to cycle " + candidates + " process definitions."));
        statusLore.add(stateHint(state));
        inv.setItem(STATUS_SLOT, GuiItems.item(statusMaterial(state), prettyState(state), statusColor(state), statusLore));

        double entropyCapacity = machines.entropyCapacity(machine.type());
        if (entropyCapacity > 0.0) {
            double ratio = machine.entropy() / Math.max(1.0, entropyCapacity);
            inv.setItem(ENTROPY_SLOT, GuiItems.item(ratio >= 0.85 ? Material.SCULK_CATALYST : Material.SCULK, "Entropy Load",
                ratio >= 0.85 ? NamedTextColor.RED : ratio >= 0.60 ? NamedTextColor.GOLD : NamedTextColor.AQUA,
                GuiItems.lore(Text.lore(String.format(Locale.ROOT, "%.1f / %.1f Entropy", machine.entropy(), entropyCapacity)),
                    ratio >= 0.85 ? Text.bad("Entropy saturation is critical") : ratio >= 0.60 ? Text.accent("Wear and coherence pressure increasing") : Text.good("Entropy load controlled"),
                    Text.muted("Connected condenser arrays can siphon entropy over Phase Logistics."))));
        }
        int computationCapacity = machines.computationCapacity(machine.type());
        if (computationCapacity > 0) {
            inv.setItem(COMPUTATION_SLOT, GuiItems.item(Material.DAYLIGHT_DETECTOR, "Computation Buffer", NamedTextColor.LIGHT_PURPLE,
                GuiItems.lore(Text.lore(machine.computation() + " / " + computationCapacity + " compute"),
                    Text.muted("Computation is generated by Phase Observers and routed across the physical network."))));
        }
        if (machine.type().isMultiblockController()) {
            var structure = machines.structureStatus(machine);
            boolean voidCore = machine.type() == MachineType.VOID_CORE;
            inv.setItem(STRUCTURE_SLOT, GuiItems.item(structure.valid() ? Material.BEACON : Material.RED_STAINED_GLASS_PANE,
                structure.valid() ? (voidCore ? "Void Lattice Complete" : "Array Geometry Complete") : (voidCore ? "Void Lattice Incomplete" : "Array Geometry Incomplete"),
                structure.valid() ? NamedTextColor.GREEN : NamedTextColor.RED,
                GuiItems.lore(Text.lore(structure.matched() + " / " + structure.required() + " structural positions valid"),
                    structure.valid() ? Text.good(voidCore ? "Spatial containment lattice commissioned" : "Industrial process chamber commissioned") : Text.bad(structure.firstProblem()),
                    voidCore ? Text.muted("5×5 reinforced-deepslate perimeter around the controller") : Text.muted("Controller layer: blackstone corners + copper-grate cardinals"),
                    voidCore ? Text.muted("Upper/lower copper pylons + tinted phase lenses + axial anchors") : Text.muted("One block above: amethyst corners + tinted-glass cardinals + lightning-rod center"))));
        }

        List<Component> heatLore = new ArrayList<>();
        heatLore.add(Text.lore(String.format(Locale.ROOT, "Current: %.1f°C", machine.heat())));
        heatLore.add(Text.lore(String.format(Locale.ROOT, "Target: %.0f°C", machine.targetHeat())));
        if (recipe == null) heatLore.add(Text.muted("Insert a valid process input to reveal its operating window."));
        else {
            heatLore.add(Text.lore(String.format(Locale.ROOT, "Valid window: %.0f–%.0f°C", recipe.minimumHeat(), recipe.maximumHeat())));
            heatLore.add(Text.muted("Quality improves near the center; active cooling consumes flux below ambient."));
        }
        inv.setItem(HEAT_SLOT, GuiItems.item(machine.targetHeat() < machines.ambientHeat() ? Material.PACKED_ICE : Material.BLAZE_POWDER,
            "Thermal State", machine.targetHeat() < machines.ambientHeat() ? NamedTextColor.AQUA : NamedTextColor.RED, heatLore));

        inv.setItem(ENERGY_SLOT, GuiItems.item(Material.REDSTONE, "Flux Buffer", NamedTextColor.RED,
            GuiItems.lore(Text.lore(machine.flux() + " / " + machines.maxFlux(machine.type()) + " Flux"),
                Text.muted("Redstone: +" + machines.redstoneFlux() + " • Block: +" + machines.redstoneBlockFlux()))));

        inv.setItem(DIAGNOSTICS_SLOT, GuiItems.item(Material.SPYGLASS, "Diagnostics", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Inspect efficiency, wear, thermal response, catalyst health, and installed modules."), Text.accent("Click to open diagnostics."))));
        inv.setItem(TARGET_DOWN_SLOT, GuiItems.item(Material.LIGHT_BLUE_DYE, "Target −25°C", NamedTextColor.AQUA, List.of()));
        inv.setItem(TARGET_SLOT, GuiItems.item(Material.COMPASS, String.format(Locale.ROOT, "Target %.0f°C", machine.targetHeat()), NamedTextColor.GOLD,
            GuiItems.lore(Text.muted("The chamber approaches this target gradually due to thermal inertia."))));
        inv.setItem(TARGET_UP_SLOT, GuiItems.item(Material.ORANGE_DYE, "Target +25°C", NamedTextColor.GOLD, List.of()));
        if (machine.type().usesPressure()) {
            inv.setItem(PRESSURE_DOWN_SLOT, GuiItems.item(Material.LIGHT_GRAY_DYE, "Pressure −0.5 bar", NamedTextColor.GRAY, List.of()));
            inv.setItem(PRESSURE_SLOT, GuiItems.item(Material.HEAVY_WEIGHTED_PRESSURE_PLATE, String.format(Locale.ROOT, "%.1f / %.1f bar", machine.pressure(), machine.targetPressure()), NamedTextColor.AQUA,
                recipe != null && recipe.usesPressure()
                    ? GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Valid: %.1f–%.1f bar", recipe.minimumPressure(), recipe.maximumPressure())), Text.muted("Compression consumes Flux; venting is passive."))
                    : GuiItems.lore(Text.muted("Pressure envelope becomes relevant when a pressure process is selected."))));
            inv.setItem(PRESSURE_UP_SLOT, GuiItems.item(Material.IRON_TRAPDOOR, "Pressure +0.5 bar", NamedTextColor.AQUA, List.of()));
        }
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private ItemStack disabled(String name) {
        return GuiItems.item(Material.GRAY_STAINED_GLASS_PANE, name, NamedTextColor.DARK_GRAY,
            GuiItems.lore(Text.muted("This machine type does not expose that process port.")));
    }

    private Material statusMaterial(ProcessEngine.TickState state) {
        return switch (state) {
            case PROCESSING, COMPLETED -> Material.LIME_DYE;
            case TOO_COLD -> Material.SNOWBALL;
            case TOO_HOT -> Material.FIRE_CHARGE;
            case PRESSURE_LOW -> Material.LIGHT_WEIGHTED_PRESSURE_PLATE;
            case PRESSURE_HIGH -> Material.HEAVY_WEIGHTED_PRESSURE_PLATE;
            case ENVIRONMENT_BLOCKED -> Material.COMPASS;
            case STRUCTURE_INVALID -> Material.BEACON;
            case FIELD_UNSTABLE -> Material.AMETHYST_SHARD;
            case ENTROPY_LOW -> Material.SCULK;
            case COMPUTATION_LOW -> Material.DAYLIGHT_DETECTOR;
            case FAULTED -> Material.ANVIL;
            case NO_FLUX -> Material.REDSTONE;
            case MISSING_SECONDARY_INPUT -> Material.DROPPER;
            case MISSING_CATALYST -> Material.BREWING_STAND;
            case CATALYST_CLEAN -> Material.LIME_DYE;
            case OUTPUT_BLOCKED, BYPRODUCT_BLOCKED -> Material.CHEST;
            case MAINTENANCE_REQUIRED -> Material.ANVIL;
            case NO_RECIPE -> Material.GRAY_DYE;
        };
    }

    private NamedTextColor statusColor(ProcessEngine.TickState state) {
        return switch (state) {
            case PROCESSING, COMPLETED, CATALYST_CLEAN -> NamedTextColor.GREEN;
            case TOO_COLD, NO_RECIPE -> NamedTextColor.GRAY;
            case TOO_HOT, PRESSURE_LOW, PRESSURE_HIGH, FAULTED, NO_FLUX, MAINTENANCE_REQUIRED, STRUCTURE_INVALID, FIELD_UNSTABLE, ENTROPY_LOW -> NamedTextColor.RED;
            case MISSING_SECONDARY_INPUT, MISSING_CATALYST, OUTPUT_BLOCKED, BYPRODUCT_BLOCKED, ENVIRONMENT_BLOCKED, COMPUTATION_LOW -> NamedTextColor.GOLD;
        };
    }

    private String prettyState(ProcessEngine.TickState state) {
        return switch (state) {
            case NO_RECIPE -> "Awaiting Input";
            case MISSING_SECONDARY_INPUT -> "Secondary Feed Required";
            case MISSING_CATALYST -> "Catalyst Required";
            case CATALYST_CLEAN -> "Catalyst Already Clean";
            case OUTPUT_BLOCKED -> "Output Blocked";
            case BYPRODUCT_BLOCKED -> "Byproduct Blocked";
            case FAULTED -> "Hard Fault";
            case MAINTENANCE_REQUIRED -> "Service Lockout";
            case TOO_COLD -> "Below Process Window";
            case TOO_HOT -> "Above Process Window";
            case PRESSURE_LOW -> "Pressure Below Window";
            case PRESSURE_HIGH -> "Pressure Above Window";
            case ENVIRONMENT_BLOCKED -> "Environment Constraint";
            case STRUCTURE_INVALID -> "Multiblock Incomplete";
            case FIELD_UNSTABLE -> "Spatial Field Unstable";
            case ENTROPY_LOW -> "Entropy Reserve Low";
            case COMPUTATION_LOW -> "Computation Reserve Low";
            case NO_FLUX -> "Insufficient Flux";
            case PROCESSING -> "Process Stable";
            case COMPLETED -> "Cycle Completed";
        };
    }

    private Component stateHint(ProcessEngine.TickState state) {
        return switch (state) {
            case NO_RECIPE -> Text.muted("Insert a supported VoidCore material in the primary feed slot.");
            case MISSING_SECONDARY_INPUT -> Text.bad("The selected process requires its registered secondary feed.");
            case MISSING_CATALYST -> Text.bad("Install the required catalyst before the reaction can proceed.");
            case CATALYST_CLEAN -> Text.good("This catalyst has no contamination to remove.");
            case OUTPUT_BLOCKED -> Text.accent("Remove the current main output to continue.");
            case BYPRODUCT_BLOCKED -> Text.accent("Remove the byproduct stream to continue.");
            case FAULTED -> Text.bad("Replace the fault-specific part on the placed machine before recommissioning it.");
            case MAINTENANCE_REQUIRED -> Text.bad("Service the placed machine with a Precision Maintenance Kit.");
            case TOO_COLD -> Text.bad("Raise the target or wait for active heating into the process window.");
            case TOO_HOT -> Text.bad("Lower the target or wait for cooling into the process window.");
            case PRESSURE_LOW -> Text.bad("Increase target pressure and supply Flux for active compression.");
            case PRESSURE_HIGH -> Text.bad("Lower target pressure and allow the vessel to vent into its process window.");
            case ENVIRONMENT_BLOCKED -> Text.bad("Move or rebuild this process line where the registered environmental predicate is satisfied.");
            case STRUCTURE_INVALID -> Text.bad("Complete the required multiblock structure before the process can advance.");
            case FIELD_UNSTABLE -> Text.bad("Raise local field stability with powered stabilizers and a Stability control policy.");
            case ENTROPY_LOW -> Text.bad("Feed entropy into this machine from connected process endpoints before starting the cycle.");
            case COMPUTATION_LOW -> Text.bad("Route computation from a powered Phase Observer into this machine.");
            case NO_FLUX -> Text.bad("Add redstone fuel or connect the machine to a supplied Flux Bus graph.");
            case PROCESSING -> Text.good("All active process constraints are satisfied.");
            case COMPLETED -> Text.good("Cycle complete; recover or route the output.");
        };
    }

    private ItemStack normalize(ItemStack stack) {
        return stack == null || stack.getType().isAir() ? null : stack.clone();
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
