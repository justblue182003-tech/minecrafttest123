package dev.voidcore.ui;

import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.item.QualityGrade;
import dev.voidcore.item.UpgradeType;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.process.ProcessRecipe;
import dev.voidcore.process.ProcessTuning;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MachineDiagnosticsMenu {
    public static final String MENU_ID = "machine:diagnostics";
    public static final int SINGULARITY_SLOT = 34;
    public static final int FIELD_VISUALIZE_SLOT = 35;
    public static final int LEDGER_SLOT = 43;
    public static final int GROUP_SLOT = 45;
    public static final int CHANNEL_SLOT = 46;
    public static final int GATE_SLOT = 47;
    public static final int SIGNAL_SLOT = 48;
    public static final int BACK_SLOT = 49;

    private final MachineService machines;
    private final ItemService items;

    public MachineDiagnosticsMenu(MachineService machines, ItemService items) {
        this.machines = machines;
        this.items = items;
    }

    public void open(Player player, MachineInstance machine) {
        if (machine == null || !machine.type().isEngineeringProcessor()) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Diagnostics"));
        holder.attach(inv);
        render(inv, machine);
        player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null || !machine.type().isEngineeringProcessor()) player.closeInventory();
            else render(top, machine);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        ProcessRecipe recipe = machines.currentRecipe(machine);
        ProcessTuning tuning = machines.tuning(machine);

        inv.setItem(4, GuiItems.item(Material.SPYGLASS, machine.type().displayName() + " Diagnostics", NamedTextColor.AQUA,
            GuiItems.lore(Text.muted("All values are derived from persistent machine state and installed modules."))));
        inv.setItem(11, GuiItems.item(Material.IRON_BLOCK, "Machine Quality", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore(machine.quality() + "/100 • " + QualityGrade.fromScore(machine.quality()).displayName()),
                Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", machine.wear())),
                machine.faulted() ? Text.bad("HARD FAULT: " + machine.fault().displayName())
                    : machine.hasFault() ? Text.accent("DEGRADED: " + machine.fault().displayName())
                    : machine.wear() >= 99.95 ? Text.bad("SERVICE LOCKOUT") : Text.muted("Quality affects speed, losses, thermal response, and wear rate."))));
        inv.setItem(13, GuiItems.item(Material.BLAZE_POWDER, "Thermal Model", NamedTextColor.RED,
            GuiItems.lore(
                Text.lore(String.format(Locale.ROOT, "Current: %.1f°C", machine.heat())),
                Text.lore(String.format(Locale.ROOT, "Target: %.0f°C", machine.targetHeat())),
                Text.lore(String.format(Locale.ROOT, "Thermal mass: %.1f", machine.type().thermalMass())),
                Text.lore(String.format(Locale.ROOT, "Heating response: %.0f%%", tuning.heatingMultiplier() * 100.0)),
                Text.lore(String.format(Locale.ROOT, "Cooling response: %.0f%%", tuning.coolingMultiplier() * 100.0)))));
        inv.setItem(15, GuiItems.item(Material.REDSTONE, "Process Efficiency", NamedTextColor.RED,
            GuiItems.lore(
                Text.lore(String.format(Locale.ROOT, "Cycle rate: %.0f%%", tuning.speedMultiplier() * 100.0)),
                Text.lore(String.format(Locale.ROOT, "Flux multiplier: %.0f%%", tuning.fluxMultiplier() * 100.0)),
                Text.lore(String.format(Locale.ROOT, "Contamination multiplier: %.0f%%", tuning.contaminationMultiplier() * 100.0)),
                Text.lore(String.format(Locale.ROOT, "Wear multiplier: %.0f%%", tuning.wearMultiplier() * 100.0)),
                Text.muted("Lower flux/contamination/wear multipliers are better."))));
        if (machine.type().usesPressure()) {
            inv.setItem(17, GuiItems.item(Material.HEAVY_WEIGHTED_PRESSURE_PLATE, "Pressure Model", NamedTextColor.AQUA,
                GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Current: %.2f bar", machine.pressure())),
                    Text.lore(String.format(Locale.ROOT, "Target: %.2f bar", machine.targetPressure())),
                    Text.lore(String.format(Locale.ROOT, "Safe vessel range: %.1f–%.1f bar", machine.type().minimumSafePressure(), machine.type().maximumSafePressure())),
                    machine.faulted() ? Text.bad(machine.fault().description()) : Text.muted("Compression consumes Flux; pressure naturally relaxes toward atmosphere."))));
        }
        if (machines.entropyCapacity(machine.type()) > 0.0) {
            inv.setItem(19, GuiItems.item(Material.SCULK, "Entropy Load", NamedTextColor.DARK_AQUA,
                GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Stored: %.1f / %.1f", machine.entropy(), machines.entropyCapacity(machine.type()))),
                    Text.lore(String.format(Locale.ROOT, "Load: %.0f%%", machine.entropy() * 100.0 / Math.max(1.0, machines.entropyCapacity(machine.type())))),
                    machine.hasFault() && machine.fault().entropyChain() ? Text.bad(machine.fault().description()) : Text.muted("Flux Bus networks can siphon excess entropy toward condenser arrays."))));
        }
        if (machines.computationCapacity(machine.type()) > 0) {
            inv.setItem(20, GuiItems.item(Material.DAYLIGHT_DETECTOR, "Computation Budget", NamedTextColor.AQUA,
                GuiItems.lore(Text.lore(machine.computation() + " / " + machines.computationCapacity(machine.type())),
                    Text.muted("Observation-derived computation is consumed by inference-heavy processes."))));
        }
        if (machine.type().isMultiblockController()) {
            var status = machines.structureStatus(machine);
            boolean voidCore = machine.type() == dev.voidcore.machine.MachineType.VOID_CORE;
            inv.setItem(21, GuiItems.item(status.valid() ? Material.LIME_STAINED_GLASS : Material.RED_STAINED_GLASS,
                status.valid() ? (voidCore ? "Void Lattice Complete" : "Condenser Array Complete") : (voidCore ? "Void Lattice Incomplete" : "Condenser Array Incomplete"),
                status.valid() ? NamedTextColor.GREEN : NamedTextColor.RED,
                GuiItems.lore(Text.lore(status.matched() + " / " + status.required() + " structure blocks matched"),
                    status.valid() ? Text.good("Physical containment field valid") : Text.bad(status.firstProblem()))));
        }

        if (recipe == null) {
            inv.setItem(22, GuiItems.item(Material.GRAY_DYE, "No Active Process", NamedTextColor.GRAY,
                GuiItems.lore(Text.muted("Insert a supported input to calculate process constraints."))));
        } else {
            inv.setItem(22, GuiItems.item(recipe.output().material(), recipe.output().displayName(), NamedTextColor.LIGHT_PURPLE,
                GuiItems.lore(
                    Text.lore(String.format(Locale.ROOT, "Heat window: %.0f–%.0f°C", recipe.minimumHeat(), recipe.maximumHeat())),
                    Text.lore("Nominal flux: " + recipe.fluxCost()),
                    Text.lore(String.format(Locale.ROOT, "Nominal cycle: %.0fs", recipe.durationSeconds())),
                    Text.lore("Projected quality: " + machines.projectedOutputQuality(machine) + "/100"),
                    recipe.usesSpatialField() ? Text.lore(String.format(Locale.ROOT, "Spatial field: %.1f%% / %.0f%%", machine.fieldStability(), recipe.minimumFieldStability())) : Text.muted("No spatial-field requirement"),
                    Text.lore("State: " + machines.processState(machine).name().replace('_', ' ')))));
        }

        inv.setItem(24, GuiItems.item(Material.AMETHYST_SHARD, "Spatial Field", machine.fieldStability() >= 80.0 ? NamedTextColor.GREEN : NamedTextColor.AQUA,
            GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Local stability: %.1f%%", machine.fieldStability())),
                Text.lore("Network policy: " + machine.activeDirective().displayName()),
                Text.muted("Nearby stabilizers, observers, entropy pressure, and control policy alter this value."))));
        inv.setItem(26, GuiItems.item(machine.activeDirective().icon(), "Active Control Policy", NamedTextColor.LIGHT_PURPLE,
            GuiItems.lore(Text.lore(machine.activeDirective().displayName()), Text.lore(machine.activeDirective().description()),
                Text.muted("Policy modifiers are applied by the deterministic Control Matrix on the attached graph."))));
        inv.setItem(32, GuiItems.item(Material.CLOCK, "Lifetime Production", NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Completed cycles: " + machine.lifetimeCycles()),
                Text.lore("Items produced: " + machine.lifetimeItemsProduced()),
                Text.lore("Flux consumed: " + machine.lifetimeFluxConsumed()),
                Text.lore(String.format(Locale.ROOT, "Entropy processed: %.1f", machine.lifetimeEntropyProcessed())),
                Text.lore("Industrial incidents: " + machine.incidentCount()))));

        if (machine.type() == dev.voidcore.machine.MachineType.VOID_CORE) {
            var mode = machine.singularityMode();
            inv.setItem(SINGULARITY_SLOT, GuiItems.item(mode.icon(), "Singularity • " + mode.displayName(), NamedTextColor.LIGHT_PURPLE,
                GuiItems.lore(Text.lore(mode.description()),
                    Text.lore(String.format(Locale.ROOT, "Speed %.0f%% • Flux %.0f%% • Entropy %.0f%%", mode.speedMultiplier() * 100.0, mode.fluxMultiplier() * 100.0, mode.entropyMultiplier() * 100.0)),
                    Text.lore("Compression chambers: " + machines.coreChamberCount(machine, dev.voidcore.machine.CoreChamberMode.COMPRESSION)),
                    Text.lore("Extraction chambers: " + machines.coreChamberCount(machine, dev.voidcore.machine.CoreChamberMode.EXTRACTION)),
                    Text.accent("Click: next mode • Right-click: previous"))));
        }
        inv.setItem(FIELD_VISUALIZE_SLOT, GuiItems.item(Material.END_ROD, "Visualize Spatial Field", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Measured stability: %.1f%%", machine.fieldStability())),
                Text.accent("Click to render a player-only local field trace."))));

        List<net.kyori.adventure.text.Component> ledgerLore = new ArrayList<>();
        ledgerLore.add(Text.lore("Distinct outputs: " + machine.productionLedger().size()));
        machine.productionLedger().entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())).limit(5).forEach(entry -> {
            CustomItem item = CustomItem.fromId(entry.getKey());
            ledgerLore.add(Text.lore((item == null ? entry.getKey() : item.displayName()) + ": " + entry.getValue()));
        });
        if (machine.productionLedger().isEmpty()) ledgerLore.add(Text.muted("No registered production yet."));
        inv.setItem(LEDGER_SLOT, GuiItems.item(Material.WRITABLE_BOOK, "Per-Item Production Ledger", NamedTextColor.GOLD, ledgerLore));

        inv.setItem(GROUP_SLOT, GuiItems.item(Material.NAME_TAG, "Automation Group G" + machine.automationGroup(), NamedTextColor.GOLD,
            GuiItems.lore(Text.lore("Condition terminals target machines by group."), Text.accent("Click: next • Right-click: previous"))));
        inv.setItem(CHANNEL_SLOT, GuiItems.item(Material.REDSTONE_TORCH, "Signal Channel CH" + machine.signalChannel(), NamedTextColor.RED,
            GuiItems.lore(Text.lore("Current signal: " + (machine.signalHigh() ? "HIGH" : "LOW")), Text.accent("Click: next • Right-click: previous"))));
        inv.setItem(GATE_SLOT, GuiItems.item(machine.signalGate().icon(), machine.signalGate().displayName(), NamedTextColor.AQUA,
            GuiItems.lore(Text.lore(machine.signalGate().description()), Text.accent("Click: next gate • Right-click: previous"))));
        inv.setItem(SIGNAL_SLOT, GuiItems.item(machine.automationAllowsRun() ? Material.LIME_CONCRETE : Material.RED_CONCRETE,
            machine.automationAllowsRun() ? "Automation Permission: RUN" : "Automation Permission: HOLD",
            machine.automationAllowsRun() ? NamedTextColor.GREEN : NamedTextColor.RED,
            GuiItems.lore(Text.lore("G" + machine.automationGroup() + " • CH" + machine.signalChannel() + " • " + machine.signalGate().displayName()),
                Text.muted("Signal state is resolved once per network evaluation."))));

        ItemStack catalyst = machine.catalyst();
        if (catalyst != null && items.identify(catalyst) != null) {
            double contamination = items.contamination(catalyst);
            inv.setItem(30, GuiItems.item(Material.HEART_OF_THE_SEA, "Catalyst Health", contamination >= 70 ? NamedTextColor.RED : NamedTextColor.AQUA,
                GuiItems.lore(Text.lore("Quality: " + items.quality(catalyst) + "/100"),
                    Text.lore(String.format(Locale.ROOT, "Contamination: %.1f%%", contamination)),
                    Text.muted("Catalytic activity decreases continuously as contamination rises."))));
        } else {
            inv.setItem(30, GuiItems.item(Material.GRAY_DYE, "Catalyst Health", NamedTextColor.GRAY,
                GuiItems.lore(Text.muted("No catalyst installed."))));
        }

        for (int i = 0; i < 3; i++) {
            int slot = 37 + i * 2;
            ItemStack upgrade = machine.upgrade(i);
            UpgradeType type = UpgradeType.fromItem(items.identify(upgrade));
            if (type == null) inv.setItem(slot, GuiItems.item(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "Socket " + (i + 1) + " Empty", NamedTextColor.GRAY, List.of()));
            else inv.setItem(slot, GuiItems.item(type.item().material(), type.displayName(), NamedTextColor.YELLOW,
                GuiItems.lore(Text.lore(type.description()), Text.lore("Module quality: " + items.quality(upgrade) + "/100"))));
        }

        inv.setItem(BACK_SLOT, GuiItems.item(Material.ARROW, "Back to Machine", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
