package dev.voidcore.ui;

import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineType;
import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class SpectrumAnalyzerMenu {
    public enum AnalyzeResult { NEW_DISCOVERY, ALREADY_KNOWN, MISSING_SAMPLE }

    public static final String MENU_ID = "machine:spectrum_analyzer";
    public static final int CLOSE_SLOT = 49;
    private static final int[] SLOTS = {10,12,14,16,28,30,32,34};
    private static final CustomItem[] SCANNABLE = {
        CustomItem.RESONANT_FRAGMENT,
        CustomItem.CHARGED_RESONANCE,
        CustomItem.COPPER_LATTICE,
        CustomItem.FLUX_COIL,
        CustomItem.ANALYSIS_PRISM,
        CustomItem.PHASE_GLASS,
        CustomItem.STABILIZED_MATRIX,
        CustomItem.RESONANT_ALLOY
    };

    private final ItemService items;
    private final DiscoveryService discoveries;
    private final ExperimentService experiments;
    private final ResearchService research;

    public SpectrumAnalyzerMenu(ItemService items, DiscoveryService discoveries, ExperimentService experiments, ResearchService research) {
        this.items = items;
        this.discoveries = discoveries;
        this.experiments = experiments;
        this.research = research;
    }

    public void open(Player player, MachineInstance machine) {
        if (machine.type() != MachineType.SPECTRUM_ANALYZER) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Spectrum Analyzer"));
        holder.attach(inv);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));

        inv.setItem(4, GuiItems.item(Material.SPYGLASS, "Spectrum Analyzer", NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Non-destructive scans use samples in your inventory."),
                Text.muted("First-time scans add the sample to your Material Index."))));

        for (int i = 0; i < SCANNABLE.length; i++) inv.setItem(SLOTS[i], scanItem(player, SCANNABLE[i]));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
        player.openInventory(inv);
    }

    public CustomItem itemAt(int slot) {
        for (int i = 0; i < SLOTS.length; i++) if (SLOTS[i] == slot) return SCANNABLE[i];
        return null;
    }

    public AnalyzeResult analyze(Player player, CustomItem item) {
        if (!hasSample(player, item)) return AnalyzeResult.MISSING_SAMPLE;
        boolean fresh = discoveries.scan(player, item);
        if (item == CustomItem.RESONANT_FRAGMENT) {
            experiments.advance(player, ResearchExperiment.ANALYZE_RESONANCE);
        }
        if (!fresh) return AnalyzeResult.ALREADY_KNOWN;
        int reward = scanReward(item);
        research.addInsight(player, reward);
        return AnalyzeResult.NEW_DISCOVERY;
    }

    private ItemStack scanItem(Player player, CustomItem item) {
        ItemStack stack = items.create(item);
        ItemMeta meta = stack.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        boolean has = hasSample(player, item);
        boolean known = discoveries.isScanned(player, item);
        lore.add(Component.empty());
        lore.add(known ? Text.good("✓ Spectral signature catalogued") : Text.accent("Unscanned spectral signature"));
        lore.add(has ? Text.good("Sample available") : Text.bad("Carry a sample to scan"));
        if (!known) lore.add(Text.lore("First scan: +" + scanReward(item) + " Insight"));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(known);
        stack.setItemMeta(meta);
        return stack;
    }

    private boolean hasSample(Player player, CustomItem item) {
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (items.is(stack, item)) return true;
        }
        return false;
    }

    private int scanReward(CustomItem item) {
        return switch (item) {
            case RESONANT_FRAGMENT, COPPER_LATTICE -> 1;
            case CHARGED_RESONANCE, FLUX_COIL, ANALYSIS_PRISM -> 2;
            case PHASE_GLASS, STABILIZED_MATRIX, RESONANT_ALLOY -> 3;
            default -> 1;
        };
    }
}
