package dev.voidcore.ui;

import dev.voidcore.item.QualityGrade;
import dev.voidcore.machine.MachineInstance;
import dev.voidcore.machine.MachineService;
import dev.voidcore.machine.MachineType;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.Locale;

public final class ThermalExchangerMenu {
    public static final String MENU_ID = "machine:thermal_exchanger";
    public static final int CLOSE_SLOT = 53;

    private final MachineService machines;

    public ThermalExchangerMenu(MachineService machines) {
        this.machines = machines;
    }

    public void open(Player player, MachineInstance machine) {
        if (machine == null || machine.type() != MachineType.THERMAL_EXCHANGER) return;
        MachineMenuHolder holder = new MachineMenuHolder(machine.location(), MENU_ID);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Thermal Exchanger"));
        holder.attach(inv);
        render(inv, machine);
        player.openInventory(inv);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            MachineInstance machine = machines.get(holder.machineLocation());
            if (machine == null || machine.type() != MachineType.THERMAL_EXCHANGER) player.closeInventory();
            else render(top, machine);
        }
    }

    public void closeViewersAt(org.bukkit.Location location) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Inventory top = player.getOpenInventory().getTopInventory();
            if (!(top.getHolder() instanceof MachineMenuHolder holder) || !holder.menuId().equals(MENU_ID)) continue;
            if (sameBlock(holder.machineLocation(), location)) player.closeInventory();
        }
    }

    private void render(Inventory inv, MachineInstance machine) {
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.BLAST_FURNACE, "Thermal Exchanger", NamedTextColor.GOLD,
            GuiItems.lore(
                Text.lore("Quality: " + machine.quality() + "/100 • " + QualityGrade.fromScore(machine.quality()).displayName()),
                Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", machine.wear())),
                Text.muted("Pairs the hottest and coldest adjacent engineering machines every second."))));

        double transfer = machine.lastHeatTransfer();
        inv.setItem(13, GuiItems.item(transfer > 0.05 ? Material.LIME_DYE : Material.GRAY_DYE,
            transfer > 0.05 ? "Heat Recovery Active" : "Awaiting Thermal Gradient",
            transfer > 0.05 ? NamedTextColor.GREEN : NamedTextColor.GRAY,
            GuiItems.lore(
                Text.lore(String.format(Locale.ROOT, "Last transfer: %.1f thermal units", transfer)),
                Text.muted("Recovered heat cools the hotter line while warming the colder line; some energy is lost."))));

        List<MachineInstance> adjacent = machines.adjacentMachines(machine.location()).stream()
            .filter(candidate -> candidate.type().isEngineeringProcessor())
            .toList();
        int[] slots = {20, 21, 22, 23, 24, 25};
        for (int i = 0; i < slots.length; i++) {
            if (i >= adjacent.size()) {
                inv.setItem(slots[i], GuiItems.item(Material.GRAY_STAINED_GLASS_PANE, "No process machine", NamedTextColor.DARK_GRAY, List.of()));
                continue;
            }
            MachineInstance endpoint = adjacent.get(i);
            inv.setItem(slots[i], GuiItems.item(endpoint.type().item().material(), endpoint.type().displayName(), NamedTextColor.AQUA,
                GuiItems.lore(
                    Text.lore(String.format(Locale.ROOT, "Temperature: %.1f°C", endpoint.heat())),
                    Text.lore("Address: " + machines.networkAddress(endpoint)),
                    Text.muted("Must be directly adjacent to exchange heat."))));
        }

        inv.setItem(31, GuiItems.item(Material.ANVIL, machine.maintenanceLocked() ? "Service Lockout" : "Service Condition",
            machine.maintenanceLocked() ? NamedTextColor.RED : NamedTextColor.YELLOW,
            GuiItems.lore(Text.lore(String.format(Locale.ROOT, "Wear: %.1f%%", machine.wear())),
                Text.muted("Use a Precision Maintenance Kit directly on the placed exchanger to service it."))));
        inv.setItem(CLOSE_SLOT, GuiItems.item(Material.BARRIER, "Close", NamedTextColor.GRAY, List.of()));
    }

    private boolean sameBlock(org.bukkit.Location a, org.bukkit.Location b) {
        return a.getWorld() != null && b.getWorld() != null && a.getWorld().getUID().equals(b.getWorld().getUID())
            && a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ();
    }
}
