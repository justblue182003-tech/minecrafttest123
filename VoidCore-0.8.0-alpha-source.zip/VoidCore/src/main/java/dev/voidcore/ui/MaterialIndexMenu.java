package dev.voidcore.ui;

import dev.voidcore.discovery.DiscoveryService;
import dev.voidcore.item.CustomItem;
import dev.voidcore.item.ItemService;
import dev.voidcore.recipe.RecipeRegistry;
import dev.voidcore.recipe.VoidRecipe;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class MaterialIndexMenu {
    public static final String MENU_PREFIX = "materials:";
    public static final int PREVIOUS_SLOT = 45;
    public static final int BACK_SLOT = 49;
    public static final int NEXT_SLOT = 53;
    private static final int[] CONTENT_SLOTS = {
        9,10,11,12,13,14,15,16,17,
        18,19,20,21,22,23,24,25,26,
        27,28,29,30,31,32,33,34,35,
        36,37,38,39,40,41,42,43,44
    };

    private final ItemService items;
    private final DiscoveryService discoveries;
    private final RecipeRegistry recipes;
    private final List<CustomItem> indexed;

    public MaterialIndexMenu(ItemService items, DiscoveryService discoveries, RecipeRegistry recipes) {
        this.items = items;
        this.discoveries = discoveries;
        this.recipes = recipes;
        this.indexed = Arrays.stream(CustomItem.values())
            .filter(item -> item.category() == CustomItem.Category.MATERIAL || item.category() == CustomItem.Category.COMPONENT)
            .toList();
    }

    public void open(Player player) { open(player, 0); }

    public void open(Player player, int requestedPage) {
        int pages = Math.max(1, (int) Math.ceil(indexed.size() / (double) CONTENT_SLOTS.length));
        int page = Math.max(0, Math.min(pages - 1, requestedPage));
        MenuHolder holder = new MenuHolder(MENU_PREFIX + page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Material Index"));
        holder.attach(inv);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.AMETHYST_SHARD, "Material Index • " + (page + 1) + "/" + pages, NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Craft or scan materials to catalogue them."),
                Text.muted("Unknown entries remain visible so the progression has clear goals."))));

        int start = page * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            int index = start + i;
            if (index >= indexed.size()) break;
            inv.setItem(CONTENT_SLOTS[i], materialItem(player, indexed.get(index)));
        }
        inv.setItem(PREVIOUS_SLOT, page > 0
            ? GuiItems.item(Material.SPECTRAL_ARROW, "Previous Page", NamedTextColor.GRAY, List.of())
            : GuiItems.filler(Material.GRAY_STAINED_GLASS_PANE));
        inv.setItem(BACK_SLOT, GuiItems.item(Material.ARROW, "Back", NamedTextColor.GRAY, List.of()));
        inv.setItem(NEXT_SLOT, page + 1 < pages
            ? GuiItems.item(Material.SPECTRAL_ARROW, "Next Page", NamedTextColor.AQUA, List.of())
            : GuiItems.filler(Material.GRAY_STAINED_GLASS_PANE));
        player.openInventory(inv);
    }

    public int page(MenuHolder holder) {
        if (holder == null || !holder.menuId().startsWith(MENU_PREFIX)) return 0;
        try { return Integer.parseInt(holder.menuId().substring(MENU_PREFIX.length())); }
        catch (NumberFormatException ignored) { return 0; }
    }

    public CustomItem itemAt(MenuHolder holder, int slot) {
        int local = -1;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) if (CONTENT_SLOTS[i] == slot) { local = i; break; }
        if (local < 0) return null;
        int index = page(holder) * CONTENT_SLOTS.length + local;
        return index >= 0 && index < indexed.size() ? indexed.get(index) : null;
    }

    public VoidRecipe recipeFor(CustomItem item) { return recipes.producing(item); }

    private ItemStack materialItem(Player player, CustomItem item) {
        boolean known = discoveries.isDiscovered(player, item);
        if (!known) {
            return GuiItems.item(Material.GRAY_DYE, "Unknown Material", NamedTextColor.DARK_GRAY,
                GuiItems.lore(Text.muted("Acquire or scan this material to catalogue its signature."),
                    Text.lore("Codex key: " + item.id())));
        }

        ItemStack stack = items.create(item);
        ItemMeta meta = stack.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Component.empty());
        lore.add(Text.good("✓ Acquired / catalogued"));
        lore.add(discoveries.isScanned(player, item) ? Text.good("✓ Spectral scan complete") : Text.muted("○ Spectral scan pending"));
        if (recipes.producing(item) != null) lore.add(Text.accent("Click to view its recipe"));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        stack.setItemMeta(meta);
        return stack;
    }
}
