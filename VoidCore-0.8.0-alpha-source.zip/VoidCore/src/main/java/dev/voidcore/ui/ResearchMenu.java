package dev.voidcore.ui;

import dev.voidcore.research.ExperimentService;
import dev.voidcore.research.ResearchExperiment;
import dev.voidcore.research.ResearchNode;
import dev.voidcore.research.ResearchService;
import dev.voidcore.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public final class ResearchMenu {
    public static final int BACK_SLOT = 49;
    private static final Map<Integer, ResearchNode> BY_SLOT = new HashMap<>();
    private static final Map<ResearchNode, Integer> BY_NODE = new EnumMap<>(ResearchNode.class);

    static {
        int[] slots = {10, 13, 16, 25, 34, 31, 28, 37, 39, 41, 43, 45, 47, 51, 46, 52, 48, 50, 53};
        ResearchNode[] nodes = ResearchNode.values();
        for (int i = 0; i < nodes.length && i < slots.length; i++) {
            BY_SLOT.put(slots[i], nodes[i]);
            BY_NODE.put(nodes[i], slots[i]);
        }
    }

    private final ResearchService research;
    private final ExperimentService experiments;

    public ResearchMenu(ResearchService research, ExperimentService experiments) {
        this.research = research;
        this.experiments = experiments;
    }

    public void open(Player player) {
        MenuHolder holder = new MenuHolder("research");
        Inventory inv = Bukkit.createInventory(holder, 54, Text.title("VoidCore • Research Matrix"));
        holder.attach(inv);

        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, GuiItems.filler(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(4, GuiItems.item(Material.EXPERIENCE_BOTTLE, "Insight: " + research.insight(player), NamedTextColor.AQUA,
            GuiItems.lore(Text.lore("Insight comes primarily from discoveries and completed experiments."))));
        inv.setItem(BACK_SLOT, GuiItems.item(Material.ARROW, "Back", NamedTextColor.GRAY, GuiItems.lore(Text.muted("Return to the Codex."))));

        for (ResearchNode node : ResearchNode.values()) {
            Integer slot = BY_NODE.get(node);
            if (slot != null) inv.setItem(slot, nodeItem(player, node));
        }
        player.openInventory(inv);
    }

    public ResearchNode nodeAt(int slot) {
        return BY_SLOT.get(slot);
    }

    private ItemStack nodeItem(Player player, ResearchNode node) {
        boolean unlocked = research.isUnlocked(player, node);
        boolean prereq = research.prerequisitesMet(player, node);
        boolean expMet = research.experimentsMet(player, node);
        boolean available = prereq && expMet;
        NamedTextColor color = unlocked ? NamedTextColor.GREEN : available ? NamedTextColor.LIGHT_PURPLE : NamedTextColor.RED;
        Material icon = unlocked || available ? node.icon() : Material.BARRIER;

        String prereqs = node.prerequisites().isEmpty()
            ? "None"
            : node.prerequisites().stream().map(ResearchNode::displayName).collect(Collectors.joining(", "));

        List<Component> lore = new ArrayList<>();
        lore.add(Text.lore(node.description()));
        lore.add(Component.empty());
        lore.add(Text.lore("Cost: " + node.cost() + " Insight"));
        lore.add(Text.lore("Research prerequisite: " + prereqs));
        if (!node.experiments().isEmpty()) {
            lore.add(Component.empty());
            lore.add(Text.accent("Required experiments:"));
            for (ResearchExperiment experiment : node.experiments()) {
                lore.add(experiments.isComplete(player, experiment)
                    ? Text.good("✓ " + experiment.displayName())
                    : Text.bad("✗ " + experiment.displayName()));
            }
        }
        lore.add(Component.empty());
        if (unlocked) lore.add(Text.good("✓ Researched"));
        else if (!prereq) lore.add(Text.bad("Complete prerequisite research first"));
        else if (!expMet) lore.add(Text.bad("Complete required experiments first"));
        else if (research.insight(player) < node.cost()) lore.add(Text.bad("Not enough Insight"));
        else lore.add(Text.accent("Click to research"));

        ItemStack stack = GuiItems.item(icon, node.displayName(), color, lore);
        ItemMeta meta = stack.getItemMeta();
        meta.setEnchantmentGlintOverride(unlocked);
        stack.setItemMeta(meta);
        return stack;
    }
}
