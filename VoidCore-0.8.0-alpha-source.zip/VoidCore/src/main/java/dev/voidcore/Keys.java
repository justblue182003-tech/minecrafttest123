package dev.voidcore;

import org.bukkit.NamespacedKey;

public final class Keys {
    public final NamespacedKey itemId;
    public final NamespacedKey itemQuality;
    public final NamespacedKey catalystContamination;
    public final NamespacedKey machineWear;
    public final NamespacedKey machineEntropy;
    public final NamespacedKey machineFault;
    public final NamespacedKey machineFaultTicks;
    public final NamespacedKey machineObserverProgram;
    public final NamespacedKey machineControlDirective;
    public final NamespacedKey machineCycles;
    public final NamespacedKey machineItemsProduced;
    public final NamespacedKey machineFluxConsumed;
    public final NamespacedKey machineEntropyProcessed;
    public final NamespacedKey machineIncidents;
    public final NamespacedKey machineAutomationGroup;
    public final NamespacedKey machineSignalChannel;
    public final NamespacedKey machineSignalGate;
    public final NamespacedKey machineAutomationRule;
    public final NamespacedKey machineSingularityMode;
    public final NamespacedKey machineCoreChamberMode;
    public final NamespacedKey machineProductionLedger;
    public final NamespacedKey insight;
    public final NamespacedKey research;
    public final NamespacedKey experimentProgress;
    public final NamespacedKey discoveries;
    public final NamespacedKey scans;
    public final NamespacedKey machineType;

    public Keys(VoidCorePlugin plugin) {
        this.itemId = new NamespacedKey(plugin, "item_id");
        this.itemQuality = new NamespacedKey(plugin, "item_quality");
        this.catalystContamination = new NamespacedKey(plugin, "catalyst_contamination");
        this.machineWear = new NamespacedKey(plugin, "machine_wear");
        this.machineEntropy = new NamespacedKey(plugin, "machine_entropy");
        this.machineFault = new NamespacedKey(plugin, "machine_fault");
        this.machineFaultTicks = new NamespacedKey(plugin, "machine_fault_ticks");
        this.machineObserverProgram = new NamespacedKey(plugin, "machine_observer_program");
        this.machineControlDirective = new NamespacedKey(plugin, "machine_control_directive");
        this.machineCycles = new NamespacedKey(plugin, "machine_cycles");
        this.machineItemsProduced = new NamespacedKey(plugin, "machine_items_produced");
        this.machineFluxConsumed = new NamespacedKey(plugin, "machine_flux_consumed");
        this.machineEntropyProcessed = new NamespacedKey(plugin, "machine_entropy_processed");
        this.machineIncidents = new NamespacedKey(plugin, "machine_incidents");
        this.machineAutomationGroup = new NamespacedKey(plugin, "machine_automation_group");
        this.machineSignalChannel = new NamespacedKey(plugin, "machine_signal_channel");
        this.machineSignalGate = new NamespacedKey(plugin, "machine_signal_gate");
        this.machineAutomationRule = new NamespacedKey(plugin, "machine_automation_rule");
        this.machineSingularityMode = new NamespacedKey(plugin, "machine_singularity_mode");
        this.machineCoreChamberMode = new NamespacedKey(plugin, "machine_core_chamber_mode");
        this.machineProductionLedger = new NamespacedKey(plugin, "machine_production_ledger");
        this.insight = new NamespacedKey(plugin, "insight");
        this.research = new NamespacedKey(plugin, "research");
        this.experimentProgress = new NamespacedKey(plugin, "experiment_progress");
        this.discoveries = new NamespacedKey(plugin, "discoveries");
        this.scans = new NamespacedKey(plugin, "scans");
        this.machineType = new NamespacedKey(plugin, "machine_type");
    }
}
