package dev.voidcore.simulation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EngineeringMathTest {
    @Test
    void networkLossIsHopBasedAndCapped() {
        assertEquals(0.02, EngineeringMath.networkLossRate(0.02, 0.008, 0), 1.0e-9);
        assertEquals(0.06, EngineeringMath.networkLossRate(0.02, 0.008, 5), 1.0e-9);
        assertEquals(0.30, EngineeringMath.networkLossRate(0.20, 0.10, 8), 1.0e-9);
    }

    @Test
    void deliveredFluxNeverExceedsSentFlux() {
        assertEquals(90, EngineeringMath.deliveredFlux(100, 0.10));
        assertEquals(0, EngineeringMath.deliveredFlux(0, 0.10));
        assertTrue(EngineeringMath.deliveredFlux(500, 0.30) <= 500);
    }

    @Test
    void sentFluxCompensatesForLoss() {
        int sent = EngineeringMath.requiredSentFlux(100, 0.20);
        assertEquals(125, sent);
        assertTrue(EngineeringMath.deliveredFlux(sent, 0.20) >= 100);
    }

    @Test
    void maintenanceQualityMattersButIsBounded() {
        assertEquals(38.0, EngineeringMath.maintenanceReduction(-20), 1.0e-9);
        assertEquals(55.0, EngineeringMath.maintenanceReduction(50), 1.0e-9);
        assertEquals(72.0, EngineeringMath.maintenanceReduction(120), 1.0e-9);
    }

    @Test
    void passiveTemperatureMovesTowardAmbient() {
        double cooled = EngineeringMath.passiveTemperature(500, 20, 0.075, 10);
        double warmed = EngineeringMath.passiveTemperature(-100, 20, 0.075, 10);
        assertTrue(cooled < 500 && cooled > 20);
        assertTrue(warmed > -100 && warmed < 20);
    }

    @Test
    void exchangerTransferIsLimitedByTemperatureDifference() {
        assertEquals(22.0, EngineeringMath.exchangerTransfer(120, 20, 500, 100), 1.0e-9);
        assertEquals(0.0, EngineeringMath.exchangerTransfer(20, 20, 90, 50), 1.0e-9);
    }

    @Test
    void passivePressureRelaxesTowardAtmosphere() {
        assertEquals(9.28, EngineeringMath.passivePressure(10.0, 1.0, 0.08), 1.0e-9);
        assertEquals(1.0, EngineeringMath.passivePressure(1.0, 1.0, 0.08), 1.0e-9);
    }

    @Test
    void pressureAccuracyPeaksAtCenter() {
        assertEquals(1.0, EngineeringMath.pressureAccuracy(5.0, 4.0, 6.0), 1.0e-9);
        assertEquals(0.0, EngineeringMath.pressureAccuracy(7.0, 4.0, 6.0), 1.0e-9);
        assertTrue(EngineeringMath.pressureAccuracy(5.5, 4.0, 6.0) > 0.0);
    }

    @Test
    void routingPriorityDominatesDistanceWhileTiePrefersShorterPath() {
        assertTrue(EngineeringMath.routingScore(8, 20) > EngineeringMath.routingScore(7, 1));
        assertTrue(EngineeringMath.routingScore(5, 2) > EngineeringMath.routingScore(5, 8));
    }
    @Test
    void spatialFalloffIsBoundedAndLinearInsideRadius() {
        assertEquals(1.0, EngineeringMath.spatialFalloff(0.0, 12.0), 1.0e-9);
        assertEquals(0.5, EngineeringMath.spatialFalloff(6.0, 12.0), 1.0e-9);
        assertEquals(0.0, EngineeringMath.spatialFalloff(12.0, 12.0), 1.0e-9);
        assertEquals(0.0, EngineeringMath.spatialFalloff(30.0, 12.0), 1.0e-9);
    }

    @Test
    void fieldStabilityIsClampedToPercentageRange() {
        assertEquals(0.0, EngineeringMath.fieldStability(-30.0), 1.0e-9);
        assertEquals(82.5, EngineeringMath.fieldStability(82.5), 1.0e-9);
        assertEquals(100.0, EngineeringMath.fieldStability(140.0), 1.0e-9);
    }

}
