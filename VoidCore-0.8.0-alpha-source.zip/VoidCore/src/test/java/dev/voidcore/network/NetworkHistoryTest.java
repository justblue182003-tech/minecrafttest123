package dev.voidcore.network;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

final class NetworkHistoryTest {
    @Test
    void capsRollingWindowAndComputesAverages() {
        NetworkHistory history = new NetworkHistory(5);
        for (int i = 1; i <= 7; i++) {
            history.add(new NetworkHistory.Sample(i * 10, i, i, i * 0.5, i * 2, 0, 0, 0, 0));
        }
        NetworkHistory.Summary summary = history.summary();
        assertEquals(5, summary.samples());
        assertEquals(50, summary.averageFluxDelivered());
        assertEquals(5, summary.averageItemMoves());
        assertEquals(2.5, summary.averageEntropyMoved(), 0.001);
        assertEquals(10, summary.averageComputationMoved());
    }

    @Test
    void entropyPressureWinsBottleneckClassification() {
        NetworkHistory history = new NetworkHistory(5);
        for (int i = 0; i < 5; i++) {
            history.add(new NetworkHistory.Sample(100, 0, 0, 0.0, 0, 2, 2, 3, 0));
        }
        assertTrue(history.summary().bottleneck().contains("Entropy"));
    }
}
